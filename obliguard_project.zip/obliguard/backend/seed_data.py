"""
ObliGuard AI - Database Seed Script
Populates initial RBAC roles, default demo organization, Org Admin user, sample contracts, and obligations.
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from sqlalchemy.orm import Session
from app.database import engine, SessionLocal, Base
from app.models import (
    Role, Permission, Organization, Department, User, Contract,
    ContractVersion, Clause, Obligation, Deadline, RiskScore, RiskFactor, RiskHistory
)
from app.core.security import get_password_hash
from app.core.permissions import RoleName
from datetime import datetime, timedelta, timezone

def seed_database():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    try:
        print("Seeding ObliGuard AI Database...")

        # 1. Seed Roles
        roles_data = [
            (RoleName.SUPER_ADMIN, "Full system administration access across all tenants.", True),
            (RoleName.ORG_ADMIN, "Full organization administrative privileges.", True),
            (RoleName.LEGAL_MANAGER, "Manages legal risk, clauses, and obligation waivers.", True),
            (RoleName.CONTRACT_MANAGER, "Manages contract uploads, deadlines, and renewals.", True),
            (RoleName.EMPLOYEE, "Executes assigned obligations and views contract details.", True),
            (RoleName.VIEWER, "Read-only analytics and contract viewing.", True)
        ]

        for name, desc, is_sys in roles_data:
            role = db.query(Role).filter(Role.name == name.value).first()
            if not role:
                db.add(Role(name=name.value, description=desc, is_system=is_sys))
        db.commit()

        # 2. Seed Organization
        org = db.query(Organization).filter(Organization.slug == "acme-corp").first()
        if not org:
            org = Organization(
                name="Acme Enterprise Corporation",
                slug="acme-corp",
                domain="acme.com"
            )
            db.add(org)
            db.commit()
            db.refresh(org)

        # 3. Seed Department
        dept = db.query(Department).filter(Department.organization_id == org.id).first()
        if not dept:
            dept = Department(
                organization_id=org.id,
                name="Legal & Compliance",
                code="LEGAL-01",
                description="Global Corporate Legal & Regulatory Compliance Department"
            )
            db.add(dept)
            db.commit()
            db.refresh(dept)

        # 4. Seed Org Admin User
        user = db.query(User).filter(User.email == "admin@acme.com").first()
        if not user:
            user = User(
                organization_id=org.id,
                email="admin@acme.com",
                password_hash=get_password_hash("Password123!"),
                full_name="Alex Mercer (Org Admin)",
                role_name="Organization Admin",
                department_id=dept.id,
                is_verified=True
            )
            db.add(user)
            db.commit()
            db.refresh(user)

        # 5. Seed Sample Contract & Obligations
        contract = db.query(Contract).filter(Contract.organization_id == org.id).first()
        if not contract:
            contract = Contract(
                organization_id=org.id,
                title="Master Cloud Services Agreement — CloudScale Inc",
                contract_number="MSA-2026-8841",
                contract_type="Master Services Agreement",
                owner_id=user.id,
                department_id=dept.id,
                status="Active",
                risk_score=68.5,
                risk_level="HIGH",
                total_value=250000.0,
                currency="USD",
                effective_date=datetime.now(timezone.utc) - timedelta(days=60),
                expiry_date=datetime.now(timezone.utc) + timedelta(days=305),
                auto_renewal=True,
                notice_period_days=60,
                description="Enterprise Cloud Infrastructure & SLA Contract"
            )
            db.add(contract)
            db.commit()
            db.refresh(contract)

            version = ContractVersion(
                contract_id=contract.id,
                version_number=1,
                file_name="msa_cloudscale_v1.pdf",
                file_path="./uploads/msa_cloudscale_v1.pdf",
                file_size=1048576,
                document_type="pdf",
                uploaded_by_id=user.id,
                processing_status="Completed"
            )
            db.add(version)
            db.commit()
            db.refresh(version)

            clause1 = Clause(
                contract_id=contract.id,
                version_id=version.id,
                section_number="4.2",
                page_number=3,
                clause_type="Reporting",
                source_text="Vendor shall submit a quarterly compliance report within 10 business days following the end of each quarter.",
                confidence_score=0.96,
                risk_impact="MEDIUM"
            )
            db.add(clause1)

            clause2 = Clause(
                contract_id=contract.id,
                version_id=version.id,
                section_number="7.1",
                page_number=6,
                clause_type="SLA",
                source_text="Vendor must maintain 99.9% uptime for cloud infrastructure. Failure to maintain SLA incurs a 10% monthly billing penalty credit.",
                confidence_score=0.98,
                risk_impact="CRITICAL"
            )
            db.add(clause2)
            db.commit()

            ob1 = Obligation(
                organization_id=org.id,
                contract_id=contract.id,
                clause_id=clause1.id,
                obligation_type="Reporting",
                party="Vendor",
                action="Submit compliance report",
                object_target="Quarterly compliance report",
                deadline_expression="within 10 business days following the end of each quarter",
                frequency="Quarterly",
                condition="End of each fiscal quarter",
                penalty_summary="Late reporting triggers audit review",
                priority="HIGH",
                status="Upcoming",
                responsible_user_id=user.id,
                due_date=datetime.now(timezone.utc) + timedelta(days=14)
            )
            db.add(ob1)

            ob2 = Obligation(
                organization_id=org.id,
                contract_id=contract.id,
                clause_id=clause2.id,
                obligation_type="SLA",
                party="Vendor",
                action="Maintain 99.9% uptime",
                object_target="Cloud Infrastructure Service Level",
                deadline_expression="Continuous monthly monitoring",
                frequency="Monthly",
                condition="Active cloud environment",
                penalty_summary="10% monthly billing penalty credit",
                priority="CRITICAL",
                status="Due",
                responsible_user_id=user.id,
                due_date=datetime.now(timezone.utc) + timedelta(days=2)
            )
            db.add(ob2)
            db.commit()

            risk_score = RiskScore(
                contract_id=contract.id,
                overall_score=68.5,
                risk_level="HIGH",
                financial_risk=18.0,
                compliance_risk=22.0,
                deadline_risk=15.0,
                penalty_risk=22.0,
                renewal_risk=15.0,
                explanation_json={"explanation": "High risk driven by strict SLA penalty credits and 60-day auto-renewal notice period."}
            )
            db.add(risk_score)
            db.commit()

        print("Database seed completed successfully.")
    except Exception as e:
        db.rollback()
        print(f"Error seeding database: {str(e)}")
    finally:
        db.close()

if __name__ == "__main__":
    seed_database()
