"""
ObliGuard AI - NLP & Clause Intelligence Tests
"""

from app.nlp.clause_classifier import classifier_instance
from app.extraction.obligation_extractor import obligation_extractor

def test_clause_classification():
    # Test Payment Clause
    res1 = classifier_instance.classify_clause("Customer shall pay all invoices within 30 days of billing date.")
    assert res1["clause_type"] == "Payment"

    # Test Confidentiality Clause
    res2 = classifier_instance.classify_clause("Both parties agree to hold all proprietary trade secret information strictly confidential.")
    assert res2["clause_type"] == "Confidentiality"

    # Test SLA Clause
    res3 = classifier_instance.classify_clause("Vendor must maintain 99.9% uptime for cloud services.")
    assert res3["clause_type"] == "SLA"

def test_obligation_extraction():
    clause_text = "Vendor shall submit a quarterly compliance report within 10 business days following the end of each quarter."
    obligations = obligation_extractor.extract_obligations_from_clause(clause_text, "Reporting")

    assert len(obligations) == 1
    ob = obligations[0]
    assert ob["party"] == "Vendor"
    assert ob["obligation_type"] == "Reporting"
    assert "submit" in ob["action"].lower()
    assert "quarterly" in ob["frequency"].lower()
