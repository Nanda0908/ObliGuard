"""
ObliGuard AI - Temporal Intelligence Unit Tests
"""

from datetime import datetime, timezone
from app.temporal_engine.date_parser import temporal_engine
from app.temporal_engine.business_days import add_business_days

def test_business_days_calculation():
    base_date = datetime(2026, 9, 7)  # Monday
    # 5 business days from Monday should be next Monday (Sep 14)
    target_date = add_business_days(base_date, 5)
    assert target_date.day == 14

def test_resolve_deadline_expression():
    base_date = datetime(2026, 9, 7, tzinfo=timezone.utc)
    target_dt, is_biz = temporal_engine.resolve_deadline_expression("within 10 business days", base_date)
    assert is_biz is True
    assert target_dt > base_date
