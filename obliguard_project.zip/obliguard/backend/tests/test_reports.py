"""
ObliGuard AI - Executive Report Generator Unit Tests
"""

import os
from app.reporting.report_generator import generate_enterprise_report

def test_report_generation():
    sample_data = {
        "Total Contracts": 10,
        "Active Obligations": 25,
        "Compliance Rate": "94.2%",
        "High Risk Exposure": 2
    }

    pdf_path = generate_enterprise_report("Risk", "Acme Corp", sample_data, "PDF")
    assert os.path.exists(pdf_path)

    csv_path = generate_enterprise_report("Risk", "Acme Corp", sample_data, "CSV")
    assert os.path.exists(csv_path)

    json_path = generate_enterprise_report("Risk", "Acme Corp", sample_data, "JSON")
    assert os.path.exists(json_path)
