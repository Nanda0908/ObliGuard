"""
ObliGuard AI - Version Comparison Unit Tests
"""

from app.comparison.diff_engine import compare_contract_versions

def test_compare_contract_versions():
    v1_clauses = [
        {"section_number": "1.0", "clause_type": "Payment", "source_text": "Payment due in 30 days.", "risk_impact": "LOW"},
        {"section_number": "2.0", "clause_type": "Confidentiality", "source_text": "Confidentiality term is 3 years.", "risk_impact": "MEDIUM"}
    ]

    v2_clauses = [
        {"section_number": "1.0", "clause_type": "Payment", "source_text": "Payment due in 15 days.", "risk_impact": "HIGH"},
        {"section_number": "3.0", "clause_type": "Penalty", "source_text": "Late payment incurs 2% interest per month.", "risk_impact": "CRITICAL"}
    ]

    res = compare_contract_versions(v1_clauses, v2_clauses)
    assert res["total_modified"] == 1  # Sec 1.0 modified
    assert res["total_removed"] == 1   # Sec 2.0 removed
    assert res["total_added"] == 1     # Sec 3.0 added
