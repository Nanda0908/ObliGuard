"""
ObliGuard AI - Obligation Workflow Unit Tests
"""

import pytest
from app.workflow.state_machine import transition_obligation_status
from app.core.exceptions import WorkflowTransitionException

def test_valid_transitions():
    assert transition_obligation_status("Pending", "Upcoming") == "Upcoming"
    assert transition_obligation_status("Upcoming", "Due") == "Due"
    assert transition_obligation_status("Due", "Completed") == "Completed"

def test_invalid_transition_throws():
    with pytest.raises(WorkflowTransitionException):
        transition_obligation_status("Completed", "Pending")
