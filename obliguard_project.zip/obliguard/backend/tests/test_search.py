"""
ObliGuard AI - Semantic Search & RAG Assistant Unit Tests
"""

import pytest
from app.ai.vector_search import generate_embedding, cosine_similarity
from app.ai.rag_assistant import rag_assistant

def test_vector_embedding_generation():
    vec1 = generate_embedding("Vendor must maintain 99.9% uptime for cloud infrastructure.")
    vec2 = generate_embedding("Vendor shall ensure system availability meets SLA standard.")
    assert len(vec1) == 384
    assert len(vec2) == 384

    sim = cosine_similarity(vec1, vec2)
    assert sim > 0.0

def test_rag_assistant_grounded_answer():
    sample_retrieved = [
        {
            "contract_id": 1,
            "contract_title": "Master Services Agreement",
            "section_number": "4.2",
            "page_number": 3,
            "clause_type": "Reporting",
            "source_text": "Vendor shall submit a quarterly compliance report within 10 business days following the end of each quarter."
        }
    ]

    res = rag_assistant.generate_grounded_answer("What are reporting requirements?", sample_retrieved)
    assert res["is_grounded"] is True
    assert len(res["sources"]) == 1
    assert res["sources"][0]["contract_title"] == "Master Services Agreement"
