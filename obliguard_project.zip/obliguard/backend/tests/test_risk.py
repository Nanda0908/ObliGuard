"""
ObliGuard AI - Risk Intelligence Unit Tests
"""

from app.risk_engine.risk_calculator import evaluate_contract_risk

def test_evaluate_contract_risk():
    res = evaluate_contract_risk(
        contract_value=750000.0,
        has_penalty_clause=True,
        has_auto_renewal=True,
        notice_period_days=90,
        overdue_obligations_count=2
    )

    assert res["overall_score"] > 60.0
    assert res["risk_level"] in ["HIGH", "CRITICAL"]
    assert len(res["factors"]) >= 3
