"""
ObliGuard AI - Multi-Tenant Isolation Tests
Verifies strict data isolation between organizations.
"""

import pytest
from app.core.tenancy import TenantContext
from app.core.exceptions import TenantAccessDeniedException

def test_tenant_isolation_validation():
    tenant_a = TenantContext(organization_id=1, is_super_admin=False)
    tenant_b = TenantContext(organization_id=2, is_super_admin=False)

    # Valid same-tenant access
    tenant_a.validate_entity_tenant(1, "Contract")

    # Cross-tenant access must raise TenantAccessDeniedException
    with pytest.raises(TenantAccessDeniedException):
        tenant_a.validate_entity_tenant(2, "Contract")

    # Super admin bypass
    super_admin = TenantContext(organization_id=1, is_super_admin=True)
    super_admin.validate_entity_tenant(2, "Contract")  # Should pass without exception
