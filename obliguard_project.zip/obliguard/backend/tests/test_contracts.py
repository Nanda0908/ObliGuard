"""
ObliGuard AI - Contract Lifecycle Integration Tests
"""

import pytest

def test_contract_crud_flow(client, auth_headers):
    # 1. Create/Upload Contract via API
    create_res = client.post(
        "/api/v1/contracts/upload",
        headers=auth_headers,
        data={
            "title": "Vendor SLA Agreement — TechCorp",
            "contract_type": "Vendor Agreement",
            "total_value": "150000.0",
            "currency": "USD"
        },
        files={
            "file": ("vendor_sla.txt", b"Vendor shall submit monthly uptime reports within 5 business days of month end.", "text/plain")
        }
    )
    assert create_res.status_code == 201
    contract_data = create_res.json()
    assert contract_data["title"] == "Vendor SLA Agreement — TechCorp"
    contract_id = contract_data["id"]

    # 2. Get Contract Detail
    get_res = client.get(f"/api/v1/contracts/{contract_id}", headers=auth_headers)
    assert get_res.status_code == 200
    assert get_res.json()["id"] == contract_id

    # 3. Update Contract
    update_res = client.put(
        f"/api/v1/contracts/{contract_id}",
        headers=auth_headers,
        json={"title": "Updated Vendor SLA Agreement — TechCorp", "status": "Active"}
    )
    assert update_res.status_code == 200
    assert update_res.json()["title"] == "Updated Vendor SLA Agreement — TechCorp"

    # 4. List Contracts
    list_res = client.get("/api/v1/contracts", headers=auth_headers)
    assert list_res.status_code == 200
    assert len(list_res.json()) >= 1
