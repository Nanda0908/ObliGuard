"""
ObliGuard AI - Authentication API Unit Tests
"""

import pytest

def test_register_and_login(client):
    # Register new user
    reg_response = client.post("/api/v1/auth/register", json={
        "email": "test_admin@globex.com",
        "password": "Password123!",
        "full_name": "Test Org Admin",
        "organization_name": "Globex Corporation"
    })
    assert reg_response.status_code == 201
    data = reg_response.json()
    assert "access_token" in data
    assert data["role"] == "Organization Admin"

    # Login user
    login_response = client.post("/api/v1/auth/login", json={
        "email": "test_admin@globex.com",
        "password": "Password123!"
    })
    assert login_response.status_code == 200
    token_data = login_response.json()
    assert token_data["access_token"] == data["access_token"]
