"""
ObliGuard AI - ORM Models Package
Imports all SQLAlchemy models to register them with Declarative Base.
"""

from app.database import Base
from app.models.organization import Organization, Department
from app.models.user import User, Role, Permission, UserRole
from app.models.contract import Contract, ContractVersion, ContractParty, DocumentChunk
from app.models.clause import Clause, ClauseType
from app.models.obligation import Obligation, ObligationAssignment
from app.models.temporal import Deadline, Reminder, Escalation
from app.models.risk import RiskScore, RiskFactor, RiskEvent, RiskHistory
from app.models.compliance import ComplianceCheck, Violation, Penalty
from app.models.ai import Embedding
from app.models.notification import Notification, NotificationPreference
from app.models.workflow import Workflow, WorkflowTask
from app.models.audit import AuditLog
from app.models.saas import Subscription, UsageRecord
from app.models.report import Report
from app.models.setting import SystemSetting

__all__ = [
    "Base",
    "Organization", "Department",
    "User", "Role", "Permission", "UserRole",
    "Contract", "ContractVersion", "ContractParty", "DocumentChunk",
    "Clause", "ClauseType",
    "Obligation", "ObligationAssignment",
    "Deadline", "Reminder", "Escalation",
    "RiskScore", "RiskFactor", "RiskEvent", "RiskHistory",
    "ComplianceCheck", "Violation", "Penalty",
    "Embedding",
    "Notification", "NotificationPreference",
    "Workflow", "WorkflowTask",
    "AuditLog",
    "Subscription", "UsageRecord",
    "Report",
    "SystemSetting"
]
