"""
ObliGuard AI - Temporal Intelligence Models
Deadlines, reminder schedules, and SLA escalation tracking.
"""

from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.database import Base

class Deadline(Base):
    __tablename__ = "deadlines"

    id = Column(Integer, primary_key=True, index=True)
    obligation_id = Column(Integer, ForeignKey("obligations.id", ondelete="CASCADE"), nullable=False, index=True)
    deadline_date = Column(DateTime, nullable=False, index=True)
    original_expression = Column(String(255), nullable=True)
    is_business_days = Column(Boolean, default=False)
    recurring_rule = Column(String(100), nullable=True)  # rrule or interval expression
    is_completed = Column(Boolean, default=False)
    completed_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)

    obligation = relationship("Obligation", back_populates="deadlines")
    reminders = relationship("Reminder", back_populates="deadline", cascade="all, delete-orphan")

class Reminder(Base):
    __tablename__ = "reminders"

    id = Column(Integer, primary_key=True, index=True)
    deadline_id = Column(Integer, ForeignKey("deadlines.id", ondelete="CASCADE"), nullable=False, index=True)
    obligation_id = Column(Integer, ForeignKey("obligations.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    days_before = Column(Integer, nullable=False, default=7)
    scheduled_date = Column(DateTime, nullable=False, index=True)
    sent_at = Column(DateTime(timezone=True), nullable=True)
    is_sent = Column(Boolean, default=False)

    deadline = relationship("Deadline", back_populates="reminders")

class Escalation(Base):
    __tablename__ = "escalations"

    id = Column(Integer, primary_key=True, index=True)
    obligation_id = Column(Integer, ForeignKey("obligations.id", ondelete="CASCADE"), nullable=False, index=True)
    level = Column(Integer, default=1, nullable=False)  # 1 = Manager, 2 = Dept Head, 3 = Legal Director
    escalated_to_user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    reason = Column(Text, nullable=False)
    status = Column(String(50), default="Active")  # Active, Resolved, Dismissed
    triggered_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
