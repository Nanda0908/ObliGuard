"""
ObliGuard AI - System Setting Model
Organization and platform-wide configuration settings.
"""

from sqlalchemy import Column, Integer, String, Text, ForeignKey
from app.database import Base

class SystemSetting(Base):
    __tablename__ = "system_settings"

    id = Column(Integer, primary_key=True, index=True)
    organization_id = Column(Integer, ForeignKey("organizations.id", ondelete="CASCADE"), nullable=True, index=True)
    setting_key = Column(String(100), nullable=False, index=True)
    setting_value = Column(Text, nullable=False)
    category = Column(String(50), default="General")
    description = Column(Text, nullable=True)
