"""
ObliGuard AI - Risk Intelligence Models
Multi-dimensional risk metrics, factor breakdowns, events, and dynamic history.
"""

from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Text, JSON
from sqlalchemy.orm import relationship
from app.database import Base

class RiskScore(Base):
    __tablename__ = "risk_scores"

    id = Column(Integer, primary_key=True, index=True)
    contract_id = Column(Integer, ForeignKey("contracts.id", ondelete="CASCADE"), nullable=False, index=True)
    overall_score = Column(Float, nullable=False, default=0.0)  # 0 to 100
    risk_level = Column(String(20), nullable=False, default="LOW")  # LOW (0-30), MEDIUM (31-60), HIGH (61-80), CRITICAL (81-100)
    
    financial_risk = Column(Float, default=0.0)
    compliance_risk = Column(Float, default=0.0)
    deadline_risk = Column(Float, default=0.0)
    penalty_risk = Column(Float, default=0.0)
    renewal_risk = Column(Float, default=0.0)
    operational_risk = Column(Float, default=0.0)
    legal_risk = Column(Float, default=0.0)
    security_risk = Column(Float, default=0.0)
    
    explanation_json = Column(JSON, default=dict)
    calculated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)

    contract = relationship("Contract", back_populates="risk_scores")
    factors = relationship("RiskFactor", back_populates="risk_score", cascade="all, delete-orphan")

class RiskFactor(Base):
    __tablename__ = "risk_factors"

    id = Column(Integer, primary_key=True, index=True)
    risk_score_id = Column(Integer, ForeignKey("risk_scores.id", ondelete="CASCADE"), nullable=False, index=True)
    dimension = Column(String(50), nullable=False)  # Financial, Penalty, Renewal, SLA, etc.
    factor_name = Column(String(255), nullable=False)
    weight = Column(Float, default=1.0)
    score_contribution = Column(Float, default=0.0)
    description = Column(Text, nullable=True)
    clause_id = Column(Integer, ForeignKey("clauses.id", ondelete="SET NULL"), nullable=True)

    risk_score = relationship("RiskScore", back_populates="factors")

class RiskEvent(Base):
    __tablename__ = "risk_events"

    id = Column(Integer, primary_key=True, index=True)
    organization_id = Column(Integer, ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True)
    contract_id = Column(Integer, ForeignKey("contracts.id", ondelete="CASCADE"), nullable=False, index=True)
    obligation_id = Column(Integer, ForeignKey("obligations.id", ondelete="SET NULL"), nullable=True)
    
    event_type = Column(String(100), nullable=False)  # Missed Obligation, Penalty Triggered, SLA Breach, Renewal Approaching
    impact_score = Column(Float, default=0.0)
    description = Column(Text, nullable=False)
    occurred_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)

class RiskHistory(Base):
    __tablename__ = "risk_history"

    id = Column(Integer, primary_key=True, index=True)
    contract_id = Column(Integer, ForeignKey("contracts.id", ondelete="CASCADE"), nullable=False, index=True)
    score = Column(Float, nullable=False)
    risk_level = Column(String(20), nullable=False)
    change_reason = Column(String(255), nullable=True)
    recorded_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
