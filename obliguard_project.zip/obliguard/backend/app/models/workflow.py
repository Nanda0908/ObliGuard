"""
ObliGuard AI - Workflow & Task Models
Workflow execution pipelines and task assignments.
"""

from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Text
from app.database import Base

class Workflow(Base):
    __tablename__ = "workflows"

    id = Column(Integer, primary_key=True, index=True)
    organization_id = Column(Integer, ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(255), nullable=False)
    entity_type = Column(String(50), nullable=False)  # Obligation, Contract, Violation
    is_active = Column(Boolean, default=True)

class WorkflowTask(Base):
    __tablename__ = "workflow_tasks"

    id = Column(Integer, primary_key=True, index=True)
    workflow_id = Column(Integer, ForeignKey("workflows.id", ondelete="CASCADE"), nullable=False, index=True)
    entity_id = Column(Integer, nullable=False)
    step_name = Column(String(100), nullable=False)
    status = Column(String(50), default="Pending")  # Pending, In Progress, Completed, Failed
    assigned_user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    due_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime(timezone=True), nullable=True)
