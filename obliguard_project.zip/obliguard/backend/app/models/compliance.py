"""
ObliGuard AI - Compliance Engine Models
Compliance checks, violations tracking, and penalty exposures.
"""

from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.database import Base

class ComplianceCheck(Base):
    __tablename__ = "compliance_checks"

    id = Column(Integer, primary_key=True, index=True)
    organization_id = Column(Integer, ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True)
    obligation_id = Column(Integer, ForeignKey("obligations.id", ondelete="CASCADE"), nullable=False, index=True)
    checked_by_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    status = Column(String(50), nullable=False)  # Pass, Fail, Waived, Partial
    notes = Column(Text, nullable=True)
    verified_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)

    obligation = relationship("Obligation", back_populates="compliance_checks")

class Violation(Base):
    __tablename__ = "violations"

    id = Column(Integer, primary_key=True, index=True)
    organization_id = Column(Integer, ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True)
    obligation_id = Column(Integer, ForeignKey("obligations.id", ondelete="CASCADE"), nullable=False, index=True)
    contract_id = Column(Integer, ForeignKey("contracts.id", ondelete="CASCADE"), nullable=False, index=True)
    severity = Column(String(20), default="HIGH", nullable=False)  # LOW, MEDIUM, HIGH, CRITICAL
    violation_type = Column(String(100), nullable=False)  # Missed Deadline, Incomplete Deliverable, Non-Payment, SLA Breach
    penalty_amount = Column(Float, default=0.0)
    notes = Column(Text, nullable=True)
    status = Column(String(50), default="Open")  # Open, Under Review, Resolved, Escalated
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)

    obligation = relationship("Obligation", back_populates="violations")

class Penalty(Base):
    __tablename__ = "penalties"

    id = Column(Integer, primary_key=True, index=True)
    contract_id = Column(Integer, ForeignKey("contracts.id", ondelete="CASCADE"), nullable=False, index=True)
    obligation_id = Column(Integer, ForeignKey("obligations.id", ondelete="SET NULL"), nullable=True)
    penalty_type = Column(String(100), nullable=False)  # Financial Penalty, Interest, Contract Termination, SLA Credit
    amount = Column(Float, default=0.0, nullable=False)
    currency = Column(String(10), default="USD")
    description = Column(Text, nullable=True)
