"""
ObliGuard AI - Clause Intelligence Models
Clause classification, section mapping, and confidence scores.
"""

from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.database import Base

class ClauseType(Base):
    __tablename__ = "clause_types"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, nullable=False)
    category = Column(String(100), nullable=False)
    default_risk_weight = Column(Float, default=1.0)
    description = Column(Text, nullable=True)

class Clause(Base):
    __tablename__ = "clauses"

    id = Column(Integer, primary_key=True, index=True)
    contract_id = Column(Integer, ForeignKey("contracts.id", ondelete="CASCADE"), nullable=False, index=True)
    version_id = Column(Integer, ForeignKey("contract_versions.id", ondelete="CASCADE"), nullable=False, index=True)
    
    section_number = Column(String(50), nullable=True)
    page_number = Column(Integer, nullable=True)
    clause_type = Column(String(100), nullable=False, index=True)  # Payment, Termination, Liability, Indemnity, etc.
    
    source_text = Column(Text, nullable=False)
    normalized_text = Column(Text, nullable=True)
    confidence_score = Column(Float, default=0.95, nullable=False)
    risk_impact = Column(String(20), default="MEDIUM")  # LOW, MEDIUM, HIGH, CRITICAL
    
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)

    contract = relationship("Contract", back_populates="clauses")
    version = relationship("ContractVersion", back_populates="clauses")
    obligations = relationship("Obligation", back_populates="clause", cascade="all, delete-orphan")
