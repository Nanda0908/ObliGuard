"""
ObliGuard AI - AI Embeddings Model
Stores dense vector representations for document chunks and clauses.
Supports both pgvector and JSON storage fallback for SQLite.
"""

from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, JSON
from app.database import Base

class Embedding(Base):
    __tablename__ = "embeddings"

    id = Column(Integer, primary_key=True, index=True)
    document_chunk_id = Column(Integer, ForeignKey("document_chunks.id", ondelete="CASCADE"), nullable=True, index=True)
    clause_id = Column(Integer, ForeignKey("clauses.id", ondelete="CASCADE"), nullable=True, index=True)
    model_name = Column(String(100), default="sentence-transformers/all-MiniLM-L6-v2", nullable=False)
    vector_json = Column(JSON, nullable=False)  # List of floats representing dense vector embedding
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
