"""
ObliGuard AI - Obligation Intelligence Models
Extracts, structures, and manages contractual obligations.
"""

from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.database import Base

class Obligation(Base):
    __tablename__ = "obligations"

    id = Column(Integer, primary_key=True, index=True)
    organization_id = Column(Integer, ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True)
    contract_id = Column(Integer, ForeignKey("contracts.id", ondelete="CASCADE"), nullable=False, index=True)
    clause_id = Column(Integer, ForeignKey("clauses.id", ondelete="SET NULL"), nullable=True, index=True)
    
    obligation_type = Column(String(100), nullable=False, index=True)  # Reporting, Payment, Audit, Delivery, SLA, Notice, Compliance
    party = Column(String(255), nullable=False)  # Responsible party (e.g. Vendor, Client, Licensee)
    action = Column(String(255), nullable=False)  # Action to be performed (e.g. Submit report, Pay invoice)
    object_target = Column(Text, nullable=True)  # Object or topic of obligation
    
    deadline_expression = Column(String(255), nullable=True)  # Original text: "within 10 business days"
    frequency = Column(String(50), default="One-Time")  # One-Time, Daily, Weekly, Monthly, Quarterly, Annually
    condition = Column(Text, nullable=True)  # Conditional logic trigger
    penalty_summary = Column(Text, nullable=True)  # Financial or contractual penalty for non-performance
    
    priority = Column(String(20), default="MEDIUM", nullable=False)  # LOW, MEDIUM, HIGH, CRITICAL
    status = Column(String(50), default="Pending", nullable=False, index=True)  # Pending, Upcoming, Due, Completed, Overdue, Escalated, Waived, Cancelled
    
    responsible_user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    department_id = Column(Integer, ForeignKey("departments.id", ondelete="SET NULL"), nullable=True)
    
    due_date = Column(DateTime, nullable=True, index=True)
    notice_deadline = Column(DateTime, nullable=True)
    confidence_score = Column(Float, default=0.90, nullable=False)
    
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc), nullable=False)

    contract = relationship("Contract", back_populates="obligations")
    clause = relationship("Clause", back_populates="obligations")
    responsible_user = relationship("User", back_populates="assigned_obligations")
    deadlines = relationship("Deadline", back_populates="obligation", cascade="all, delete-orphan")
    assignments = relationship("ObligationAssignment", back_populates="obligation", cascade="all, delete-orphan")
    compliance_checks = relationship("ComplianceCheck", back_populates="obligation", cascade="all, delete-orphan")
    violations = relationship("Violation", back_populates="obligation", cascade="all, delete-orphan")

class ObligationAssignment(Base):
    __tablename__ = "obligation_assignments"

    id = Column(Integer, primary_key=True, index=True)
    obligation_id = Column(Integer, ForeignKey("obligations.id", ondelete="CASCADE"), nullable=False, index=True)
    assigned_user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    assigned_by_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    assigned_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)

    obligation = relationship("Obligation", back_populates="assignments")
