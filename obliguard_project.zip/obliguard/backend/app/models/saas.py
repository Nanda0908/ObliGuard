"""
ObliGuard AI - SaaS Subscription & Usage Models
Tier plan status, quota limits, and usage tracking records.
"""

from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Float
from sqlalchemy.orm import relationship
from app.database import Base

class Subscription(Base):
    __tablename__ = "subscriptions"

    id = Column(Integer, primary_key=True, index=True)
    organization_id = Column(Integer, ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True)
    plan_tier = Column(String(50), nullable=False, default="FREE")  # FREE, PROFESSIONAL, ENTERPRISE
    status = Column(String(50), nullable=False, default="Active")  # Active, Past Due, Canceled
    max_contracts = Column(Integer, default=10)
    max_users = Column(Integer, default=5)
    max_storage_mb = Column(Integer, default=500)
    expires_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)

    organization = relationship("Organization", back_populates="subscriptions")

class UsageRecord(Base):
    __tablename__ = "usage_records"

    id = Column(Integer, primary_key=True, index=True)
    organization_id = Column(Integer, ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True)
    metric_name = Column(String(100), nullable=False)  # contracts_count, users_count, ai_queries_count, storage_bytes
    current_value = Column(Float, default=0.0)
    period_start = Column(DateTime, nullable=False)
    period_end = Column(DateTime, nullable=False)
