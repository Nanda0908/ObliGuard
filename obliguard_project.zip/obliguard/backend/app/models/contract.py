"""
ObliGuard AI - Contract & Document Models
Stores contract metadata, version history, document metadata, chunks and parties.
"""

from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Text, JSON
from sqlalchemy.orm import relationship
from app.database import Base

class Contract(Base):
    __tablename__ = "contracts"

    id = Column(Integer, primary_key=True, index=True)
    organization_id = Column(Integer, ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True)
    title = Column(String(255), nullable=False, index=True)
    contract_number = Column(String(100), nullable=True, index=True)
    contract_type = Column(String(100), nullable=False, default="Master Services Agreement")  # MSA, NDA, SLA, Vendor, Employment, etc.
    department_id = Column(Integer, ForeignKey("departments.id", ondelete="SET NULL"), nullable=True)
    owner_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    
    status = Column(String(50), nullable=False, default="Draft")  # Draft, Active, Expiring, Expired, Terminated, Archived
    risk_score = Column(Float, default=0.0, nullable=False)
    risk_level = Column(String(20), default="LOW", nullable=False)  # LOW, MEDIUM, HIGH, CRITICAL
    
    total_value = Column(Float, nullable=True)
    currency = Column(String(10), default="USD")
    
    effective_date = Column(DateTime, nullable=True)
    expiry_date = Column(DateTime, nullable=True)
    renewal_date = Column(DateTime, nullable=True)
    auto_renewal = Column(Boolean, default=False)
    notice_period_days = Column(Integer, default=30)
    
    description = Column(Text, nullable=True)
    tags_json = Column(JSON, default=list)
    
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc), nullable=False)

    organization = relationship("Organization", back_populates="contracts")
    versions = relationship("ContractVersion", back_populates="contract", cascade="all, delete-orphan", order_by="desc(ContractVersion.version_number)")
    parties = relationship("ContractParty", back_populates="contract", cascade="all, delete-orphan")
    clauses = relationship("Clause", back_populates="contract", cascade="all, delete-orphan")
    obligations = relationship("Obligation", back_populates="contract", cascade="all, delete-orphan")
    risk_scores = relationship("RiskScore", back_populates="contract", cascade="all, delete-orphan")

class ContractVersion(Base):
    __tablename__ = "contract_versions"

    id = Column(Integer, primary_key=True, index=True)
    contract_id = Column(Integer, ForeignKey("contracts.id", ondelete="CASCADE"), nullable=False, index=True)
    version_number = Column(Integer, nullable=False, default=1)
    file_name = Column(String(255), nullable=False)
    file_path = Column(String(500), nullable=False)
    file_hash = Column(String(128), nullable=True)
    file_size = Column(Integer, nullable=False)
    document_type = Column(String(20), nullable=False)  # pdf, docx, txt
    is_active_version = Column(Boolean, default=True)
    uploaded_by_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    
    processing_status = Column(String(50), default="Uploaded")  # Uploaded, Queued, Processing, OCR, Extracted, Classified, Completed, Failed
    processing_error = Column(Text, nullable=True)
    
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)

    contract = relationship("Contract", back_populates="versions")
    chunks = relationship("DocumentChunk", back_populates="version", cascade="all, delete-orphan")
    clauses = relationship("Clause", back_populates="version", cascade="all, delete-orphan")

class ContractParty(Base):
    __tablename__ = "contract_parties"

    id = Column(Integer, primary_key=True, index=True)
    contract_id = Column(Integer, ForeignKey("contracts.id", ondelete="CASCADE"), nullable=False, index=True)
    party_name = Column(String(255), nullable=False)
    party_type = Column(String(50), default="Vendor")  # Vendor, Client, Partner, Employer, Contractor
    role_in_contract = Column(String(100), nullable=True)
    contact_email = Column(String(255), nullable=True)
    contact_phone = Column(String(50), nullable=True)

    contract = relationship("Contract", back_populates="parties")

class DocumentChunk(Base):
    __tablename__ = "document_chunks"

    id = Column(Integer, primary_key=True, index=True)
    version_id = Column(Integer, ForeignKey("contract_versions.id", ondelete="CASCADE"), nullable=False, index=True)
    chunk_index = Column(Integer, nullable=False)
    page_number = Column(Integer, nullable=True)
    section_title = Column(String(255), nullable=True)
    content = Column(Text, nullable=False)
    embedding_id = Column(Integer, ForeignKey("embeddings.id", ondelete="SET NULL"), nullable=True)

    version = relationship("ContractVersion", back_populates="chunks")
