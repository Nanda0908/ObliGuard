"""
ObliGuard AI - Contract Version Comparison & Diff Engine
Compares two contract document versions to detect added, removed, and modified clauses,
evaluating overall risk impact and obligation changes.
"""

from typing import List, Dict, Any

def compare_contract_versions(
    version_1_clauses: List[Dict[str, Any]],
    version_2_clauses: List[Dict[str, Any]]
) -> Dict[str, Any]:
    """
    Perform structural and semantic diff between Version 1 and Version 2 clauses.
    """
    v1_map = {c.get("section_number", f"s_{i}"): c for i, c in enumerate(version_1_clauses)}
    v2_map = {c.get("section_number", f"s_{i}"): c for i, c in enumerate(version_2_clauses)}

    clause_diffs = []
    total_added = 0
    total_removed = 0
    total_modified = 0

    all_sections = set(v1_map.keys()).union(set(v2_map.keys()))

    for sec in sorted(list(all_sections)):
        c1 = v1_map.get(sec)
        c2 = v2_map.get(sec)

        if c1 and not c2:
            total_removed += 1
            clause_diffs.append({
                "change_type": "REMOVED",
                "clause_type": c1.get("clause_type", "General"),
                "section_number": sec,
                "old_text": c1.get("source_text", ""),
                "new_text": None,
                "risk_impact": c1.get("risk_impact", "MEDIUM")
            })
        elif not c1 and c2:
            total_added += 1
            clause_diffs.append({
                "change_type": "ADDED",
                "clause_type": c2.get("clause_type", "General"),
                "section_number": sec,
                "old_text": None,
                "new_text": c2.get("source_text", ""),
                "risk_impact": c2.get("risk_impact", "MEDIUM")
            })
        else:
            t1 = c1.get("source_text", "").strip()
            t2 = c2.get("source_text", "").strip()
            if t1 != t2:
                total_modified += 1
                clause_diffs.append({
                    "change_type": "MODIFIED",
                    "clause_type": c2.get("clause_type", "General"),
                    "section_number": sec,
                    "old_text": t1,
                    "new_text": t2,
                    "risk_impact": c2.get("risk_impact", "MEDIUM")
                })

    summary = f"Comparison complete: {total_added} added, {total_removed} removed, {total_modified} modified clause(s)."
    risk_delta = (total_added * 2.5) - (total_removed * 1.5)

    return {
        "summary_of_changes": summary,
        "total_added": total_added,
        "total_removed": total_removed,
        "total_modified": total_modified,
        "clause_diffs": clause_diffs,
        "risk_delta": round(risk_delta, 1),
        "obligation_impact_summary": f"Detected {total_added + total_modified} clause changes affecting contractual obligations."
    }
