"""
ObliGuard AI - International Corporate Holiday Calendars Database
Provides working day calculation rules and holiday calendars for global business jurisdictions.
"""

from typing import Dict, List, Tuple

JURISDICTION_HOLIDAYS: Dict[str, List[Tuple[int, int, str]]] = {
    "US": [
        (1, 1, "New Year's Day"),
        (1, 15, "Martin Luther King Jr. Day"),
        (2, 19, "Presidents' Day"),
        (5, 27, "Memorial Day"),
        (6, 19, "Juneteenth"),
        (7, 4, "Independence Day"),
        (9, 2, "Labor Day"),
        (10, 14, "Columbus Day"),
        (11, 11, "Veterans Day"),
        (11, 28, "Thanksgiving Day"),
        (12, 25, "Christmas Day")
    ],
    "UK": [
        (1, 1, "New Year's Day"),
        (3, 29, "Good Friday"),
        (4, 1, "Easter Monday"),
        (5, 6, "Early May Bank Holiday"),
        (5, 27, "Spring Bank Holiday"),
        (8, 26, "Summer Bank Holiday"),
        (12, 25, "Christmas Day"),
        (12, 26, "Boxing Day")
    ],
    "EU": [
        (1, 1, "New Year's Day"),
        (5, 1, "Labor Day"),
        (5, 9, "Europe Day"),
        (11, 1, "All Saints' Day"),
        (12, 25, "Christmas Day"),
        (12, 26, "St. Stephen's Day")
    ],
    "DE": [
        (1, 1, "Neujahr"),
        (5, 1, "Tag der Arbeit"),
        (10, 3, "Tag der Deutschen Einheit"),
        (12, 25, "Erster Weihnachtstag"),
        (12, 26, "Zweiter Weihnachtstag")
    ],
    "JP": [
        (1, 1, "Gantan (New Year's Day)"),
        (1, 8, "Seijin no Hi"),
        (2, 11, "Kenkoku Kinen no Hi"),
        (2, 23, "Tenno Tanjobi"),
        (4, 29, "Showa no Hi"),
        (5, 3, "Kenpo Kinenbi"),
        (5, 4, "Midori no Hi"),
        (5, 5, "Kodomo no Hi"),
        (11, 3, "Bunka no Hi"),
        (11, 23, "Kinro Kansha no Hi")
    ]
}

def get_holidays_for_jurisdiction(country_code: str = "US") -> List[Tuple[int, int]]:
    """Retrieve month-day tuples for specified country code."""
    holidays = JURISDICTION_HOLIDAYS.get(country_code.upper(), JURISDICTION_HOLIDAYS["US"])
    return [(m, d) for m, d, _ in holidays]
