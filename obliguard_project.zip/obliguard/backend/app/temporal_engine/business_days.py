"""
ObliGuard AI - Business Days & Holiday Calendar Engine
Calculates working days excluding weekends (Saturday/Sunday) and custom holidays.
"""

from datetime import datetime, timedelta
from typing import List, Optional

# Default Corporate Holidays (New Year's Day, Independence Day, Christmas, etc.)
DEFAULT_HOLIDAYS = [
    (1, 1),    # Jan 1 - New Year
    (7, 4),    # Jul 4 - Independence Day
    (12, 25),  # Dec 25 - Christmas
    (12, 31)   # Dec 31 - New Year's Eve
]

def add_business_days(
    start_date: datetime,
    num_days: int,
    custom_holidays: Optional[List[datetime]] = None
) -> datetime:
    """Add N business days to start_date, skipping weekends and holidays."""
    current_date = start_date
    added_days = 0
    
    holidays_set = set()
    if custom_holidays:
        for h in custom_holidays:
            holidays_set.add((h.month, h.day))
    else:
        for h in DEFAULT_HOLIDAYS:
            holidays_set.add(h)

    while added_days < num_days:
        current_date += timedelta(days=1)
        # Saturday is 5, Sunday is 6
        if current_date.weekday() in (5, 6):
            continue
        if (current_date.month, current_date.day) in holidays_set:
            continue
        added_days += 1
        
    return current_date

def calculate_notice_deadline(expiry_date: datetime, notice_days: int) -> datetime:
    """Calculate last valid date to issue non-renewal or termination notice prior to expiration."""
    return expiry_date - timedelta(days=notice_days)
