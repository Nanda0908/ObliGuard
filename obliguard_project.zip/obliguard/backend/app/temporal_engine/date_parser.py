"""
ObliGuard AI - Temporal Date Parser Engine
Converts natural language contractual deadline expressions into concrete machine-processable datetime rules.
Uses Python standard library with dateutil fallback.
"""

import re
from datetime import datetime, timedelta, timezone
from typing import Optional, Tuple
from app.temporal_engine.business_days import add_business_days

class TemporalEngine:
    """Parses relative, absolute, business day, and recurring deadline expressions."""

    def resolve_deadline_expression(
        self,
        expression: str,
        base_date: Optional[datetime] = None
    ) -> Tuple[datetime, bool]:
        """
        Parse expression into (calculated_datetime, is_business_days).
        """
        if not base_date:
            base_date = datetime.now(timezone.utc)

        if not expression:
            return base_date + timedelta(days=30), False

        expr_clean = expression.strip()
        is_business_days = "business day" in expr_clean.lower()

        # Match "within N business days" or "within N days"
        rel_match = re.search(r"within\s+(\d+)\s*(business\s+days|calendar\s+days|days)", expr_clean, re.IGNORECASE)
        if rel_match:
            num_days = int(rel_match.group(1))
            if is_business_days:
                target_date = add_business_days(base_date, num_days)
            else:
                target_date = base_date + timedelta(days=num_days)
            return target_date, is_business_days

        # Match "N days after/following"
        after_match = re.search(r"(\d+)\s*days\s+(?:after|following)", expr_clean, re.IGNORECASE)
        if after_match:
            num_days = int(after_match.group(1))
            if is_business_days:
                target_date = add_business_days(base_date, num_days)
            else:
                target_date = base_date + timedelta(days=num_days)
            return target_date, is_business_days

        # Try dateutil if available
        try:
            from dateutil import parser as date_parser
            parsed_dt = date_parser.parse(expr_clean, fuzzy=True)
            return parsed_dt, False
        except Exception:
            pass

        return base_date + timedelta(days=14), False

    def compute_next_recurring_date(self, current_due_date: datetime, frequency: str) -> datetime:
        """Calculate next due date for recurring obligation schedules."""
        freq_lower = frequency.lower()
        if "daily" in freq_lower:
            return current_due_date + timedelta(days=1)
        elif "weekly" in freq_lower:
            return current_due_date + timedelta(days=7)
        elif "monthly" in freq_lower or "each month" in freq_lower:
            return current_due_date + timedelta(days=30)
        elif "quarterly" in freq_lower or "each quarter" in freq_lower:
            return current_due_date + timedelta(days=90)
        elif "annually" in freq_lower or "yearly" in freq_lower:
            return current_due_date + timedelta(days=365)
        
        return current_due_date + timedelta(days=30)

temporal_engine = TemporalEngine()
