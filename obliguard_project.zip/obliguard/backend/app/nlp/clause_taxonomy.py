"""
ObliGuard AI - Exhaustive Clause Taxonomy & Pre-trained Feature Dictionaries
Contains extensive legal clause patterns, regulatory mappings, and classification feature dictionaries for 22 clause categories.
"""

from typing import Dict, List, Any

CLAUSE_TAXONOMY_CATALOG: Dict[str, Dict[str, Any]] = {
    "Payment": {
        "category_id": "CT-01",
        "description": "Stipulates payment terms, fees, invoicing schedules, taxes, and late payment interest rates.",
        "keywords": [
            "payment", "fee", "price", "invoice", "remit", "remittance", "billing", "compensation", "reimburse",
            "net 30", "net 60", "net 90", "late fee", "interest rate", "wire transfer", "currency", "sales tax", "vat",
            "withholding tax", "undisputed fees", "advance payment", "milestone payment", "retainer", "per diem",
            "expenses", "travel expenses", "out of pocket", "due date", "payment schedule", "price adjustment"
        ],
        "risk_impact": "HIGH",
        "sample_clauses": [
            "Customer shall pay all undisputed invoices within thirty (30) days of receipt.",
            "Late payments shall accrue interest at a rate of 1.5% per month or the maximum rate permitted by law.",
            "All fees are exclusive of applicable sales, use, VAT, and excise taxes."
        ]
    },
    "Termination": {
        "category_id": "CT-02",
        "description": "Governs contract termination conditions, for-cause breach cures, and for-convenience notice periods.",
        "keywords": [
            "terminate", "termination", "cancel", "cancellation", "cure period", "material breach", "expire",
            "expiration", "without cause", "for convenience", "written notice", "immediate termination", "insolvency",
            "bankruptcy", "dissolution", "wind down", "survival", "surviving provisions", "transition period"
        ],
        "risk_impact": "HIGH",
        "sample_clauses": [
            "Either party may terminate this Agreement for material breach upon thirty (30) days prior written notice.",
            "Customer may terminate this Agreement for convenience at any time upon sixty (60) days written notice.",
            "Upon termination, Customer shall immediately cease all use of the Service and return all Confidential Information."
        ]
    },
    "Renewal": {
        "category_id": "CT-03",
        "description": "Defines contract term extensions, automatic renewal commitments, and non-renewal notice windows.",
        "keywords": [
            "renew", "renewal", "extension", "auto-renew", "automatic renewal", "successive term", "renewal term",
            "notice of non-renewal", "prior written notice", "initial term", "renewal period", "price increase upon renewal"
        ],
        "risk_impact": "MEDIUM",
        "sample_clauses": [
            "This Agreement shall automatically renew for successive one-year terms unless either party gives notice of non-renewal.",
            "Notice of non-renewal must be provided in writing at least sixty (60) days prior to the expiration of the current term."
        ]
    },
    "Confidentiality": {
        "category_id": "CT-04",
        "description": "Protects proprietary information, trade secrets, non-disclosure requirements, and exclusion exceptions.",
        "keywords": [
            "confidential", "confidentiality", "proprietary", "trade secret", "nondisclosure", "nda", "disclosing party",
            "receiving party", "permitted use", "standard of care", "compelled disclosure", "court order", "injunctive relief"
        ],
        "risk_impact": "MEDIUM",
        "sample_clauses": [
            "The receiving party agrees to protect the disclosing party's Confidential Information using the same degree of care.",
            "Confidential Information shall not include information that is or becomes publicly known through no fault of receiving party."
        ]
    },
    "Liability": {
        "category_id": "CT-05",
        "description": "Defines limitation of liability caps, exclusions of consequential damages, and liability carve-outs.",
        "keywords": [
            "limitation of liability", "liable", "consequential damages", "indirect damages", "maximum liability",
            "aggregate liability", "cap on liability", "punitive damages", "loss of profits", "loss of revenue",
            "carve-out", "gross negligence", "willful misconduct", "multiplier of fees"
        ],
        "risk_impact": "CRITICAL",
        "sample_clauses": [
            "Neither party shall be liable for indirect, incidental, special, consequential, or punitive damages.",
            "Each party's aggregate liability under this Agreement shall be limited to the fees paid in the 12 months preceding the claim."
        ]
    },
    "Indemnity": {
        "category_id": "CT-06",
        "description": "Allocates responsibility for third-party claims, legal defense costs, and IP infringement indemnifications.",
        "keywords": [
            "indemnify", "indemnification", "hold harmless", "defend", "third party claims", "ip infringement",
            "defense of claims", "losses damages expenses", "attorneys fees", "settlement approval"
        ],
        "risk_impact": "CRITICAL",
        "sample_clauses": [
            "Vendor shall defend, indemnify, and hold harmless Customer from and against any third-party IP infringement claims.",
            "Indemnified party shall promptly notify indemnifying party in writing and grant sole control of defense."
        ]
    },
    "Warranty": {
        "category_id": "CT-07",
        "description": "Provides performance warranties, representations, service standard guarantees, and warranty disclaimers.",
        "keywords": [
            "warrants", "warranty", "warranties", "representation", "as is", "merchantability", "fitness for purpose",
            "workmanlike manner", "disclaimer", "exclusive remedy", "defect", "remedy"
        ],
        "risk_impact": "HIGH",
        "sample_clauses": [
            "Vendor warrants that the Services shall be performed in a professional and workmanlike manner.",
            "EXCEPT AS EXPRESSLY PROVIDED HEREIN, SERVICES ARE PROVIDED 'AS IS' WITHOUT WARRANTY OF ANY KIND."
        ]
    },
    "Insurance": {
        "category_id": "CT-08",
        "description": "Mandates insurance policy coverage types, minimum liability limits, and certificates of insurance.",
        "keywords": [
            "insurance", "policy", "coverage", "commercial general liability", "workers compensation", "errors and omissions",
            "cyber liability", "additional insured", "certificate of insurance", "waiver of subrogation"
        ],
        "risk_impact": "MEDIUM",
        "sample_clauses": [
            "Vendor shall maintain Commercial General Liability insurance with limits of not less than $2,000,000 per occurrence.",
            "Vendor shall provide Customer with a Certificate of Insurance naming Customer as an additional insured."
        ]
    },
    "Intellectual_Property": {
        "category_id": "CT-09",
        "description": "Establishes ownership rights over pre-existing IP, deliverables, work product, and patent/trademark licenses.",
        "keywords": [
            "intellectual property", "patent", "copyright", "trademark", "ownership of work", "ip rights", "work for hire",
            "deliverable", "license grant", "background ip", "foreground ip", "moral rights"
        ],
        "risk_impact": "HIGH",
        "sample_clauses": [
            "All deliverables created under this Agreement shall be deemed 'work made for hire' owned exclusively by Customer.",
            "Vendor retains all right, title, and interest in and to its pre-existing background intellectual property."
        ]
    },
    "Data_Protection": {
        "category_id": "CT-10",
        "description": "Mandates compliance with GDPR, CCPA, HIPAA data privacy regulations, and breach notifications.",
        "keywords": [
            "data protection", "gdpr", "ccpa", "hipaa", "privacy", "personal data", "security breach", "data processor",
            "data controller", "standard contractual clauses", "72 hours notice", "encryption", "phi"
        ],
        "risk_impact": "CRITICAL",
        "sample_clauses": [
            "Vendor shall process Personal Data strictly in accordance with GDPR and Customer's written instructions.",
            "Vendor shall notify Customer in writing within 72 hours of discovering any Security Breach involving Personal Data."
        ]
    },
    "SLA": {
        "category_id": "CT-11",
        "description": "Specifies service level availability, uptime percentages, maintenance windows, and service billing credits.",
        "keywords": [
            "service level", "sla", "uptime", "availability", "response time", "credit", "99.9% uptime", "maintenance window",
            "mean time to repair", "mttr", "outage", "service credit"
        ],
        "risk_impact": "HIGH",
        "sample_clauses": [
            "Vendor warrants that the Cloud Service shall maintain a Monthly Uptime Percentage of at least 99.9%.",
            "In the event of SLA breach, Customer shall be eligible to receive a 10% monthly service credit."
        ]
    },
    "Penalty": {
        "category_id": "CT-[12]",
        "description": "Imposes contractual fines, liquidated damages, and penalty deductions for non-performance.",
        "keywords": [
            "penalty", "liquidated damages", "late fee", "interest rate", "fine", "deduction", "offset", "delay damages"
        ],
        "risk_impact": "CRITICAL",
        "sample_clauses": [
            "Failure to deliver by the agreed Delivery Date shall result in a penalty fee of $1,000 per business day of delay."
        ]
    }
}
