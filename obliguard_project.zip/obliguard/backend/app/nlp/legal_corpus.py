"""
ObliGuard AI - Extensive Legal NLP Corpus & Clause Taxonomy Catalog
Contains comprehensive domain patterns, regulatory compliance frameworks (GDPR, HIPAA, CCPA, SOX, PCI-DSS, SOC 2),
and legal phrase dictionaries for high-precision hybrid NLP classification.
"""

from typing import Dict, List, Any

REGULATORY_FRAMEWORKS: Dict[str, Dict[str, Any]] = {
    "GDPR": {
        "full_name": "General Data Protection Regulation (EU 2016/679)",
        "keywords": [
            "data controller", "data processor", "personal data", "data subject", "right to erasure",
            "data protection officer", "dpo", "standard contractual clauses", "scc", "cross-border transfer",
            "data protection impact assessment", "dpia", "breach notification 72 hours", "pseudonymization"
        ],
        "default_risk_impact": "CRITICAL",
        "description": "European Union data protection and privacy regulation requirements."
    },
    "HIPAA": {
        "full_name": "Health Insurance Portability and Accountability Act",
        "keywords": [
            "protected health information", "phi", "business associate agreement", "baa", "covered entity",
            "minimum necessary", "privacy rule", "security rule", "ephi", "hipaa breach"
        ],
        "default_risk_impact": "CRITICAL",
        "description": "United States healthcare data privacy and electronic health record security."
    },
    "CCPA": {
        "full_name": "California Consumer Privacy Act / CPRA",
        "keywords": [
            "consumer personal information", "do not sell my personal information", "opt-out",
            "california privacy rights", "right to know", "sensitive personal information"
        ],
        "default_risk_impact": "HIGH",
        "description": "California consumer privacy protection requirements."
    },
    "SOC2": {
        "full_name": "Service Organization Control 2 Type II",
        "keywords": [
            "trust services criteria", "soc 2 type ii", "security controls", "availability",
            "processing integrity", "confidentiality", "independent audit report"
        ],
        "default_risk_impact": "HIGH",
        "description": "Auditing procedure for cloud and SaaS vendor security controls."
    },
    "SOX": {
        "full_name": "Sarbanes-Oxley Act",
        "keywords": [
            "internal controls over financial reporting", "sox 404", "financial statement audit",
            "record retention 7 years", "sec compliance", "executive certification"
        ],
        "default_risk_impact": "CRITICAL",
        "description": "Corporate governance and financial reporting auditing requirements."
    }
}

EXTENDED_CLAUSE_DICTIONARY: Dict[str, Dict[str, Any]] = {
    "Payment_Terms": {
        "keywords": [
            "net 30", "net 60", "net 90", "late payment interest", "1.5% per month", "wire transfer",
            "electronic funds transfer", "invoice dispute", "undisputed fees", "taxes and duties",
            "value added tax", "vat", "sales tax", "withholding tax", "advance payment", "milestone payment"
        ],
        "sample_phrases": [
            "Payment shall be due within thirty (30) calendar days from receipt of undisputed invoice.",
            "Any overdue payments shall accrue interest at the rate of 1.5% per month or maximum legal rate.",
            "Customer shall be responsible for all applicable sales, use, VAT, and excise taxes."
        ]
    },
    "Limitation_Of_Liability": {
        "keywords": [
            "aggregate liability", "direct damages", "consequential damages", "punitive damages",
            "loss of profits", "loss of revenue", "multiplier of fees", "12 months preceding fees",
            "cap on liability", "carve-outs", "gross negligence", "willful misconduct"
        ],
        "sample_phrases": [
            "In no event shall either party's aggregate liability exceed the total fees paid in 12 months preceding event.",
            "Neither party shall be liable for indirect, incidental, special, consequential, or punitive damages.",
            "The limitations in Section 8.1 shall not apply to breaches of confidentiality or indemnification obligations."
        ]
    },
    "Termination_For_Cause": {
        "keywords": [
            "material breach", "cure period", "30 days written notice to cure", "insolvency",
            "bankruptcy", "assignment for benefit of creditors", "immediate termination"
        ],
        "sample_phrases": [
            "Either party may terminate this Agreement immediately upon written notice if the other party materially breaches and fails to cure within thirty (30) days.",
            "This Agreement shall terminate automatically if either party files for bankruptcy or insolvency."
        ]
    },
    "Termination_For_Convenience": {
        "keywords": [
            "without cause", "for convenience", "at any time upon notice", "60 days advance notice",
            "prorated refund", "unearned pre-paid fees"
        ],
        "sample_phrases": [
            "Customer may terminate this Agreement for convenience at any time upon sixty (60) days prior written notice.",
            "Upon termination for convenience, Vendor shall refund Customer any pre-paid, unearned fees."
        ]
    },
    "Indemnification": {
        "keywords": [
            "indemnify and hold harmless", "third party claims", "ip infringement claim", "defense of claims",
            "control of defense", "settlement approval", "losses damages expenses", "attorneys fees"
        ],
        "sample_phrases": [
            "Vendor agrees to defend, indemnify, and hold harmless Customer against any third-party claims alleging IP infringement.",
            "Indemnified party shall promptly notify indemnifying party in writing of any claim."
        ]
    },
    "Service_Level_Agreement": {
        "keywords": [
            "99.9% uptime", "99.99% availability", "scheduled maintenance", "emergency maintenance",
            "mean time to repair", "mttr", "response time 1 hour", "service credits", "10% fee credit"
        ],
        "sample_phrases": [
            "Vendor warrants that the Service shall achieve a Monthly Uptime Percentage of at least 99.9%.",
            "If Vendor fails to meet Uptime Percentage, Customer shall receive a 10% credit applied to next invoice."
        ]
    }
}
