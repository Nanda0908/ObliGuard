"""
ObliGuard AI - Hybrid Clause Classification Engine
Classifies legal contract clauses into 20+ categories using deterministic legal pattern matching
with Scikit-Learn ML classification fallback when available.
"""

from typing import Dict, Any, Tuple, List

# Rule-based Keyword Dictionary for High Precision Matching
CLAUSE_PATTERNS: Dict[str, Tuple[List[str], str]] = {
    "Payment": (["pay", "payment", "invoice", "remit", "fee", "price", "compensation", "billing", "reimburse", "net 30", "net 60"], "HIGH"),
    "Termination": (["terminate", "termination", "cancel", "cancellation", "cure period", "material breach", "expire", "without cause"], "HIGH"),
    "Renewal": (["renew", "renewal", "extension", "auto-renew", "automatic renewal", "term extension", "non-renewal"], "MEDIUM"),
    "Confidentiality": (["confidential", "confidentiality", "proprietary", "trade secret", "nondisclosure", "nda"], "MEDIUM"),
    "Liability": (["limitation of liability", "liable", "consequential damages", "indirect damages", "maximum liability", "aggregate liability"], "CRITICAL"),
    "Indemnity": (["indemnify", "indemnification", "hold harmless", "defend", "third party claims"], "CRITICAL"),
    "Warranty": (["warrants", "warranty", "warranties", "representation", "as is", "merchantability"], "HIGH"),
    "Insurance": (["insurance", "policy", "coverage", "commercial general liability", "workers compensation"], "MEDIUM"),
    "Intellectual Property": (["intellectual property", "patent", "copyright", "trademark", "ownership of work", "ip rights", "work for hire"], "HIGH"),
    "Data Protection": (["data protection", "gdpr", "ccpa", "hipaa", "privacy", "personal data", "security breach", "72 hours notice"], "CRITICAL"),
    "SLA": (["service level", "sla", "uptime", "availability", "response time", "credit", "99.9% uptime"], "HIGH"),
    "Penalty": (["penalty", "liquidated damages", "late fee", "interest rate", "fine"], "CRITICAL"),
    "Dispute Resolution": (["dispute", "arbitration", "mediation", "litigation", "jurisdiction", "venue"], "MEDIUM"),
    "Audit": (["audit", "inspect", "books and records", "examination", "access to records"], "MEDIUM"),
    "Reporting": (["submit report", "quarterly report", "monthly report", "status report", "notice", "compliance report"], "MEDIUM"),
    "Compliance": (["comply with laws", "regulatory compliance", "applicable law", "anti-bribery", "fcpa"], "HIGH"),
    "Force Majeure": (["force majeure", "act of god", "natural disaster", "war", "epidemic"], "LOW"),
    "Governing Law": (["governing law", "construed in accordance with", "state of", "laws of"], "LOW"),
    "Non-Compete": (["non-compete", "noncompete", "competing business", "covenant not to compete"], "HIGH"),
    "Non-Solicitation": (["solicit", "non-solicitation", "solicitation of employees", "hire employees"], "MEDIUM"),
    "Security": (["security controls", "encryption", "soc 2", "iso 27001", "vulnerability"], "HIGH"),
    "Delivery": (["deliverable", "delivery date", "shipment", "acceptance criteria"], "MEDIUM"),
    "Acceptance": (["acceptance testing", "accept the deliverables", "written acceptance"], "MEDIUM")
}

class HybridClauseClassifier:
    """Combines high-precision legal keyword heuristics with optional ML classifier."""

    def classify_clause(self, text: str) -> Dict[str, Any]:
        """Classify clause text and return best category, confidence score, and risk impact."""
        text_lower = text.lower()

        # Step 1: High-precision Pattern Matcher
        matched_scores = {}
        for category, (keywords, risk_level) in CLAUSE_PATTERNS.items():
            hits = sum(1 for kw in keywords if kw in text_lower)
            if hits > 0:
                matched_scores[category] = (hits, risk_level)

        if matched_scores:
            best_cat, (hits, risk_level) = max(matched_scores.items(), key=lambda x: x[1][0])
            confidence = min(0.98, 0.70 + (hits * 0.10))
            return {
                "clause_type": best_cat,
                "confidence_score": round(confidence, 2),
                "risk_impact": risk_level
            }

        # Step 2: Try optional Scikit-Learn ML Classifier if installed
        try:
            from sklearn.feature_extraction.text import TfidfVectorizer
            from sklearn.linear_model import LogisticRegression
            import numpy as np

            texts = [f"The party agrees to {kw}." for cat, (kws, _) in CLAUSE_PATTERNS.items() for kw in kws]
            labels = [cat for cat, (kws, _) in CLAUSE_PATTERNS.items() for kw in kws]

            vec = TfidfVectorizer().fit(texts)
            clf = LogisticRegression().fit(vec.transform(texts), labels)

            X_vec = vec.transform([text])
            probas = clf.predict_proba(X_vec)[0]
            top_idx = np.argmax(probas)
            best_cat = clf.classes_[top_idx]
            confidence = float(probas[top_idx])
            risk_level = CLAUSE_PATTERNS.get(best_cat, ([], "MEDIUM"))[1]

            return {
                "clause_type": best_cat,
                "confidence_score": round(max(0.60, confidence), 2),
                "risk_impact": risk_level
            }
        except Exception:
            pass

        return {
            "clause_type": "General Term",
            "confidence_score": 0.50,
            "risk_impact": "LOW"
        }

classifier_instance = HybridClauseClassifier()
