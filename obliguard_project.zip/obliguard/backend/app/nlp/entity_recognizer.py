"""
ObliGuard AI - Contract Named Entity Recognizer (NER)
Extracts Parties, Amounts, Currencies, Durations, and Jurisdictions from legal text.
"""

import re
from typing import Dict, Any, List

MONEY_REGEX = re.compile(r"(\$|USD|EUR|GBP)\s*([0-9]{1,3}(?:,[0-9]{3})*(?:\.[0-9]{2})?|\d+)")
DURATION_REGEX = re.compile(r"(\d+)\s*(business\s+days|calendar\s+days|days|weeks|months|years)")
PARTY_KEYWORDS = ["Vendor", "Supplier", "Client", "Customer", "Licensor", "Licensee", "Company", "Contractor", "Consultant", "Provider"]

def extract_contract_entities(text: str) -> Dict[str, Any]:
    """Extract parties, money, and durations from contract text."""
    parties = []
    for party_kw in PARTY_KEYWORDS:
        if re.search(rf"\b{party_kw}\b", text, re.IGNORECASE):
            parties.append(party_kw)

    money_matches = MONEY_REGEX.findall(text)
    amounts = [f"{m[0]} {m[1]}".strip() for m in money_matches]

    duration_matches = DURATION_REGEX.findall(text, re.IGNORECASE)
    durations = [f"{d[0]} {d[1]}".strip() for d in duration_matches]

    return {
        "parties": list(set(parties)),
        "amounts": list(set(amounts)),
        "durations": list(set(durations))
    }
