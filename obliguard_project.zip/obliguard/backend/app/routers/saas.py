"""
ObliGuard AI - SaaS Subscription & Usage Router
Subscription status, feature limits, and usage metrics.
"""

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.routers.deps import get_tenant_context, require_permission
from app.core.permissions import Permission
from app.core.tenancy import TenantContext
from app.schemas.analytics import UsageSummary
from app.repositories.analytics_repo import AnalyticsRepository

router = APIRouter(prefix="/saas", tags=["SaaS Subscription"])

@router.get("/usage", response_model=UsageSummary)
def get_usage_summary(
    db: Session = Depends(get_db),
    tenant: TenantContext = Depends(get_tenant_context),
    current_user = Depends(require_permission(Permission.SUBSCRIPTION_MANAGE))
):
    """Retrieve SaaS quota usage summary."""
    analytics_repo = AnalyticsRepository(db)
    metrics = analytics_repo.get_tenant_metrics(tenant.organization_id)

    return UsageSummary(
        plan_tier="ENTERPRISE",
        contracts_used=metrics["total_contracts"],
        contracts_limit=1000,
        users_used=3,
        users_limit=50,
        storage_mb_used=14.5,
        storage_mb_limit=50000
    )
