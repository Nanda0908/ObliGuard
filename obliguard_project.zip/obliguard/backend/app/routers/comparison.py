"""
ObliGuard AI - Contract Version Comparison API Router
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.routers.deps import get_tenant_context, require_permission
from app.core.permissions import Permission
from app.core.tenancy import TenantContext
from app.schemas.search import ComparisonRequest, ComparisonResponse
from app.repositories.contract_repo import ContractRepository
from app.repositories.clause_repo import ClauseRepository
from app.comparison.diff_engine import compare_contract_versions

router = APIRouter(prefix="/comparison", tags=["Contract Version Comparison"])

@router.post("", response_model=ComparisonResponse)
def compare_versions(
    request: ComparisonRequest,
    db: Session = Depends(get_db),
    tenant: TenantContext = Depends(get_tenant_context),
    current_user = Depends(require_permission(Permission.CONTRACT_COMPARE))
):
    """Compare two contract versions and generate structural/semantic diff."""
    contract_repo = ContractRepository(db)
    v1 = contract_repo.get_contract_version(request.version_id_1)
    v2 = contract_repo.get_contract_version(request.version_id_2)

    if not v1 or not v2:
        raise HTTPException(status_code=404, detail="One or both contract versions not found.")

    clause_repo = ClauseRepository(db)
    c1_list = [c.__dict__ for c in clause_repo.get_clauses(tenant.organization_id, v1.contract_id)]
    c2_list = [c.__dict__ for c in clause_repo.get_clauses(tenant.organization_id, v2.contract_id)]

    diff_results = compare_contract_versions(c1_list, c2_list)

    return ComparisonResponse(
        contract_id=v1.contract_id,
        version_1_number=v1.version_number,
        version_2_number=v2.version_number,
        summary_of_changes=diff_results["summary_of_changes"],
        total_added=diff_results["total_added"],
        total_removed=diff_results["total_removed"],
        total_modified=diff_results["total_modified"],
        clause_diffs=diff_results["clause_diffs"],
        risk_delta=diff_results["risk_delta"],
        obligation_impact_summary=diff_results["obligation_impact_summary"]
    )
