"""
ObliGuard AI - Contract Lifecycle & Document Processing Routers
API endpoints for uploading, listing, searching, updating, and managing contract documents.
"""

import os
from typing import List, Optional
from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.routers.deps import get_current_user, get_tenant_context, require_permission
from app.core.permissions import Permission
from app.core.tenancy import TenantContext
from app.models.user import User
from app.schemas.contract import ContractOut, ContractCreate, ContractUpdate
from app.services.contract_service import ContractService
from app.repositories.contract_repo import ContractRepository
from app.config import settings

router = APIRouter(prefix="/contracts", tags=["Contracts"])

@router.post("/upload", response_model=ContractOut, status_code=status.HTTP_201_CREATED)
def upload_contract(
    title: str = Form(...),
    contract_type: str = Form("Master Services Agreement"),
    total_value: float = Form(0.0),
    currency: str = Form("USD"),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permission(Permission.CONTRACT_CREATE)),
    tenant: TenantContext = Depends(get_tenant_context)
):
    """Upload PDF, DOCX, or TXT contract document and execute processing pipeline."""
    # File type validation
    ext = file.filename.split(".")[-1].lower()
    if ext not in ["pdf", "docx", "doc", "txt"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Unsupported document format. Upload PDF, DOCX, or TXT."
        )

    # Save file to local storage
    saved_filename = f"org_{tenant.organization_id}_{file.filename}"
    file_path = os.path.join(settings.STORAGE_DIR, saved_filename)
    
    file_bytes = file.file.read()
    with open(file_path, "wb") as f:
        f.write(file_bytes)

    contract_service = ContractService(db)
    contract = contract_service.process_and_create_contract(
        organization_id=tenant.organization_id,
        title=title,
        contract_type=contract_type,
        file_path=file_path,
        file_name=file.filename,
        file_size=len(file_bytes),
        uploaded_by_id=current_user.id,
        total_value=total_value,
        currency=currency
    )

    return contract

@router.get("", response_model=List[ContractOut])
def list_contracts(
    query: Optional[str] = None,
    contract_type: Optional[str] = None,
    status: Optional[str] = None,
    risk_level: Optional[str] = None,
    skip: int = 0,
    limit: int = 50,
    db: Session = Depends(get_db),
    tenant: TenantContext = Depends(get_tenant_context),
    current_user: User = Depends(require_permission(Permission.CONTRACT_READ))
):
    """List and filter tenant contracts."""
    contract_repo = ContractRepository(db)
    contracts = contract_repo.search_contracts(
        organization_id=tenant.organization_id,
        query=query,
        contract_type=contract_type,
        status=status,
        risk_level=risk_level,
        skip=skip,
        limit=limit
    )
    return contracts

@router.get("/{contract_id}", response_model=ContractOut)
def get_contract_detail(
    contract_id: int,
    db: Session = Depends(get_db),
    tenant: TenantContext = Depends(get_tenant_context),
    current_user: User = Depends(require_permission(Permission.CONTRACT_READ))
):
    """Get single contract details."""
    contract_repo = ContractRepository(db)
    contract = contract_repo.get_by_id(contract_id)
    if not contract:
        raise HTTPException(status_code=404, detail="Contract not found")

    tenant.validate_entity_tenant(contract.organization_id, "Contract")
    return contract

@router.put("/{contract_id}", response_model=ContractOut)
def update_contract(
    contract_id: int,
    request: ContractUpdate,
    db: Session = Depends(get_db),
    tenant: TenantContext = Depends(get_tenant_context),
    current_user: User = Depends(require_permission(Permission.CONTRACT_UPDATE))
):
    """Update contract metadata."""
    contract_repo = ContractRepository(db)
    contract = contract_repo.get_by_id(contract_id)
    if not contract:
        raise HTTPException(status_code=404, detail="Contract not found")

    tenant.validate_entity_tenant(contract.organization_id, "Contract")
    updated = contract_repo.update(contract, request)
    return updated

@router.delete("/{contract_id}", status_code=204)
def delete_contract(
    contract_id: int,
    db: Session = Depends(get_db),
    tenant: TenantContext = Depends(get_tenant_context),
    current_user: User = Depends(require_permission(Permission.CONTRACT_DELETE))
):
    """Delete contract and all associated clauses, obligations, and risk history."""
    contract_repo = ContractRepository(db)
    contract = contract_repo.get_by_id(contract_id)
    if not contract:
        raise HTTPException(status_code=404, detail="Contract not found")

    tenant.validate_entity_tenant(contract.organization_id, "Contract")
    contract_repo.delete(contract_id)
    return None
