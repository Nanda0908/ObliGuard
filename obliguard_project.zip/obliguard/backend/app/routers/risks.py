"""
ObliGuard AI - Risk Intelligence API Routers
Endpoints for retrieving contract risk scores, explainable factor breakdowns, and historical trends.
"""

from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.routers.deps import get_tenant_context, require_permission
from app.core.permissions import Permission
from app.core.tenancy import TenantContext
from app.schemas.risk import RiskScoreOut
from app.repositories.risk_repo import RiskRepository

router = APIRouter(prefix="/risks", tags=["Risk Intelligence"])

@router.get("/contract/{contract_id}", response_model=RiskScoreOut)
def get_contract_risk_score(
    contract_id: int,
    db: Session = Depends(get_db),
    tenant: TenantContext = Depends(get_tenant_context),
    current_user = Depends(require_permission(Permission.RISK_VIEW))
):
    """Get latest risk evaluation score and factor breakdown for contract."""
    risk_repo = RiskRepository(db)
    risk_score = risk_repo.get_latest_by_contract(contract_id)
    if not risk_score:
        raise HTTPException(status_code=404, detail="Risk evaluation not found for contract.")
    return risk_score
