"""
ObliGuard AI - Analytics & Executive Dashboard Router
Aggregates contract metrics, obligation compliance percentages, risk distributions, and trend charts.
"""

from typing import Optional
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.routers.deps import get_tenant_context, require_permission
from app.core.permissions import Permission
from app.core.tenancy import TenantContext
from app.schemas.analytics import AnalyticsDashboard, AnalyticsOverview
from app.repositories.analytics_repo import AnalyticsRepository

router = APIRouter(prefix="/analytics", tags=["Analytics & Dashboard"])

@router.get("/dashboard", response_model=AnalyticsDashboard)
def get_analytics_dashboard(
    contract_id: Optional[int] = None,
    db: Session = Depends(get_db),
    tenant: TenantContext = Depends(get_tenant_context),
    current_user = Depends(require_permission(Permission.ANALYTICS_VIEW))
):
    """Retrieve full executive analytics metrics using real database aggregations."""
    analytics_repo = AnalyticsRepository(db)
    overview_data = analytics_repo.get_tenant_metrics(tenant.organization_id, contract_id=contract_id)

    overview = AnalyticsOverview(**overview_data)

    status_dist = [
        {"label": "Active", "count": overview_data["active_contracts"]},
        {"label": "Expiring Soon", "count": overview_data["expiring_soon_contracts"]},
        {"label": "Draft", "count": max(0, overview_data["total_contracts"] - overview_data["active_contracts"])}
    ]

    risk_dist = [
        {"risk_level": "LOW", "count": max(0, overview_data["total_contracts"] - overview_data["high_risk_contracts"] - overview_data["critical_risk_contracts"])},
        {"risk_level": "MEDIUM", "count": max(0, overview_data["active_contracts"] - overview_data["high_risk_contracts"])},
        {"risk_level": "HIGH", "count": overview_data["high_risk_contracts"]},
        {"risk_level": "CRITICAL", "count": overview_data["critical_risk_contracts"]}
    ]

    obligation_dist = [
        {"label": "Overdue", "count": overview_data["overdue_obligations"]},
        {"label": "Upcoming", "count": overview_data["upcoming_obligations"]},
        {"label": "Completed", "count": max(0, overview_data["total_obligations"] - overview_data["overdue_obligations"] - overview_data["upcoming_obligations"])}
    ]

    trends = analytics_repo.get_compliance_trends(tenant.organization_id, contract_id=contract_id)
    dept_matrix = analytics_repo.get_department_risk_matrix(tenant.organization_id, contract_id=contract_id)

    return AnalyticsDashboard(
        overview=overview,
        contract_status_distribution=status_dist,
        risk_level_distribution=risk_dist,
        obligation_status_distribution=obligation_dist,
        compliance_trend=trends,
        department_risk_matrix=dept_matrix
    )
