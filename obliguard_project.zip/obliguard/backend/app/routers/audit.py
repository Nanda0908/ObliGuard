"""
ObliGuard AI - Audit Log Router
Endpoints for querying immutable security and governance audit logs.
"""

from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.routers.deps import get_tenant_context, require_permission
from app.core.permissions import Permission
from app.core.tenancy import TenantContext
from app.schemas.analytics import AuditLogOut
from app.models.audit import AuditLog

router = APIRouter(prefix="/audit", tags=["Audit & Governance"])

@router.get("", response_model=List[AuditLogOut])
def get_audit_logs(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    tenant: TenantContext = Depends(get_tenant_context),
    current_user = Depends(require_permission(Permission.AUDIT_VIEW))
):
    """Retrieve immutable audit event trail."""
    return db.query(AuditLog).filter(
        AuditLog.organization_id == tenant.organization_id
    ).order_by(AuditLog.created_at.desc()).offset(skip).limit(limit).all()
