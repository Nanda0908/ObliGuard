"""
ObliGuard AI - Clause Explorer & Details API Routers
"""

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.routers.deps import get_tenant_context, require_permission
from app.core.permissions import Permission
from app.core.tenancy import TenantContext
from app.schemas.clause import ClauseOut
from app.repositories.clause_repo import ClauseRepository

router = APIRouter(prefix="/clauses", tags=["Clauses"])

@router.get("", response_model=List[ClauseOut])
def list_clauses(
    contract_id: Optional[int] = None,
    clause_type: Optional[str] = None,
    skip: int = 0,
    limit: int = 50,
    db: Session = Depends(get_db),
    tenant: TenantContext = Depends(get_tenant_context),
    current_user = Depends(require_permission(Permission.CONTRACT_READ))
):
    """List classified contract clauses."""
    clause_repo = ClauseRepository(db)
    return clause_repo.get_clauses(tenant.organization_id, contract_id, clause_type, skip, limit)
