"""
ObliGuard AI - System Health & Observability Router
`/health` and `/ready` endpoints for Docker & Kubernetes health checks.
"""

from datetime import datetime, timezone
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import text
from app.database import get_db
from app.schemas.analytics import SystemHealth
from app.config import settings

router = APIRouter(tags=["System Health"])

@router.get("/health", response_model=SystemHealth)
def get_system_health(db: Session = Depends(get_db)):
    """Liveness probe endpoint."""
    db_ok = True
    try:
        db.execute(text("SELECT 1"))
    except Exception:
        db_ok = False

    return SystemHealth(
        status="healthy" if db_ok else "unhealthy",
        database_connected=db_ok,
        local_ai_available=True,
        version=settings.VERSION,
        timestamp=datetime.now(timezone.utc)
    )

@router.get("/ready", response_model=SystemHealth)
def get_system_readiness(db: Session = Depends(get_db)):
    """Readiness probe endpoint."""
    return get_system_health(db)
