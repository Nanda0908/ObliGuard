"""
ObliGuard AI - FastAPI Dependency Injection Core
Authentication, JWT token verification, Tenant isolation, and RBAC permission checks.
"""

from typing import Generator
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from app.database import get_db
from app.core.security import decode_access_token
from app.core.permissions import Permission, verify_role_permission
from app.core.tenancy import TenantContext
from app.repositories.user_repo import UserRepository
from app.models.user import User

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")

def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
) -> User:
    """Validate JWT access token and return current authenticated User."""
    payload = decode_access_token(token)
    user_id = payload.get("sub")
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication token payload"
        )

    user_repo = UserRepository(db)
    user = user_repo.get_by_id(int(user_id))
    if not user or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User account inactive or not found"
        )

    return user

def get_tenant_context(
    current_user: User = Depends(get_current_user)
) -> TenantContext:
    """Provide TenantContext for strict multi-tenant isolation."""
    is_super = current_user.role_name == "Super Admin"
    return TenantContext(organization_id=current_user.organization_id, is_super_admin=is_super)

def require_permission(required_perm: Permission):
    """Dependency factory for enforcing RBAC permissions."""
    def permission_checker(current_user: User = Depends(get_current_user)):
        verify_role_permission(current_user.role_name, required_perm)
        return current_user
    return permission_checker
