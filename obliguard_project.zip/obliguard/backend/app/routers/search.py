"""
ObliGuard AI - Semantic Contract Search API Router
"""

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.routers.deps import get_tenant_context, require_permission
from app.core.permissions import Permission
from app.core.tenancy import TenantContext
from app.schemas.search import SearchQuery, SearchResponse
from app.services.search_service import SearchService

router = APIRouter(prefix="/search", tags=["Semantic Search"])

@router.post("", response_model=SearchResponse)
def execute_semantic_search(
    request: SearchQuery,
    db: Session = Depends(get_db),
    tenant: TenantContext = Depends(get_tenant_context),
    current_user = Depends(require_permission(Permission.SEARCH_EXECUTE))
):
    """Execute natural language vector search over contract clauses."""
    search_service = SearchService(db)
    return search_service.search_clauses(
        organization_id=tenant.organization_id,
        query=request.query,
        top_k=request.top_k,
        contract_id=request.contract_id,
        clause_type=request.clause_type
    )
