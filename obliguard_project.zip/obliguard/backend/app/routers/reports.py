"""
ObliGuard AI - Executive Reporting API Router
Endpoints to trigger, list, and download executive PDF, CSV, and JSON reports.
"""

from typing import List
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from app.database import get_db
from app.routers.deps import get_tenant_context, require_permission
from app.core.permissions import Permission
from app.core.tenancy import TenantContext
from app.schemas.analytics import ReportGenerateRequest, ReportOut
from app.models.report import Report
from app.reporting.report_generator import generate_enterprise_report
from app.repositories.analytics_repo import AnalyticsRepository

router = APIRouter(prefix="/reports", tags=["Reports"])

@router.post("/generate", response_model=ReportOut)
def generate_report(
    request: ReportGenerateRequest,
    db: Session = Depends(get_db),
    tenant: TenantContext = Depends(get_tenant_context),
    current_user = Depends(require_permission(Permission.REPORTS_GENERATE))
):
    """Generate enterprise contract intelligence report."""
    analytics_repo = AnalyticsRepository(db)
    metrics_data = analytics_repo.get_tenant_metrics(tenant.organization_id)

    filepath = generate_enterprise_report(
        report_type=request.report_type,
        organization_name="Tenant Org",
        data=metrics_data,
        file_format=request.format
    )

    report_obj = Report(
        organization_id=tenant.organization_id,
        title=request.title,
        report_type=request.report_type,
        generated_by_id=current_user.id,
        file_path=filepath,
        format=request.format
    )
    db.add(report_obj)
    db.commit()
    db.refresh(report_obj)
    return report_obj

@router.get("", response_model=List[ReportOut])
def list_reports(
    db: Session = Depends(get_db),
    tenant: TenantContext = Depends(get_tenant_context),
    current_user = Depends(require_permission(Permission.REPORTS_GENERATE))
):
    """List generated organization reports."""
    return db.query(Report).filter(Report.organization_id == tenant.organization_id).order_by(Report.created_at.desc()).all()

@router.get("/{report_id}/download")
def download_report(
    report_id: int,
    db: Session = Depends(get_db),
    tenant: TenantContext = Depends(get_tenant_context),
    current_user = Depends(require_permission(Permission.REPORTS_EXPORT))
):
    """Download generated report file."""
    report = db.query(Report).filter(Report.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")

    tenant.validate_entity_tenant(report.organization_id, "Report")
    return FileResponse(report.file_path, filename=f"{report.title}.{report.format.lower()}")
