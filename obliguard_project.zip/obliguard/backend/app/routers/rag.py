"""
ObliGuard AI - Grounded Local RAG Contract Assistant Router
"""

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.routers.deps import get_tenant_context, require_permission
from app.core.permissions import Permission
from app.core.tenancy import TenantContext
from app.schemas.search import RAGQuery, RAGResponse
from app.services.search_service import SearchService
from app.ai.rag_assistant import rag_assistant

router = APIRouter(prefix="/rag", tags=["AI Contract Assistant"])

@router.post("/query", response_model=RAGResponse)
def ask_contract_assistant(
    request: RAGQuery,
    db: Session = Depends(get_db),
    tenant: TenantContext = Depends(get_tenant_context),
    current_user = Depends(require_permission(Permission.AI_ASSISTANT_USE))
):
    """Query Grounded Local RAG Contract Assistant with clause retrieval citations."""
    search_service = SearchService(db)
    search_results = search_service.search_clauses(
        organization_id=tenant.organization_id,
        query=request.question,
        top_k=request.top_k,
        contract_id=request.contract_id
    )

    retrieved_dict_list = [r.dict() for r in search_results.results]
    answer_data = rag_assistant.generate_grounded_answer(request.question, retrieved_dict_list)

    return RAGResponse(**answer_data)
