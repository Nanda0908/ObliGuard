"""
ObliGuard AI - User & Department Administration Router
Endpoints to list, invite, update roles, and manage organization team members.
"""

from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.routers.deps import get_tenant_context, require_permission
from app.core.permissions import Permission
from app.core.tenancy import TenantContext
from app.schemas.user import UserOut, UserCreate, UserUpdate
from app.repositories.user_repo import UserRepository
from app.core.security import get_password_hash

router = APIRouter(prefix="/users", tags=["User Management"])

@router.get("", response_model=List[UserOut])
def list_users(
    db: Session = Depends(get_db),
    tenant: TenantContext = Depends(get_tenant_context),
    current_user = Depends(require_permission(Permission.ORG_USERS_MANAGE))
):
    """List team members in organization."""
    user_repo = UserRepository(db)
    return user_repo.get_org_users(tenant.organization_id)

@router.post("", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def create_user(
    request: UserCreate,
    db: Session = Depends(get_db),
    tenant: TenantContext = Depends(get_tenant_context),
    current_user = Depends(require_permission(Permission.ORG_USERS_MANAGE))
):
    """Add user team member with assigned RBAC role."""
    user_repo = UserRepository(db)
    if user_repo.get_by_email(request.email):
        raise HTTPException(status_code=400, detail="User email already exists.")

    hashed_pwd = get_password_hash(request.password)
    user = user_repo.create({
        "organization_id": tenant.organization_id,
        "email": request.email.lower(),
        "password_hash": hashed_pwd,
        "full_name": request.full_name,
        "role_name": request.role_name,
        "department_id": request.department_id,
        "is_verified": True
    })
    return user
