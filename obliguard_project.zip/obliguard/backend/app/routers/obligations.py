"""
ObliGuard AI - Obligation Management API Routers
Endpoints for listing, filtering, updating lifecycle status, assigning owners, and deadline tracking.
"""

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.routers.deps import get_current_user, get_tenant_context, require_permission
from app.core.permissions import Permission
from app.core.tenancy import TenantContext
from app.models.user import User
from app.schemas.obligation import ObligationOut, ObligationUpdate
from app.repositories.obligation_repo import ObligationRepository
from app.services.obligation_service import ObligationService

router = APIRouter(prefix="/obligations", tags=["Obligations"])

@router.get("", response_model=List[ObligationOut])
def list_obligations(
    contract_id: Optional[int] = None,
    obligation_type: Optional[str] = None,
    status: Optional[str] = None,
    priority: Optional[str] = None,
    assigned_user_id: Optional[int] = None,
    skip: int = 0,
    limit: int = 50,
    db: Session = Depends(get_db),
    tenant: TenantContext = Depends(get_tenant_context),
    current_user: User = Depends(require_permission(Permission.OBLIGATION_READ))
):
    """List obligations with tenant isolation filters."""
    ob_repo = ObligationRepository(db)
    return ob_repo.get_filtered_obligations(
        organization_id=tenant.organization_id,
        contract_id=contract_id,
        obligation_type=obligation_type,
        status=status,
        priority=priority,
        assigned_user_id=assigned_user_id,
        skip=skip,
        limit=limit
    )

@router.put("/{obligation_id}/status", response_model=ObligationOut)
def update_obligation_status(
    obligation_id: int,
    status: str,
    db: Session = Depends(get_db),
    tenant: TenantContext = Depends(get_tenant_context),
    current_user: User = Depends(require_permission(Permission.OBLIGATION_UPDATE))
):
    """Update obligation workflow lifecycle status."""
    ob_service = ObligationService(db)
    return ob_service.update_status(obligation_id, status, current_user.id)

@router.put("/{obligation_id}/assign", response_model=ObligationOut)
def assign_obligation_owner(
    obligation_id: int,
    user_id: int,
    db: Session = Depends(get_db),
    tenant: TenantContext = Depends(get_tenant_context),
    current_user: User = Depends(require_permission(Permission.OBLIGATION_ASSIGN))
):
    """Assign responsible user owner to obligation."""
    ob_service = ObligationService(db)
    return ob_service.assign_user(obligation_id, user_id)
