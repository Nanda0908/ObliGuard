"""
ObliGuard AI - Multi-Dimensional Risk Intelligence Engine
Computes 0-100 explainable risk scores across 8 dimensions based on deterministic contract features,
financial exposure, penalty presence, auto-renewals, and compliance history.
"""

from typing import List, Dict, Any

def evaluate_contract_risk(
    contract_value: float = 0.0,
    has_penalty_clause: bool = False,
    has_auto_renewal: bool = False,
    notice_period_days: int = 30,
    clause_risk_impacts: List[str] = None,
    overdue_obligations_count: int = 0
) -> Dict[str, Any]:
    """
    Calculate deterministic 0-100 risk score and factor breakdown.
    Returns: {
        "overall_score": float,
        "risk_level": str,
        "financial_risk": float,
        "compliance_risk": float,
        "deadline_risk": float,
        "penalty_risk": float,
        "renewal_risk": float,
        "operational_risk": float,
        "legal_risk": float,
        "security_risk": float,
        "factors": List[Dict[str, Any]],
        "explanation": str
    }
    """
    clause_impacts = clause_risk_impacts or []
    factors = []

    # 1. Financial Risk Score (0 - 25)
    financial_risk = 10.0
    if contract_value > 500000:
        financial_risk = 25.0
        factors.append({
            "dimension": "Financial",
            "factor_name": "High Financial Exposure",
            "weight": 1.5,
            "score_contribution": 25.0,
            "description": f"Contract monetary value of ${contract_value:,.2f} exceeds high-exposure threshold."
        })
    elif contract_value > 100000:
        financial_risk = 18.0
        factors.append({
            "dimension": "Financial",
            "factor_name": "Moderate Financial Exposure",
            "weight": 1.2,
            "score_contribution": 18.0,
            "description": f"Contract monetary value of ${contract_value:,.2f}."
        })

    # 2. Penalty Risk Score (0 - 25)
    penalty_risk = 5.0
    if has_penalty_clause or "Penalty" in clause_impacts or "CRITICAL" in clause_impacts:
        penalty_risk = 22.0
        factors.append({
            "dimension": "Penalty",
            "factor_name": "Strict Liquidated Damages & Penalty Terms",
            "weight": 2.0,
            "score_contribution": 22.0,
            "description": "Explicit penalty or liquidated damages clause detected."
        })

    # 3. Renewal & Expiry Risk Score (0 - 20)
    renewal_risk = 5.0
    if has_auto_renewal:
        renewal_risk += 10.0
        factors.append({
            "dimension": "Renewal",
            "factor_name": "Automatic Renewal Commitment",
            "weight": 1.3,
            "score_contribution": 10.0,
            "description": "Contract contains auto-renewal provision."
        })
    if notice_period_days > 60:
        renewal_risk += 5.0
        factors.append({
            "dimension": "Renewal",
            "factor_name": "Long Cancellation Notice Window",
            "weight": 1.1,
            "score_contribution": 5.0,
            "description": f"Requires {notice_period_days} days advance notice prior to expiration."
        })

    # 4. Compliance & Operational Risk Score (0 - 30)
    compliance_risk = 5.0 + (overdue_obligations_count * 12.0)
    if overdue_obligations_count > 0:
        factors.append({
            "dimension": "Compliance",
            "factor_name": "Overdue Obligation History",
            "weight": 2.5,
            "score_contribution": min(30.0, overdue_obligations_count * 12.0),
            "description": f"{overdue_obligations_count} obligation(s) currently overdue."
        })

    deadline_risk = min(20.0, 5.0 + (overdue_obligations_count * 5.0))
    operational_risk = 10.0
    legal_risk = 10.0
    security_risk = 10.0

    # Aggregate Overall Weighted Score (0 to 100)
    total_score = min(100.0, financial_risk + penalty_risk + renewal_risk + min(30.0, compliance_risk))

    # Assign Risk Level Category
    if total_score <= 30.0:
        risk_level = "LOW"
    elif total_score <= 60.0:
        risk_level = "MEDIUM"
    elif total_score <= 80.0:
        risk_level = "HIGH"
    else:
        risk_level = "CRITICAL"

    explanation = f"Contract evaluated with {risk_level} risk (Score: {total_score:.1f}/100) across {len(factors)} identified risk factors."

    return {
        "overall_score": round(total_score, 1),
        "risk_level": risk_level,
        "financial_risk": round(financial_risk, 1),
        "compliance_risk": round(min(30.0, compliance_risk), 1),
        "deadline_risk": round(deadline_risk, 1),
        "penalty_risk": round(penalty_risk, 1),
        "renewal_risk": round(renewal_risk, 1),
        "operational_risk": round(operational_risk, 1),
        "legal_risk": round(legal_risk, 1),
        "security_risk": round(security_risk, 1),
        "factors": factors,
        "explanation": explanation
    }
