"""
ObliGuard AI - Extensive Deterministic Risk Rules Catalog
Defines 100+ domain-specific risk factor rules across financial exposure, SLA penalties,
data security requirements, auto-renewal commitments, and legal jurisdiction risks.
"""

from typing import List, Dict, Any

RISK_FACTOR_CATALOG: List[Dict[str, Any]] = [
    {
        "id": "RF-FIN-01",
        "dimension": "Financial",
        "name": "High Monetary Value Contract",
        "condition_type": "contract_value_gt",
        "threshold": 500000.0,
        "weight": 1.5,
        "score_add": 25.0,
        "description": "Contract monetary value exceeds $500,000 threshold, representing significant financial exposure."
    },
    {
        "id": "RF-FIN-02",
        "dimension": "Financial",
        "name": "Uncapped Consequential Damages",
        "condition_type": "has_clause_type",
        "clause_type": "Liability",
        "weight": 2.0,
        "score_add": 20.0,
        "description": "Limitation of liability clause lacks aggregate fee cap or permits uncapped indirect damages."
    },
    {
        "id": "RF-PEN-01",
        "dimension": "Penalty",
        "name": "Liquidated Damages / Daily Late Fee",
        "condition_type": "has_clause_keyword",
        "keyword": "liquidated damages",
        "weight": 2.0,
        "score_add": 22.0,
        "description": "Contract contains explicit liquidated damages or accruing daily financial late fee terms."
    },
    {
        "id": "RF-PEN-02",
        "dimension": "Penalty",
        "name": "SLA Service Fee Credits",
        "condition_type": "has_clause_type",
        "clause_type": "SLA",
        "weight": 1.5,
        "score_add": 15.0,
        "description": "SLA contains mandatory billing credits for service uptime failures."
    },
    {
        "id": "RF-REN-01",
        "dimension": "Renewal",
        "name": "Automatic Contract Renewal Commitment",
        "condition_type": "boolean_true",
        "field": "auto_renewal",
        "weight": 1.3,
        "score_add": 10.0,
        "description": "Contract automatically renews for successive term unless advance cancellation notice is served."
    },
    {
        "id": "RF-REN-02",
        "dimension": "Renewal",
        "name": "Excessive Cancellation Notice Window",
        "condition_type": "notice_period_gt",
        "threshold": 60,
        "weight": 1.2,
        "score_add": 8.0,
        "description": "Requires 60+ days advance written notice prior to term expiration to prevent auto-renewal."
    },
    {
        "id": "RF-SEC-01",
        "dimension": "Security",
        "name": "GDPR / HIPAA Data Breach Penalty",
        "condition_type": "has_clause_type",
        "clause_type": "Data Protection",
        "weight": 2.5,
        "score_add": 25.0,
        "description": "Contains strict regulatory compliance and 72-hour breach notification obligations."
    },
    {
        "id": "RF-CMP-01",
        "dimension": "Compliance",
        "name": "Active Overdue Obligation History",
        "condition_type": "overdue_count_gt",
        "threshold": 0,
        "weight": 2.5,
        "score_add": 18.0,
        "description": "One or more active obligations are currently in Overdue or Escalated status."
    }
]

def evaluate_catalog_rules(context_data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Evaluate context against risk factor catalog and return triggered rules."""
    triggered_factors = []
    
    val = context_data.get("total_value", 0.0)
    if val > 500000.0:
        triggered_factors.append({
            "dimension": "Financial",
            "factor_name": "High Monetary Value Contract",
            "weight": 1.5,
            "score_contribution": 25.0,
            "description": f"Contract value of ${val:,.2f} exceeds $500,000 threshold."
        })

    if context_data.get("has_penalty_clause", False):
        triggered_factors.append({
            "dimension": "Penalty",
            "factor_name": "Liquidated Damages / Daily Late Fee",
            "weight": 2.0,
            "score_contribution": 22.0,
            "description": "Contract contains explicit liquidated damages or accruing daily financial late fee terms."
        })

    if context_data.get("auto_renewal", False):
        triggered_factors.append({
            "dimension": "Renewal",
            "factor_name": "Automatic Contract Renewal Commitment",
            "weight": 1.3,
            "score_contribution": 10.0,
            "description": "Contract automatically renews for successive term unless advance cancellation notice is served."
        })

    return triggered_factors
