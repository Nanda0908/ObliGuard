"""
ObliGuard AI - Industry Risk Profile Profiles
Provides industry-tailored risk dimension weighting matrices.
"""

from typing import Dict, Any

INDUSTRY_RISK_PROFILES: Dict[str, Dict[str, float]] = {
    "SaaS_Cloud": {
        "financial_weight": 1.2,
        "compliance_weight": 1.8,
        "deadline_weight": 1.5,
        "penalty_weight": 2.0,  # High SLA penalty emphasis
        "renewal_weight": 1.4,
        "operational_weight": 1.5,
        "legal_weight": 1.2,
        "security_weight": 2.5   # Critical SOC 2 / GDPR security emphasis
    },
    "Healthcare": {
        "financial_weight": 1.0,
        "compliance_weight": 3.0,  # Critical HIPAA / PHI emphasis
        "deadline_weight": 1.2,
        "penalty_weight": 1.8,
        "renewal_weight": 1.0,
        "operational_weight": 1.8,
        "legal_weight": 2.0,
        "security_weight": 3.0
    },
    "Financial_Services": {
        "financial_weight": 2.5,  # High monetary liability emphasis
        "compliance_weight": 2.5,  # High SOX / SEC regulatory emphasis
        "deadline_weight": 1.8,
        "penalty_weight": 2.2,
        "renewal_weight": 1.2,
        "operational_weight": 2.0,
        "legal_weight": 2.2,
        "security_weight": 2.5
    },
    "Supply_Chain": {
        "financial_weight": 1.8,
        "compliance_weight": 1.2,
        "deadline_weight": 2.5,  # High delivery date & milestone emphasis
        "penalty_weight": 2.5,  # Liquidated damages on shipping delays
        "renewal_weight": 1.5,
        "operational_weight": 2.5,
        "legal_weight": 1.5,
        "security_weight": 1.0
    }
}

def get_industry_weights(industry: str = "SaaS_Cloud") -> Dict[str, float]:
    """Retrieve dimension weighting profile for specified industry."""
    return INDUSTRY_RISK_PROFILES.get(industry, INDUSTRY_RISK_PROFILES["SaaS_Cloud"])
