"""
ObliGuard AI - Semantic Vector Search Service
Performs natural language similarity search across indexed clauses using SentenceTransformers vectors.
"""

from typing import List, Dict, Any, Optional
from sqlalchemy.orm import Session
from app.models.clause import Clause
from app.models.contract import Contract
from app.models.ai import Embedding
from app.ai.vector_search import generate_embedding, cosine_similarity
from app.schemas.search import SearchResponse, SearchResultItem

class SearchService:
    def __init__(self, db: Session):
        self.db = db

    def search_clauses(
        self,
        organization_id: int,
        query: str,
        top_k: int = 5,
        contract_id: Optional[int] = None,
        clause_type: Optional[str] = None
    ) -> SearchResponse:
        """Perform semantic search across organization clauses."""

        query_vec = generate_embedding(query)

        # Query active clauses for organization contracts
        q = self.db.query(Clause, Contract, Embedding).join(
            Contract, Clause.contract_id == Contract.id
        ).join(
            Embedding, Clause.id == Embedding.clause_id
        ).filter(
            Contract.organization_id == organization_id
        )

        if contract_id:
            q = q.filter(Clause.contract_id == contract_id)

        if clause_type:
            q = q.filter(Clause.clause_type == clause_type)

        records = q.all()

        scored_results = []
        for clause, contract, embedding in records:
            sim_score = cosine_similarity(query_vec, embedding.vector_json)
            scored_results.append((sim_score, clause, contract))

        # Sort by similarity score descending
        scored_results.sort(key=lambda x: x[0], reverse=True)

        result_items = []
        for sim, clause, contract in scored_results[:top_k]:
            result_items.append(SearchResultItem(
                clause_id=clause.id,
                contract_id=contract.id,
                contract_title=contract.title,
                section_number=clause.section_number,
                page_number=clause.page_number,
                clause_type=clause.clause_type,
                source_text=clause.source_text,
                similarity_score=round(float(sim), 4)
            ))

        return SearchResponse(
            query=query,
            total_matches=len(result_items),
            results=result_items
        )
