"""
ObliGuard AI - Obligation & Compliance Lifecycle Service
Manages obligation status transitions, assignments, completion checks, and SLA escalations.
"""

from typing import Optional, List
from sqlalchemy.orm import Session
from app.repositories.obligation_repo import ObligationRepository
from app.models.obligation import Obligation
from app.models.compliance import ComplianceCheck
from app.workflow.state_machine import transition_obligation_status
from app.core.exceptions import ResourceNotFoundException

class ObligationService:
    def __init__(self, db: Session):
        self.db = db
        self.ob_repo = ObligationRepository(db)

    def update_status(self, obligation_id: int, new_status: str, user_id: int) -> Obligation:
        """Execute state machine transition for obligation."""
        obligation = self.ob_repo.get_by_id(obligation_id)
        if not obligation:
            raise ResourceNotFoundException("Obligation", obligation_id)

        validated_status = transition_obligation_status(obligation.status, new_status)
        obligation.status = validated_status

        # Create audit compliance check entry
        check = ComplianceCheck(
            organization_id=obligation.organization_id,
            obligation_id=obligation.id,
            checked_by_id=user_id,
            status="Pass" if validated_status == "Completed" else "Fail",
            notes=f"Obligation status updated to '{validated_status}'."
        )
        self.db.add(check)
        self.db.commit()
        self.db.refresh(obligation)
        return obligation

    def assign_user(self, obligation_id: int, user_id: int) -> Obligation:
        """Assign responsible owner to obligation."""
        obligation = self.ob_repo.get_by_id(obligation_id)
        if not obligation:
            raise ResourceNotFoundException("Obligation", obligation_id)

        obligation.responsible_user_id = user_id
        self.db.commit()
        self.db.refresh(obligation)
        return obligation
