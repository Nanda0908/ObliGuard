"""
ObliGuard AI - Contract Lifecycle & Document Processing Orchestration Service
Orchestrates contract upload, text extraction, clause classification, obligation extraction,
temporal deadline calculation, vector embedding generation, and explainable risk evaluation.
"""

import os
from typing import Dict, Any, List
from sqlalchemy.orm import Session
from app.repositories.contract_repo import ContractRepository
from app.repositories.clause_repo import ClauseRepository
from app.repositories.obligation_repo import ObligationRepository
from app.repositories.risk_repo import RiskRepository
from app.models.contract import Contract, ContractVersion, ContractParty, DocumentChunk
from app.models.clause import Clause
from app.models.obligation import Obligation
from app.models.temporal import Deadline
from app.models.risk import RiskScore, RiskFactor, RiskHistory
from app.models.ai import Embedding

from app.document_processing.pdf_extractor import extract_text_from_pdf
from app.document_processing.docx_extractor import extract_text_from_docx, extract_text_from_txt
from app.document_processing.section_parser import segment_contract_into_clauses
from app.nlp.clause_classifier import classifier_instance
from app.extraction.obligation_extractor import obligation_extractor
from app.temporal_engine.date_parser import temporal_engine
from app.risk_engine.risk_calculator import evaluate_contract_risk
from app.ai.vector_search import generate_embedding

class ContractService:
    def __init__(self, db: Session):
        self.db = db
        self.contract_repo = ContractRepository(db)

    def process_and_create_contract(
        self,
        organization_id: int,
        title: str,
        contract_type: str,
        file_path: str,
        file_name: str,
        file_size: int,
        uploaded_by_id: int,
        total_value: float = 0.0,
        currency: str = "USD"
    ) -> Contract:
        """Execute complete Document & Clause Intelligence Pipeline."""

        # 1. Create base contract entity
        contract = Contract(
            organization_id=organization_id,
            title=title,
            contract_type=contract_type,
            owner_id=uploaded_by_id,
            total_value=total_value,
            currency=currency,
            status="Active"
        )
        self.db.add(contract)
        self.db.commit()
        self.db.refresh(contract)

        # 2. Determine file type and extract text pages
        doc_type = file_name.split(".")[-1].lower()
        if doc_type == "pdf":
            pages_data = extract_text_from_pdf(file_path)
        elif doc_type in ["docx", "doc"]:
            pages_data = extract_text_from_docx(file_path)
        else:
            pages_data = extract_text_from_txt(file_path)

        # 3. Save Contract Version
        version = ContractVersion(
            contract_id=contract.id,
            version_number=1,
            file_name=file_name,
            file_path=file_path,
            file_size=file_size,
            document_type=doc_type,
            uploaded_by_id=uploaded_by_id,
            processing_status="Processing"
        )
        self.db.add(version)
        self.db.commit()
        self.db.refresh(version)

        # 4. Segment contract into clauses
        raw_clauses = segment_contract_into_clauses(pages_data)
        clause_objects = []
        clause_impacts = []

        for c_data in raw_clauses:
            text = c_data["text"]
            sec_num = c_data["section_number"]
            p_num = c_data["page_number"]

            # Clause Intelligence Classification
            classification = classifier_instance.classify_clause(text)
            c_type = classification["clause_type"]
            c_conf = classification["confidence_score"]
            c_risk = classification["risk_impact"]
            clause_impacts.append(c_risk)

            clause_obj = Clause(
                contract_id=contract.id,
                version_id=version.id,
                section_number=sec_num,
                page_number=p_num,
                clause_type=c_type,
                source_text=text,
                confidence_score=c_conf,
                risk_impact=c_risk
            )
            self.db.add(clause_obj)
            self.db.commit()
            self.db.refresh(clause_obj)
            clause_objects.append(clause_obj)

            # Generate Vector Embedding for Semantic Search & RAG
            vec = generate_embedding(text)
            emb = Embedding(clause_id=clause_obj.id, vector_json=vec)
            self.db.add(emb)

            # 5. Extract Obligations from clause
            extracted_obs = obligation_extractor.extract_obligations_from_clause(text, c_type)
            for ob_data in extracted_obs:
                due_dt, is_biz = temporal_engine.resolve_deadline_expression(
                    ob_data["deadline_expression"] or ""
                )

                ob_obj = Obligation(
                    organization_id=organization_id,
                    contract_id=contract.id,
                    clause_id=clause_obj.id,
                    obligation_type=ob_data["obligation_type"],
                    party=ob_data["party"],
                    action=ob_data["action"],
                    object_target=ob_data["object_target"],
                    deadline_expression=ob_data["deadline_expression"],
                    frequency=ob_data["frequency"],
                    condition=ob_data["condition"],
                    penalty_summary=ob_data["penalty_summary"],
                    priority=ob_data["priority"],
                    status="Upcoming",
                    due_date=due_dt,
                    confidence_score=ob_data["confidence_score"]
                )
                self.db.add(ob_obj)
                self.db.commit()
                self.db.refresh(ob_obj)

                # Save calculated deadline
                deadline = Deadline(
                    obligation_id=ob_obj.id,
                    deadline_date=due_dt,
                    original_expression=ob_data["deadline_expression"],
                    is_business_days=is_biz
                )
                self.db.add(deadline)

        # 6. Risk Intelligence Engine Evaluation
        risk_result = evaluate_contract_risk(
            contract_value=total_value,
            has_penalty_clause="Penalty" in clause_impacts or "CRITICAL" in clause_impacts,
            clause_risk_impacts=clause_impacts
        )

        risk_score_obj = RiskScore(
            contract_id=contract.id,
            overall_score=risk_result["overall_score"],
            risk_level=risk_result["risk_level"],
            financial_risk=risk_result["financial_risk"],
            compliance_risk=risk_result["compliance_risk"],
            deadline_risk=risk_result["deadline_risk"],
            penalty_risk=risk_result["penalty_risk"],
            renewal_risk=risk_result["renewal_risk"],
            operational_risk=risk_result["operational_risk"],
            legal_risk=risk_result["legal_risk"],
            security_risk=risk_result["security_risk"],
            explanation_json={"explanation": risk_result["explanation"]}
        )
        self.db.add(risk_score_obj)
        self.db.commit()
        self.db.refresh(risk_score_obj)

        for factor in risk_result["factors"]:
            rf = RiskFactor(
                risk_score_id=risk_score_obj.id,
                dimension=factor["dimension"],
                factor_name=factor["factor_name"],
                weight=factor["weight"],
                score_contribution=factor["score_contribution"],
                description=factor["description"]
            )
            self.db.add(rf)

        # Record Risk History
        rh = RiskHistory(
            contract_id=contract.id,
            score=risk_result["overall_score"],
            risk_level=risk_result["risk_level"],
            change_reason="Initial automated contract intelligence processing."
        )
        self.db.add(rh)

        # Update contract status and processing completion
        contract.risk_score = risk_result["overall_score"]
        contract.risk_level = risk_result["risk_level"]
        version.processing_status = "Completed"

        self.db.commit()
        self.db.refresh(contract)
        return contract
