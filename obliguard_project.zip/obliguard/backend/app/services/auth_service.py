"""
ObliGuard AI - Authentication & User Domain Service
Handles organization bootstrap, registration, login verification, and RBAC token generation.
"""

from typing import Dict, Any
from sqlalchemy.orm import Session
from app.repositories.user_repo import UserRepository, OrganizationRepository
from app.core.security import get_password_hash, verify_password, create_access_token
from app.core.exceptions import AuthenticationException, ValidationException
from app.schemas.auth import RegisterRequest, LoginRequest, Token

class AuthService:
    def __init__(self, db: Session):
        self.db = db
        self.user_repo = UserRepository(db)
        self.org_repo = OrganizationRepository(db)

    def register(self, request: RegisterRequest) -> Token:
        """Register a new Organization Admin and bootstrap organization context."""
        existing_user = self.user_repo.get_by_email(request.email)
        if existing_user:
            raise ValidationException(f"User with email '{request.email}' already exists.")

        # Create or fetch organization
        slug = request.organization_name.lower().replace(" ", "-")
        org = self.org_repo.get_by_slug(slug)
        if not org:
            org = self.org_repo.create({
                "name": request.organization_name,
                "slug": slug,
                "domain": request.email.split("@")[-1]
            })

        # Password hashing
        hashed_pwd = get_password_hash(request.password)

        # Create User with Organization Admin role
        user = self.user_repo.create({
            "organization_id": org.id,
            "email": request.email.lower(),
            "password_hash": hashed_pwd,
            "full_name": request.full_name,
            "role_name": "Organization Admin",
            "is_verified": True
        })

        token_str = create_access_token(
            subject=user.id,
            organization_id=org.id,
            role=user.role_name
        )

        return Token(
            access_token=token_str,
            user_id=user.id,
            organization_id=org.id,
            role=user.role_name,
            full_name=user.full_name
        )

    def login(self, request: LoginRequest) -> Token:
        """Authenticate user login credentials."""
        user = self.user_repo.get_by_email(request.email)
        if not user or not verify_password(request.password, user.password_hash):
            raise AuthenticationException("Invalid email or password.")

        if not user.is_active:
            raise AuthenticationException("Account is deactivated. Contact organization administrator.")

        token_str = create_access_token(
            subject=user.id,
            organization_id=user.organization_id,
            role=user.role_name
        )

        return Token(
            access_token=token_str,
            user_id=user.id,
            organization_id=user.organization_id,
            role=user.role_name,
            full_name=user.full_name
        )
