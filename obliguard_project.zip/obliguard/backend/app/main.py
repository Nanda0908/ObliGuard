"""
ObliGuard AI - Primary FastAPI Application Entrypoint
Assembles domain routers, CORS middleware, global exception handlers, and database initializers.
"""

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import settings
from app.database import engine, Base
from app.core.logging import setup_logging, logger
from app.core.exceptions import ObliGuardException

# Import Routers
from app.routers import (
    auth, contracts, obligations, clauses, risks,
    search, rag, comparison, analytics, reports,
    users, audit, saas, system
)

setup_logging()

# Create Database Tables automatically for development
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="AI-Powered Contract Obligation, Risk & Compliance Intelligence SaaS Platform",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Configure CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global Exception Handler
@app.exception_handler(ObliGuardException)
async def obliguard_exception_handler(request: Request, exc: ObliGuardException):
    logger.error(f"Domain Exception [{exc.code}]: {exc.message}")
    return JSONResponse(
        status_code=400,
        content={
            "error": exc.code,
            "message": exc.message,
            "details": exc.details
        }
    )

# Include Routers with API_V1 Prefix
api_prefix = settings.API_V1_STR
app.include_router(auth.router, prefix=api_prefix)
app.include_router(contracts.router, prefix=api_prefix)
app.include_router(obligations.router, prefix=api_prefix)
app.include_router(clauses.router, prefix=api_prefix)
app.include_router(risks.router, prefix=api_prefix)
app.include_router(search.router, prefix=api_prefix)
app.include_router(rag.router, prefix=api_prefix)
app.include_router(comparison.router, prefix=api_prefix)
app.include_router(analytics.router, prefix=api_prefix)
app.include_router(reports.router, prefix=api_prefix)
app.include_router(users.router, prefix=api_prefix)
app.include_router(audit.router, prefix=api_prefix)
app.include_router(saas.router, prefix=api_prefix)
app.include_router(system.router)  # /health and /ready at root

@app.get("/")
def root():
    return {
        "title": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "status": "Operational",
        "docs": "/docs"
    }
