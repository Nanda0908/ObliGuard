"""
ObliGuard AI - Obligation Extraction Engine
Parses legal clause sentences to identify contractual modal language, responsible parties,
target actions, deadlines, frequencies, conditions, and penalties.
"""

import re
from typing import List, Dict, Any, Optional

MODAL_PATTERNS = [
    r"\bshall\b", r"\bmust\b", r"\bis required to\b", r"\bare required to\b",
    r"\bagrees to\b", r"\bagree to\b", r"\bwill\b", r"\bis responsible for\b",
    r"\bare responsible for\b", r"\bis obligated to\b", r"\bundertakes to\b"
]

MODAL_REGEX = re.compile("|".join(MODAL_PATTERNS), re.IGNORECASE)

DEADLINE_REGEX = re.compile(
    r"(?i)(within\s+\d+\s*(?:business\s+days|calendar\s+days|days|weeks|months)|"
    r"no\s+later\s+than\s+[^,\.\n]+|"
    r"prior\s+to\s+[^,\.\n]+|"
    r"by\s+(?:january|february|march|april|may|june|july|august|september|october|november|december)\s+\d{1,2}(?:,\s*\d{4})?)"
)

FREQUENCY_REGEX = re.compile(
    r"(?i)\b(daily|weekly|bi-weekly|monthly|quarterly|semi-annually|annually|yearly|each\s+quarter|each\s+month)\b"
)

ACTION_VERBS = [
    "submit", "notify", "pay", "provide", "maintain", "deliver", "perform",
    "comply", "indemnify", "obtain", "audit", "report", "renew", "terminate"
]

class ObligationExtractorEngine:
    """Extracts structured obligations from contractual clauses."""

    def extract_obligations_from_clause(self, clause_text: str, clause_type: str) -> List[Dict[str, Any]]:
        """Identify sentences with modal obligation keywords and extract structured fields."""
        obligations = []
        
        # Split clause into sentences
        sentences = re.split(r"(?<=[.\n])\s+", clause_text)
        
        for sentence in sentences:
            sentence_clean = sentence.strip()
            if not sentence_clean or len(sentence_clean) < 15:
                continue

            # Check if sentence contains modal language indicating binding obligation
            if MODAL_REGEX.search(sentence_clean):
                obligation_data = self._parse_obligation_sentence(sentence_clean, clause_type)
                if obligation_data:
                    obligations.append(obligation_data)

        return obligations

    def _parse_obligation_sentence(self, sentence: str, clause_type: str) -> Optional[Dict[str, Any]]:
        """Parse single sentence into structured Obligation dictionary."""
        
        # Identify responsible party
        party = "Responsible Party"
        if re.search(r"\bvendor\b|\bsupplier\b|\bprovider\b", sentence, re.IGNORECASE):
            party = "Vendor"
        elif re.search(r"\bcustomer\b|\bclient\b|\blicensee\b|\bcompany\b", sentence, re.IGNORECASE):
            party = "Customer"
        elif re.search(r"\bcontractor\b|\bconsultant\b", sentence, re.IGNORECASE):
            party = "Contractor"
        elif re.search(r"\beither party\b|\bboth parties\b", sentence, re.IGNORECASE):
            party = "Both Parties"

        # Extract action verb
        action = "Fulfill Obligation"
        for verb in ACTION_VERBS:
            if re.search(rf"\b{verb}\b", sentence, re.IGNORECASE):
                action = verb.capitalize()
                break

        # Extract deadline expression
        deadline_match = DEADLINE_REGEX.search(sentence)
        deadline_expr = deadline_match.group(0).strip() if deadline_match else None

        # Extract frequency
        freq_match = FREQUENCY_REGEX.search(sentence)
        frequency = freq_match.group(0).capitalize() if freq_match else "One-Time"

        # Determine obligation type mapping
        obligation_type = self._map_obligation_type(clause_type, sentence)

        # Determine priority
        priority = "MEDIUM"
        if re.search(r"\bimmediate\b|\bpenalty\b|\bliquidated damages\b|\btermination\b", sentence, re.IGNORECASE):
            priority = "HIGH"
        if re.search(r"\bwithin 24 hours\b|\bwithin 48 hours\b|\breach\b", sentence, re.IGNORECASE):
            priority = "CRITICAL"

        # Extract penalty summary
        penalty_summary = None
        penalty_match = re.search(r"(?i)(penalty|late fee|interest|fine)[^,\.\n]*", sentence)
        if penalty_match:
            penalty_summary = penalty_match.group(0).strip()

        return {
            "obligation_type": obligation_type,
            "party": party,
            "action": action,
            "object_target": sentence[:150],
            "deadline_expression": deadline_expr,
            "frequency": frequency,
            "condition": "Subject to contract execution and terms",
            "penalty_summary": penalty_summary,
            "priority": priority,
            "confidence_score": 0.92
        }

    def _map_obligation_type(self, clause_type: str, sentence: str) -> str:
        """Map clause category and sentence keywords to standardized Obligation Type."""
        sentence_lower = sentence.lower()
        if "report" in sentence_lower or "submit" in sentence_lower or clause_type == "Reporting":
            return "Reporting"
        if "pay" in sentence_lower or "fee" in sentence_lower or clause_type == "Payment":
            return "Payment"
        if "audit" in sentence_lower or clause_type == "Audit":
            return "Audit"
        if "sla" in sentence_lower or "uptime" in sentence_lower or clause_type == "SLA":
            return "SLA"
        if "notice" in sentence_lower or "notify" in sentence_lower:
            return "Notice"
        if "security" in sentence_lower or clause_type == "Security":
            return "Security"
        return "Compliance"

obligation_extractor = ObligationExtractorEngine()
