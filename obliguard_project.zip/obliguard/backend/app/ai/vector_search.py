"""
ObliGuard AI - Vector Embedding & Local Semantic Search Engine
Generates dense embeddings via SentenceTransformers and calculates cosine similarity rankings.
100% offline — zero external cloud API keys required.
"""

import math
from typing import List, Dict, Any, Optional
from app.config import settings
from app.core.logging import logger

_model_instance = None

def get_embedding_model():
    """Lazy load SentenceTransformers model."""
    global _model_instance
    if _model_instance is None:
        try:
            from sentence_transformers import SentenceTransformer
            _model_instance = SentenceTransformer(settings.EMBEDDING_MODEL_NAME)
        except Exception as e:
            logger.warning(f"SentenceTransformers load warning: {str(e)}. Using fallback feature vectorizer.")
            _model_instance = False
    return _model_instance

def generate_embedding(text: str) -> List[float]:
    """Generate dense vector embedding for text snippet."""
    model = get_embedding_model()
    if model and hasattr(model, "encode"):
        try:
            vec = model.encode(text, convert_to_numpy=True)
            return vec.tolist()
        except Exception as e:
            logger.error(f"Embedding error: {str(e)}")
            
    # Fallback 384-dim dummy vector if model unavailable
    words = text.lower().split()
    vector = [0.0] * 384
    for i, w in enumerate(words[:384]):
        vector[i % 384] += (len(w) * 0.01)
    return vector

def cosine_similarity(vec1: List[float], vec2: List[float]) -> float:
    """Calculate cosine similarity score between two float vectors."""
    if not vec1 or not vec2 or len(vec1) != len(vec2):
        return 0.0
    dot_prod = sum(a * b for a, b in zip(vec1, vec2))
    mag1 = math.sqrt(sum(a * a for a in vec1))
    mag2 = math.sqrt(sum(b * b for b in vec2))
    if mag1 == 0 or mag2 == 0:
        return 0.0
    return dot_prod / (mag1 * mag2)
