"""
ObliGuard AI - Grounded Local RAG Contract Assistant Engine
Synthesizes contract answers from retrieved clauses using local Ollama LLM or local grounded synthesizer.
Uses standard library urllib.request for Ollama connection.
"""

import time
import json
import urllib.request
from typing import List, Dict, Any, Optional
from app.config import settings
from app.core.logging import logger

class RAGAssistantEngine:
    """Grounded RAG Assistant providing evidence-backed answers from indexed clauses."""

    def generate_grounded_answer(
        self,
        question: str,
        retrieved_clauses: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Build context from retrieved clauses and query local LLM / synthesizer.
        """
        start_time = time.time()

        if not retrieved_clauses:
            return {
                "question": question,
                "answer": "Insufficient evidence found in the indexed contract content to answer this question.",
                "sources": [],
                "is_grounded": True,
                "execution_time_seconds": round(time.time() - start_time, 2)
            }

        # Build context blocks and sources list
        context_blocks = []
        sources = []
        for i, item in enumerate(retrieved_clauses, 1):
            clause_text = item.get("source_text", "")
            c_title = item.get("contract_title", "Contract")
            sec_num = item.get("section_number", "General")
            page_num = item.get("page_number", 1)
            c_type = item.get("clause_type", "Clause")

            context_blocks.append(
                f"--- EXCERPT {i} ---\n"
                f"Contract: {c_title}\n"
                f"Section: {sec_num} (Page {page_num})\n"
                f"Type: {c_type}\n"
                f"Content: {clause_text}\n"
            )

            sources.append({
                "contract_id": item.get("contract_id", 0),
                "contract_title": c_title,
                "section_number": sec_num,
                "page_number": page_num,
                "clause_type": c_type,
                "excerpt": clause_text[:120] + "..."
            })

        joined_context = "\n".join(context_blocks)

        # Attempt query to local Ollama service
        ollama_answer = self._query_ollama(question, joined_context)
        if ollama_answer:
            return {
                "question": question,
                "answer": ollama_answer,
                "sources": sources,
                "is_grounded": True,
                "execution_time_seconds": round(time.time() - start_time, 2)
            }

        # Fallback Local Grounded Synthesizer
        synthetic_answer = self._synthesize_fallback_answer(question, retrieved_clauses, sources)
        return {
            "question": question,
            "answer": synthetic_answer,
            "sources": sources,
            "is_grounded": True,
            "execution_time_seconds": round(time.time() - start_time, 2)
        }

    def _query_ollama(self, question: str, context: str) -> Optional[str]:
        """Send prompt to local Ollama service if running."""
        try:
            url = f"{settings.OLLAMA_BASE_URL}/api/generate"
            prompt = (
                f"You are ObliGuard AI legal contract assistant. Answer the user's question based strictly on the context provided below.\n"
                f"Do not invent facts. Cite section numbers and contract titles.\n\n"
                f"CONTEXT:\n{context}\n\n"
                f"QUESTION: {question}\n\n"
                f"ANSWER:"
            )
            req = urllib.request.Request(
                url,
                data=json.dumps({"model": settings.OLLAMA_MODEL, "prompt": prompt, "stream": False}).encode(),
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=4) as response:
                data = json.loads(response.read().decode())
                return data.get("response", "").strip()
        except Exception:
            pass
        return None

    def _synthesize_fallback_answer(
        self,
        question: str,
        retrieved_clauses: List[Dict[str, Any]],
        sources: List[Dict[str, Any]]
    ) -> str:
        """Create deterministic evidence-backed response when Ollama is offline."""
        top_clause = retrieved_clauses[0]
        c_title = top_clause.get("contract_title", "Contract")
        sec_num = top_clause.get("section_number", "Section")
        text = top_clause.get("source_text", "")

        return (
            f"Based on contractual analysis of **{c_title}** (Section {sec_num}), "
            f"the contract specifies: \"{text[:200]}...\". "
            f"Please inspect the cited source clauses below for full details."
        )

rag_assistant = RAGAssistantEngine()
