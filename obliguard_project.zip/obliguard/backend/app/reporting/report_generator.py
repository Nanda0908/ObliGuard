"""
ObliGuard AI - Executive Report Generator Engine
Generates PDF, CSV, and JSON contract intelligence reports.
"""

import os
import csv
import json
from datetime import datetime, timezone
from typing import Dict, Any, List
from app.config import settings

def generate_enterprise_report(
    report_type: str,
    organization_name: str,
    data: Dict[str, Any],
    file_format: str = "PDF"
) -> str:
    """Generate report file and return local filepath."""
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    file_format = file_format.upper()
    filename = f"report_{report_type.lower()}_{timestamp}.{file_format.lower()}"
    filepath = os.path.join(settings.REPORTS_DIR, filename)

    if file_format == "CSV":
        _write_csv_report(filepath, data)
    elif file_format == "JSON":
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump({"organization": organization_name, "generated_at": timestamp, "data": data}, f, indent=2)
    else:
        # Default PDF / Text Report generator
        _write_text_pdf_report(filepath, report_type, organization_name, timestamp, data)

    return filepath

def _write_csv_report(filepath: str, data: Dict[str, Any]):
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Metric / Item", "Value / Details"])
        for k, v in data.items():
            writer.writerow([k, str(v)])

def _write_text_pdf_report(filepath: str, report_type: str, org_name: str, timestamp: str, data: Dict[str, Any]):
    with open(filepath, "w", encoding="utf-8") as f:
        f.write("============================================================\n")
        f.write(f"OBLIGUARD AI — {report_type.upper()} REPORT\n")
        f.write("============================================================\n")
        f.write(f"Organization: {org_name}\n")
        f.write(f"Generated At: {timestamp}\n\n")
        f.write("METRICS SUMMARY:\n")
        for k, v in data.items():
            f.write(f"  - {k}: {v}\n")
        f.write("\n============================================================\n")
