"""
ObliGuard AI - Application Configuration
Handles environment settings, database URLs, JWT configurations, security defaults,
Ollama/Local AI settings, and document storage directories.
"""

import os
from typing import List, Optional
from pydantic import BaseModel

class Settings(BaseModel):
    PROJECT_NAME: str = "ObliGuard AI"
    VERSION: str = "1.0.0"
    API_V1_STR: str = "/api/v1"
    ENVIRONMENT: str = os.getenv("ENVIRONMENT", "development")
    DEBUG: bool = True

    # Security & Auth
    SECRET_KEY: str = os.getenv(
        "SECRET_KEY",
        "obliguard_super_secret_jwt_key_342c7979_458b_4814_aed8_027203ab453f_enterprise_grade_2026"
    )
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 days

    # Database
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./obliguard.db")

    # Storage
    STORAGE_DIR: str = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "uploads")
    REPORTS_DIR: str = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "reports")

    # Local AI & NLP Configuration (100% Offline / Zero external API keys)
    OLLAMA_BASE_URL: str = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    OLLAMA_MODEL: str = "llama3:8b-instruct-q4_K_M"
    EMBEDDING_MODEL_NAME: str = "sentence-transformers/all-MiniLM-L6-v2"
    ENABLE_LOCAL_LLM: bool = True
    NLP_MODEL_PATH: str = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ml_models")

    # Redis & Celery
    REDIS_URL: str = os.getenv("REDIS_URL", "redis://localhost:6379/0")

    # CORS
    BACKEND_CORS_ORIGINS: List[str] = [
        "http://localhost:5173",
        "http://localhost:3000",
        "http://127.0.0.1:5173",
        "http://127.0.0.1:3000",
        "*"
    ]

settings = Settings()

# Ensure storage directories exist
os.makedirs(settings.STORAGE_DIR, exist_ok=True)
os.makedirs(settings.REPORTS_DIR, exist_ok=True)
os.makedirs(settings.NLP_MODEL_PATH, exist_ok=True)
