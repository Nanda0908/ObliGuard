"""
ObliGuard AI - Contract Repository
Database operations for contracts, versions, parties, and document chunks.
"""

from typing import Optional, List
from sqlalchemy.orm import Session
from sqlalchemy import or_, and_
from app.models.contract import Contract, ContractVersion, ContractParty, DocumentChunk
from app.repositories.base import BaseRepository

class ContractRepository(BaseRepository[Contract]):
    def __init__(self, db: Session):
        super().__init__(Contract, db)

    def search_contracts(
        self,
        organization_id: int,
        query: Optional[str] = None,
        contract_type: Optional[str] = None,
        status: Optional[str] = None,
        risk_level: Optional[str] = None,
        department_id: Optional[int] = None,
        skip: int = 0,
        limit: int = 50
    ) -> List[Contract]:
        q = self.db.query(Contract).filter(Contract.organization_id == organization_id)
        
        if query:
            search_pattern = f"%{query}%"
            q = q.filter(
                or_(
                    Contract.title.ilike(search_pattern),
                    Contract.contract_number.ilike(search_pattern),
                    Contract.description.ilike(search_pattern)
                )
            )
            
        if contract_type:
            q = q.filter(Contract.contract_type == contract_type)
            
        if status:
            q = q.filter(Contract.status == status)
            
        if risk_level:
            q = q.filter(Contract.risk_level == risk_level)
            
        if department_id:
            q = q.filter(Contract.department_id == department_id)
            
        return q.order_by(Contract.created_at.desc()).offset(skip).limit(limit).all()

    def get_contract_version(self, version_id: int) -> Optional[ContractVersion]:
        return self.db.query(ContractVersion).filter(ContractVersion.id == version_id).first()
