"""
ObliGuard AI - Obligation Repository
Database operations for extracted obligations, assignments, and deadlines.
"""

from typing import Optional, List
from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy import or_, and_
from app.models.obligation import Obligation, ObligationAssignment
from app.models.temporal import Deadline
from app.repositories.base import BaseRepository

class ObligationRepository(BaseRepository[Obligation]):
    def __init__(self, db: Session):
        super().__init__(Obligation, db)

    def get_filtered_obligations(
        self,
        organization_id: int,
        contract_id: Optional[int] = None,
        obligation_type: Optional[str] = None,
        status: Optional[str] = None,
        priority: Optional[str] = None,
        assigned_user_id: Optional[int] = None,
        skip: int = 0,
        limit: int = 50
    ) -> List[Obligation]:
        q = self.db.query(Obligation).filter(Obligation.organization_id == organization_id)
        
        if contract_id:
            q = q.filter(Obligation.contract_id == contract_id)
            
        if obligation_type:
            q = q.filter(Obligation.obligation_type == obligation_type)
            
        if status:
            q = q.filter(Obligation.status == status)
            
        if priority:
            q = q.filter(Obligation.priority == priority)
            
        if assigned_user_id:
            q = q.filter(Obligation.responsible_user_id == assigned_user_id)
            
        return q.order_by(Obligation.due_date.asc().nullslast()).offset(skip).limit(limit).all()

    def get_upcoming_deadlines(self, organization_id: int, before_date: datetime) -> List[Obligation]:
        return self.db.query(Obligation).filter(
            Obligation.organization_id == organization_id,
            Obligation.due_date <= before_date,
            Obligation.status.in_(["Pending", "Upcoming", "Due"])
        ).all()
