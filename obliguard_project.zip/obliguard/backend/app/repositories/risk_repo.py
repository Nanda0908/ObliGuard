"""
ObliGuard AI - Risk & Compliance Repositories
Database operations for risk scoring, factor breakdown, violations, and compliance checks.
"""

from typing import Optional, List
from sqlalchemy.orm import Session
from app.models.risk import RiskScore, RiskFactor, RiskEvent, RiskHistory
from app.models.compliance import ComplianceCheck, Violation, Penalty
from app.repositories.base import BaseRepository

class RiskRepository(BaseRepository[RiskScore]):
    def __init__(self, db: Session):
        super().__init__(RiskScore, db)

    def get_latest_by_contract(self, contract_id: int) -> Optional[RiskScore]:
        return self.db.query(RiskScore).filter(
            RiskScore.contract_id == contract_id
        ).order_by(RiskScore.calculated_at.desc()).first()

    def get_contract_risk_history(self, contract_id: int) -> List[RiskHistory]:
        return self.db.query(RiskHistory).filter(
            RiskHistory.contract_id == contract_id
        ).order_by(RiskHistory.recorded_at.asc()).all()

class ComplianceRepository(BaseRepository[ComplianceCheck]):
    def __init__(self, db: Session):
        super().__init__(ComplianceCheck, db)

    def get_org_violations(self, organization_id: int, status: Optional[str] = None) -> List[Violation]:
        q = self.db.query(Violation).filter(Violation.organization_id == organization_id)
        if status:
            q = q.filter(Violation.status == status)
        return q.order_by(Violation.created_at.desc()).all()
