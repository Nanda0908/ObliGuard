"""
ObliGuard AI - User & Organization Repository
Database operations for users, roles, organizations, and departments.
"""

from typing import Optional, List
from sqlalchemy.orm import Session
from app.models.user import User, Role, Permission
from app.models.organization import Organization, Department
from app.repositories.base import BaseRepository

class UserRepository(BaseRepository[User]):
    def __init__(self, db: Session):
        super().__init__(User, db)

    def get_by_email(self, email: str) -> Optional[User]:
        return self.db.query(User).filter(User.email == email.lower()).first()

    def get_org_users(self, organization_id: int) -> List[User]:
        return self.db.query(User).filter(User.organization_id == organization_id).all()

class OrganizationRepository(BaseRepository[Organization]):
    def __init__(self, db: Session):
        super().__init__(Organization, db)

    def get_by_slug(self, slug: str) -> Optional[Organization]:
        return self.db.query(Organization).filter(Organization.slug == slug.lower()).first()

    def get_by_name(self, name: str) -> Optional[Organization]:
        return self.db.query(Organization).filter(Organization.name == name).first()
