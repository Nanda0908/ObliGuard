"""
ObliGuard AI - Clause Repository
Database operations for clauses.
"""

from typing import Optional, List
from sqlalchemy.orm import Session
from app.models.clause import Clause
from app.models.contract import Contract
from app.repositories.base import BaseRepository

class ClauseRepository(BaseRepository[Clause]):
    def __init__(self, db: Session):
        super().__init__(Clause, db)

    def get_clauses(
        self,
        organization_id: int,
        contract_id: Optional[int] = None,
        clause_type: Optional[str] = None,
        skip: int = 0,
        limit: int = 50
    ) -> List[Clause]:
        q = self.db.query(Clause).join(Contract, Clause.contract_id == Contract.id).filter(
            Contract.organization_id == organization_id
        )

        if contract_id:
            q = q.filter(Clause.contract_id == contract_id)

        if clause_type:
            q = q.filter(Clause.clause_type == clause_type)

        return q.offset(skip).limit(limit).all()
