"""
ObliGuard AI - Contract Section & Clause Segmenter
Parses raw page streams into structured sections, clauses, and paragraph chunks.
"""

import re
from typing import List, Dict, Any

SECTION_HEADER_REGEX = re.compile(
    r"(?i)^(section|article|clause|\d+\.\d+|\d+\.)\s*([0-9A-Z\.\:\-\s]+)$",
    re.MULTILINE
)

def segment_contract_into_clauses(pages_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Segment page data into discrete clauses with section numbers, page numbers, and text.
    Returns: [{"section_number": str, "page_number": int, "text": str}]
    """
    segmented_clauses = []
    
    current_section = "1.0"
    
    for page in pages_data:
        page_num = page["page_number"]
        text = page["text"]
        
        # Split text into paragraphs
        paragraphs = text.split("\n\n")
        
        for p in paragraphs:
            p_clean = p.strip()
            if not p_clean:
                continue
                
            # Check if paragraph begins with a section identifier
            first_line = p_clean.split("\n")[0].strip()
            match = SECTION_HEADER_REGEX.match(first_line)
            if match:
                current_section = match.group(0).strip()[:50]
                
            # If paragraph contains meaningful sentence length, treat as clause
            if len(p_clean) > 25:
                segmented_clauses.append({
                    "section_number": current_section,
                    "page_number": page_num,
                    "text": p_clean
                })
                
    return segmented_clauses
