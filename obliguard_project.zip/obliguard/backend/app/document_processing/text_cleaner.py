"""
ObliGuard AI - Text Cleaning & Normalization Engine
Strips headers, footers, page numbers, and normalizes legal contract text.
"""

import re

def clean_contract_text(text: str) -> str:
    """Clean and normalize raw extracted contract text."""
    if not text:
        return ""

    # Replace non-breaking spaces and special unicode quotes/dashes
    cleaned = text.replace("\u00a0", " ").replace("\r\n", "\n")
    cleaned = cleaned.replace("“", '"').replace("”", '"').replace("’", "'")
    
    # Strip repeating page number headers/footers like "Page 1 of 12"
    cleaned = re.sub(r"(?i)page\s+\d+\s+of\s+\d+", "", cleaned)
    cleaned = re.sub(r"(?i)confidential\s+-\s+all\s+rights\s+reserved", "", cleaned)
    
    # Normalize multiple whitespace characters
    cleaned = re.sub(r"[ \t]+", " ", cleaned)
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
    
    return cleaned.strip()
