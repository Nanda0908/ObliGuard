"""
ObliGuard AI - PDF Document Extractor Engine
Extracts page-by-page text using PyMuPDF (fitz) or standard layout parser.
"""

import os
from typing import List, Dict, Any
from app.core.exceptions import DocumentProcessingException
from app.document_processing.text_cleaner import clean_contract_text

def extract_text_from_pdf(file_path: str) -> List[Dict[str, Any]]:
    """
    Extract text page by page from PDF file with fallback text reader.
    """
    if not os.path.exists(file_path):
        raise DocumentProcessingException(f"PDF file not found at path: '{file_path}'")

    pages_data = []
    try:
        import fitz
        doc = fitz.open(file_path)
        for page_index in range(len(doc)):
            page = doc[page_index]
            page_num = page_index + 1
            raw_text = page.get_text("text")
            cleaned_text = clean_contract_text(raw_text)
            pages_data.append({
                "page_number": page_num,
                "text": cleaned_text,
                "is_scanned": len(cleaned_text.strip()) < 20,
                "raw_text": raw_text
            })
        doc.close()
        return pages_data
    except Exception:
        # Fallback file reader if fitz is not installed
        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
            cleaned = clean_contract_text(content)
            return [{
                "page_number": 1,
                "text": cleaned,
                "is_scanned": False,
                "raw_text": content
            }]
        except Exception as e:
            raise DocumentProcessingException(f"Failed to process PDF document: {str(e)}")
