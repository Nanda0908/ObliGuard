"""
ObliGuard AI - DOCX & TXT Document Extractor Engine
Extracts paragraph text, section titles, and layout blocks from Microsoft Word files and plain text documents.
"""

import os
from typing import List, Dict, Any
from app.core.exceptions import DocumentProcessingException
from app.document_processing.text_cleaner import clean_contract_text

try:
    import docx
except ImportError:
    docx = None

def extract_text_from_docx(file_path: str) -> List[Dict[str, Any]]:
    """Extract paragraph blocks from DOCX file with fallback text reader."""
    if not os.path.exists(file_path):
        raise DocumentProcessingException(f"DOCX file not found at path: '{file_path}'")

    if docx is not None:
        try:
            doc = docx.Document(file_path)
            full_text_paragraphs = []
            for i, p in enumerate(doc.paragraphs):
                text = clean_contract_text(p.text)
                if text:
                    full_text_paragraphs.append(text)

            joined_text = "\n\n".join(full_text_paragraphs)
            return [{
                "page_number": 1,
                "text": joined_text,
                "is_scanned": False,
                "raw_text": joined_text
            }]
        except Exception:
            pass

    # Fallback plain text reading for DOCX files
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
        cleaned = clean_contract_text(content)
        return [{
            "page_number": 1,
            "text": cleaned,
            "is_scanned": False,
            "raw_text": content
        }]
    except Exception as e:
        raise DocumentProcessingException(f"Failed to process DOCX file: {str(e)}")

def extract_text_from_txt(file_path: str) -> List[Dict[str, Any]]:
    """Extract plain text file."""
    if not os.path.exists(file_path):
        raise DocumentProcessingException(f"TXT file not found at path: '{file_path}'")

    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
        cleaned = clean_contract_text(content)
        return [{
            "page_number": 1,
            "text": cleaned,
            "is_scanned": False,
            "raw_text": content
        }]
    except Exception as e:
        raise DocumentProcessingException(f"Failed to read TXT file: {str(e)}")
