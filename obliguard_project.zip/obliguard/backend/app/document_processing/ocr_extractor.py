"""
ObliGuard AI - OCR Engine (Tesseract Fallback)
Performs Optical Character Recognition on scanned PDF pages or image assets.
Runs with graceful fallback if Tesseract is not installed locally.
"""

from typing import Optional
from app.core.logging import logger

def perform_ocr_on_page_bytes(image_bytes: bytes) -> str:
    """Run Tesseract OCR on raw image bytes."""
    try:
        import pytesseract
        from PIL import Image
        import io

        image = Image.open(io.BytesIO(image_bytes))
        ocr_text = pytesseract.image_to_string(image)
        return ocr_text.strip()
    except Exception as e:
        logger.warning(f"OCR execution skipped or unavailable: {str(e)}")
        return ""
