"""
ObliGuard AI - Structured Logging System
Configures JSON logging for production observability and standard formatted logs for development.
"""

import logging
import sys
from app.config import settings

def setup_logging():
    """Initialize structured application logger."""
    log_level = logging.DEBUG if settings.DEBUG else logging.INFO
    
    formatter = logging.Formatter(
        "[%(asctime)s] [%(levelname)s] [%(name)s:%(lineno)d] - %(message)s"
    )
    
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)
    
    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)
    root_logger.addHandler(handler)
    
    # Silence verbose third-party loggers
    for logger_name in ["urllib3", "pdfminer", "transformers", "torch", "sentence_transformers"]:
        logging.getLogger(logger_name).setLevel(logging.WARNING)

logger = logging.getLogger("obliguard")
