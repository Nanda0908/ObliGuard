"""
ObliGuard AI - Role-Based Access Control (RBAC) & Permissions Core
Defines roles, granular permission matrices, and backend authorization checkers.
"""

from enum import Enum
from typing import Dict, Set, List
from app.core.exceptions import PermissionDeniedException

class RoleName(str, Enum):
    SUPER_ADMIN = "Super Admin"
    ORG_ADMIN = "Organization Admin"
    LEGAL_MANAGER = "Legal Manager"
    CONTRACT_MANAGER = "Contract Manager"
    EMPLOYEE = "Employee"
    VIEWER = "Viewer"

class Permission(str, Enum):
    # System Administration
    SYSTEM_MANAGE = "system:manage"
    SYSTEM_HEALTH_VIEW = "system:health:view"
    
    # Organization Management
    ORG_VIEW = "org:view"
    ORG_EDIT = "org:edit"
    ORG_USERS_MANAGE = "org:users:manage"
    
    # Contract Management
    CONTRACT_READ = "contract:read"
    CONTRACT_CREATE = "contract:create"
    CONTRACT_UPDATE = "contract:update"
    CONTRACT_DELETE = "contract:delete"
    CONTRACT_COMPARE = "contract:compare"
    
    # Obligation Management
    OBLIGATION_READ = "obligation:read"
    OBLIGATION_CREATE = "obligation:create"
    OBLIGATION_UPDATE = "obligation:update"
    OBLIGATION_ASSIGN = "obligation:assign"
    OBLIGATION_COMPLETE = "obligation:complete"
    OBLIGATION_WAIVE = "obligation:waive"
    
    # Risk Management
    RISK_VIEW = "risk:view"
    RISK_RECALCULATE = "risk:recalculate"
    RISK_OVERRIDE = "risk:override"
    
    # Compliance & Workflow
    COMPLIANCE_VIEW = "compliance:view"
    COMPLIANCE_MANAGE = "compliance:manage"
    WORKFLOW_EXECUTE = "workflow:execute"
    
    # Search & AI
    SEARCH_EXECUTE = "search:execute"
    AI_ASSISTANT_USE = "ai:assistant:use"
    
    # Reports & Analytics
    ANALYTICS_VIEW = "analytics:view"
    REPORTS_GENERATE = "reports:generate"
    REPORTS_EXPORT = "reports:export"
    
    # Audit & SaaS
    AUDIT_VIEW = "audit:view"
    SUBSCRIPTION_MANAGE = "subscription:manage"

# Granular Permission Mapping for Roles
ROLE_PERMISSIONS: Dict[RoleName, Set[Permission]] = {
    RoleName.SUPER_ADMIN: set(Permission),  # All permissions
    
    RoleName.ORG_ADMIN: {
        Permission.ORG_VIEW, Permission.ORG_EDIT, Permission.ORG_USERS_MANAGE,
        Permission.CONTRACT_READ, Permission.CONTRACT_CREATE, Permission.CONTRACT_UPDATE, Permission.CONTRACT_DELETE, Permission.CONTRACT_COMPARE,
        Permission.OBLIGATION_READ, Permission.OBLIGATION_CREATE, Permission.OBLIGATION_UPDATE, Permission.OBLIGATION_ASSIGN, Permission.OBLIGATION_COMPLETE, Permission.OBLIGATION_WAIVE,
        Permission.RISK_VIEW, Permission.RISK_RECALCULATE, Permission.RISK_OVERRIDE,
        Permission.COMPLIANCE_VIEW, Permission.COMPLIANCE_MANAGE, Permission.WORKFLOW_EXECUTE,
        Permission.SEARCH_EXECUTE, Permission.AI_ASSISTANT_USE,
        Permission.ANALYTICS_VIEW, Permission.REPORTS_GENERATE, Permission.REPORTS_EXPORT,
        Permission.AUDIT_VIEW, Permission.SUBSCRIPTION_MANAGE, Permission.SYSTEM_HEALTH_VIEW
    },
    
    RoleName.LEGAL_MANAGER: {
        Permission.ORG_VIEW,
        Permission.CONTRACT_READ, Permission.CONTRACT_CREATE, Permission.CONTRACT_UPDATE, Permission.CONTRACT_COMPARE,
        Permission.OBLIGATION_READ, Permission.OBLIGATION_CREATE, Permission.OBLIGATION_UPDATE, Permission.OBLIGATION_ASSIGN, Permission.OBLIGATION_COMPLETE, Permission.OBLIGATION_WAIVE,
        Permission.RISK_VIEW, Permission.RISK_RECALCULATE, Permission.RISK_OVERRIDE,
        Permission.COMPLIANCE_VIEW, Permission.COMPLIANCE_MANAGE, Permission.WORKFLOW_EXECUTE,
        Permission.SEARCH_EXECUTE, Permission.AI_ASSISTANT_USE,
        Permission.ANALYTICS_VIEW, Permission.REPORTS_GENERATE, Permission.REPORTS_EXPORT,
        Permission.AUDIT_VIEW
    },
    
    RoleName.CONTRACT_MANAGER: {
        Permission.ORG_VIEW,
        Permission.CONTRACT_READ, Permission.CONTRACT_CREATE, Permission.CONTRACT_UPDATE, Permission.CONTRACT_COMPARE,
        Permission.OBLIGATION_READ, Permission.OBLIGATION_CREATE, Permission.OBLIGATION_UPDATE, Permission.OBLIGATION_ASSIGN, Permission.OBLIGATION_COMPLETE,
        Permission.RISK_VIEW, Permission.RISK_RECALCULATE,
        Permission.COMPLIANCE_VIEW, Permission.WORKFLOW_EXECUTE,
        Permission.SEARCH_EXECUTE, Permission.AI_ASSISTANT_USE,
        Permission.ANALYTICS_VIEW, Permission.REPORTS_GENERATE, Permission.REPORTS_EXPORT
    },
    
    RoleName.EMPLOYEE: {
        Permission.ORG_VIEW,
        Permission.CONTRACT_READ,
        Permission.OBLIGATION_READ, Permission.OBLIGATION_COMPLETE,
        Permission.RISK_VIEW,
        Permission.COMPLIANCE_VIEW,
        Permission.SEARCH_EXECUTE, Permission.AI_ASSISTANT_USE,
        Permission.ANALYTICS_VIEW
    },
    
    RoleName.VIEWER: {
        Permission.ORG_VIEW,
        Permission.CONTRACT_READ,
        Permission.OBLIGATION_READ,
        Permission.RISK_VIEW,
        Permission.COMPLIANCE_VIEW,
        Permission.SEARCH_EXECUTE,
        Permission.ANALYTICS_VIEW
    }
}

def verify_role_permission(role_str: str, required_permission: Permission) -> None:
    """Validate if user's role grants the required permission in backend execution."""
    try:
        role = RoleName(role_str)
    except ValueError:
        raise PermissionDeniedException(f"Invalid system role: '{role_str}'")

    allowed_permissions = ROLE_PERMISSIONS.get(role, set())
    if required_permission not in allowed_permissions:
        raise PermissionDeniedException(
            f"Role '{role_str}' is not granted required permission '{required_permission.value}'"
        )
