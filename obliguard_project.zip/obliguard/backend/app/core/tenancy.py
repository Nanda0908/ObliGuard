"""
ObliGuard AI - Multi-Tenant Isolation Engine
Enforces tenant scoping and validates cross-tenant access boundaries.
"""

from typing import Optional, Any
from app.core.exceptions import TenantAccessDeniedException

class TenantContext:
    """Encapsulates the tenant scope for an authenticated request context."""
    def __init__(self, organization_id: int, is_super_admin: bool = False):
        self.organization_id = organization_id
        self.is_super_admin = is_super_admin

    def validate_entity_tenant(self, entity_org_id: Optional[int], entity_name: str = "Resource") -> None:
        """Verify that an entity belongs to the current tenant context. Super Admins bypass."""
        if self.is_super_admin:
            return

        if entity_org_id is None:
            raise TenantAccessDeniedException(f"Unscoped {entity_name} cannot be accessed without explicit tenant context.")

        if entity_org_id != self.organization_id:
            raise TenantAccessDeniedException(
                f"Tenant Isolation Violation: Current organization ({self.organization_id}) "
                f"cannot access {entity_name} owned by organization ({entity_org_id})."
            )

    def apply_filter(self, query: Any, model_class: Any) -> Any:
        """Apply tenant isolation filter to a SQLAlchemy query unless user is Super Admin."""
        if self.is_super_admin:
            return query
        
        if hasattr(model_class, "organization_id"):
            return query.filter(model_class.organization_id == self.organization_id)
        
        return query
