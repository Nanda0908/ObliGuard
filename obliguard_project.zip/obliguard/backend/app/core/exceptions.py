"""
ObliGuard AI - Domain Exceptions
Custom exception classes for structured error handling across modules.
"""

from typing import Any, Dict, Optional

class ObliGuardException(Exception):
    """Base exception class for all ObliGuard platform errors."""
    def __init__(self, message: str, code: str = "INTERNAL_ERROR", details: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.message = message
        self.code = code
        self.details = details or {}

class AuthenticationException(ObliGuardException):
    def __init__(self, message: str = "Invalid credentials or token expired"):
        super().__init__(message, code="AUTH_FAILED")

class PermissionDeniedException(ObliGuardException):
    def __init__(self, message: str = "Insufficient permissions to access this resource"):
        super().__init__(message, code="PERMISSION_DENIED")

class TenantAccessDeniedException(ObliGuardException):
    def __init__(self, message: str = "Cross-tenant access prohibited"):
        super().__init__(message, code="TENANT_ACCESS_DENIED")

class ResourceNotFoundException(ObliGuardException):
    def __init__(self, resource_name: str, resource_id: Any):
        super().__init__(f"{resource_name} with ID '{resource_id}' not found", code="RESOURCE_NOT_FOUND")

class ValidationException(ObliGuardException):
    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message, code="VALIDATION_ERROR", details=details)

class DocumentProcessingException(ObliGuardException):
    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message, code="DOCUMENT_PROCESSING_FAILED", details=details)

class OCRException(DocumentProcessingException):
    def __init__(self, message: str = "Tesseract OCR failed to extract text"):
        super().__init__(message, details={"engine": "tesseract"})

class NLPException(ObliGuardException):
    def __init__(self, message: str):
        super().__init__(message, code="NLP_PIPELINE_ERROR")

class TemporalCalculationException(ObliGuardException):
    def __init__(self, message: str):
        super().__init__(message, code="TEMPORAL_ENGINE_ERROR")

class RiskCalculationException(ObliGuardException):
    def __init__(self, message: str):
        super().__init__(message, code="RISK_ENGINE_ERROR")

class WorkflowTransitionException(ObliGuardException):
    def __init__(self, from_state: str, to_state: str, reason: str):
        super().__init__(f"Cannot transition workflow from '{from_state}' to '{to_state}': {reason}", code="WORKFLOW_TRANSITION_FAILED")

class SaaSQuotaExceededException(ObliGuardException):
    def __init__(self, feature: str, limit: int):
        super().__init__(f"Subscription quota limit of {limit} reached for feature '{feature}'", code="SAAS_QUOTA_EXCEEDED")
