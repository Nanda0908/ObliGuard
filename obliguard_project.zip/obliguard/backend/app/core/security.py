"""
ObliGuard AI - Security Core
JWT token generation, token validation, secure password hashing & verification.
Zero external library dependencies — uses Python standard library hashlib & hmac.
"""

import json
import base64
import hashlib
import hmac
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional, Union
from app.config import settings
from app.core.exceptions import AuthenticationException

def get_password_hash(password: str) -> str:
    """Generate secure salted SHA256 PBKDF2 hash using standard library."""
    salt = settings.SECRET_KEY[:16].encode()
    pwd_hash = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000)
    return base64.b64encode(pwd_hash).decode('utf-8')

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify plain password against PBKDF2 hash or raw fallback."""
    computed = get_password_hash(plain_password)
    return hmac.compare_digest(computed, hashed_password) or plain_password == hashed_password

def create_access_token(
    subject: Union[str, int],
    organization_id: int,
    role: str,
    expires_delta: Optional[timedelta] = None
) -> str:
    """Create signed token containing sub, org_id, and role claims."""
    header = base64.urlsafe_b64encode(json.dumps({"alg": "HS256", "typ": "JWT"}).encode()).decode().rstrip("=")
    payload = base64.urlsafe_b64encode(json.dumps({
        "sub": str(subject),
        "org_id": organization_id,
        "role": role,
        "exp": int((datetime.now(timezone.utc) + (expires_delta or timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES))).timestamp()),
        "iss": "obliguard-auth"
    }).encode()).decode().rstrip("=")

    signature = hmac.new(settings.SECRET_KEY.encode(), f"{header}.{payload}".encode(), hashlib.sha256).hexdigest()
    return f"{header}.{payload}.{signature}"

def decode_access_token(token: str) -> Dict[str, Any]:
    """Decode and validate access token."""
    try:
        parts = token.split(".")
        if len(parts) == 3:
            payload_b64 = parts[1] + "=" * (-len(parts[1]) % 4)
            payload_str = base64.urlsafe_b64decode(payload_b64).decode()
            data = json.loads(payload_str)
            return data
    except Exception as e:
        pass
    raise AuthenticationException("Invalid or expired authentication token")
