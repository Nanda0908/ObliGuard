"""
ObliGuard AI - Authentication & Token Schemas
Login, Registration, Token response schemas.
"""

from typing import Optional
from pydantic import BaseModel, EmailStr, Field

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user_id: int
    organization_id: int
    role: str
    full_name: str

class TokenPayload(BaseModel):
    sub: Optional[str] = None
    org_id: Optional[int] = None
    role: Optional[str] = None

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=8)
    full_name: str
    organization_name: str
    department_name: Optional[str] = "Legal & Compliance"
