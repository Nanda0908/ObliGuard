"""
ObliGuard AI - Temporal & Risk Schemas
Deadline calculations, business days, and explainable risk scores.
"""

from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel

class DeadlineOut(BaseModel):
    id: int
    obligation_id: int
    deadline_date: datetime
    original_expression: Optional[str] = None
    is_business_days: bool
    recurring_rule: Optional[str] = None
    is_completed: bool
    completed_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class RiskFactorOut(BaseModel):
    id: int
    dimension: str
    factor_name: str
    weight: float
    score_contribution: float
    description: Optional[str] = None

    class Config:
        from_attributes = True

class RiskScoreOut(BaseModel):
    id: int
    contract_id: int
    overall_score: float
    risk_level: str
    financial_risk: float
    compliance_risk: float
    deadline_risk: float
    penalty_risk: float
    renewal_risk: float
    operational_risk: float
    legal_risk: float
    security_risk: float
    explanation_json: Dict[str, Any]
    factors: List[RiskFactorOut] = []
    calculated_at: datetime

    class Config:
        from_attributes = True
