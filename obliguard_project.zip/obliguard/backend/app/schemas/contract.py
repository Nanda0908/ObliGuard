"""
ObliGuard AI - Contract & Document Schemas
Contracts, versioning, parties, and processing statuses.
"""

from datetime import datetime
from typing import Optional, List, Any, Dict
from pydantic import BaseModel, Field

class ContractPartyBase(BaseModel):
    party_name: str
    party_type: str = "Vendor"
    role_in_contract: Optional[str] = None
    contact_email: Optional[str] = None
    contact_phone: Optional[str] = None

class ContractPartyOut(ContractPartyBase):
    id: int
    contract_id: int

    class Config:
        from_attributes = True

class ContractVersionOut(BaseModel):
    id: int
    contract_id: int
    version_number: int
    file_name: str
    file_size: int
    document_type: str
    is_active_version: bool
    processing_status: str
    processing_error: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True

class ContractBase(BaseModel):
    title: str
    contract_number: Optional[str] = None
    contract_type: str = "Master Services Agreement"
    department_id: Optional[int] = None
    owner_id: Optional[int] = None
    total_value: Optional[float] = None
    currency: str = "USD"
    effective_date: Optional[datetime] = None
    expiry_date: Optional[datetime] = None
    renewal_date: Optional[datetime] = None
    auto_renewal: bool = False
    notice_period_days: int = 30
    description: Optional[str] = None
    tags_json: List[str] = Field(default_factory=list)

class ContractCreate(ContractBase):
    parties: List[ContractPartyBase] = Field(default_factory=list)

class ContractUpdate(BaseModel):
    title: Optional[str] = None
    contract_type: Optional[str] = None
    department_id: Optional[int] = None
    owner_id: Optional[int] = None
    status: Optional[str] = None
    total_value: Optional[float] = None
    effective_date: Optional[datetime] = None
    expiry_date: Optional[datetime] = None
    renewal_date: Optional[datetime] = None
    auto_renewal: Optional[bool] = None
    notice_period_days: Optional[int] = None
    description: Optional[str] = None
    tags_json: Optional[List[str]] = None

class ContractOut(ContractBase):
    id: int
    organization_id: int
    status: str
    risk_score: float
    risk_level: str
    created_at: datetime
    updated_at: datetime
    parties: List[ContractPartyOut] = []
    versions: List[ContractVersionOut] = []

    class Config:
        from_attributes = True
