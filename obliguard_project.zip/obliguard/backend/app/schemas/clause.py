"""
ObliGuard AI - Clause Schemas
Clause classification, section location, and confidence ratings.
"""

from datetime import datetime
from typing import Optional
from pydantic import BaseModel

class ClauseBase(BaseModel):
    section_number: Optional[str] = None
    page_number: Optional[int] = None
    clause_type: str
    source_text: str
    normalized_text: Optional[str] = None
    confidence_score: float = 0.95
    risk_impact: str = "MEDIUM"

class ClauseCreate(ClauseBase):
    contract_id: int
    version_id: int

class ClauseOut(ClauseBase):
    id: int
    contract_id: int
    version_id: int
    created_at: datetime

    class Config:
        from_attributes = True
