"""
ObliGuard AI - Analytics, Reports, SaaS, Audit & System Schemas
Metrics dashboards, report generators, usage tracking, audit logs & system health.
"""

from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel

# Analytics Schemas
class AnalyticsOverview(BaseModel):
    total_contracts: int
    active_contracts: int
    expiring_soon_contracts: int
    high_risk_contracts: int
    critical_risk_contracts: int
    total_obligations: int
    overdue_obligations: int
    upcoming_obligations: int
    compliance_rate_percent: float
    total_open_violations: int
    total_penalty_exposure: float

class StatusDistribution(BaseModel):
    label: str
    count: int

class RiskDistribution(BaseModel):
    risk_level: str
    count: int

class TrendPoint(BaseModel):
    date: str
    compliance_rate: float
    overdue_count: int

class AnalyticsDashboard(BaseModel):
    overview: AnalyticsOverview
    contract_status_distribution: List[StatusDistribution]
    risk_level_distribution: List[RiskDistribution]
    obligation_status_distribution: List[StatusDistribution]
    compliance_trend: List[TrendPoint]
    department_risk_matrix: List[Dict[str, Any]]

# Report Schemas
class ReportGenerateRequest(BaseModel):
    title: str
    report_type: str  # Risk, Compliance, Obligation, Renewal, Overdue, Department, Audit
    format: str = "PDF"  # PDF, CSV, JSON
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    department_id: Optional[int] = None

class ReportOut(BaseModel):
    id: int
    organization_id: int
    title: str
    report_type: str
    format: str
    file_path: str
    created_at: datetime

    class Config:
        from_attributes = True

# SaaS Schemas
class SubscriptionOut(BaseModel):
    id: int
    organization_id: int
    plan_tier: str
    status: str
    max_contracts: int
    max_users: int
    max_storage_mb: int
    expires_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class UsageSummary(BaseModel):
    plan_tier: str
    contracts_used: int
    contracts_limit: int
    users_used: int
    users_limit: int
    storage_mb_used: float
    storage_mb_limit: int

# Audit Log Schema
class AuditLogOut(BaseModel):
    id: int
    organization_id: int
    user_id: Optional[int] = None
    action: str
    resource_type: str
    resource_id: Optional[str] = None
    ip_address: Optional[str] = None
    details_json: Dict[str, Any]
    created_at: datetime

    class Config:
        from_attributes = True

# System Health Schema
class SystemHealth(BaseModel):
    status: str = "healthy"
    database_connected: bool = True
    local_ai_available: bool = True
    version: str = "1.0.0"
    timestamp: datetime
