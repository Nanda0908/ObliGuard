"""
ObliGuard AI - Compliance Schemas
Compliance checks, violation tracking, and penalty details.
"""

from datetime import datetime
from typing import Optional
from pydantic import BaseModel

class ComplianceCheckCreate(BaseModel):
    obligation_id: int
    status: str  # Pass, Fail, Waived, Partial
    notes: Optional[str] = None

class ComplianceCheckOut(BaseModel):
    id: int
    obligation_id: int
    checked_by_id: Optional[int] = None
    status: str
    notes: Optional[str] = None
    verified_at: datetime

    class Config:
        from_attributes = True

class ViolationOut(BaseModel):
    id: int
    organization_id: int
    obligation_id: int
    contract_id: int
    severity: str
    violation_type: str
    penalty_amount: float
    notes: Optional[str] = None
    status: str
    created_at: datetime

    class Config:
        from_attributes = True
