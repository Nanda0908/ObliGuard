"""
ObliGuard AI - Search, RAG & Version Comparison Schemas
Semantic vector search, grounded LLM assistant, and contract version diffing.
"""

from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel

# Search Schemas
class SearchQuery(BaseModel):
    query: str
    top_k: int = 5
    contract_id: Optional[int] = None
    clause_type: Optional[str] = None
    min_similarity: float = 0.2

class SearchResultItem(BaseModel):
    clause_id: int
    contract_id: int
    contract_title: str
    section_number: Optional[str] = None
    page_number: Optional[int] = None
    clause_type: str
    source_text: str
    similarity_score: float

class SearchResponse(BaseModel):
    query: str
    total_matches: int
    results: List[SearchResultItem]

# RAG Schemas
class RAGQuery(BaseModel):
    question: str
    contract_id: Optional[int] = None
    top_k: int = 4

class RAGSourceReference(BaseModel):
    contract_id: int
    contract_title: str
    section_number: Optional[str] = None
    page_number: Optional[int] = None
    clause_type: str
    excerpt: str

class RAGResponse(BaseModel):
    question: str
    answer: str
    sources: List[RAGSourceReference]
    is_grounded: bool
    execution_time_seconds: float

# Comparison Schemas
class ComparisonRequest(BaseModel):
    version_id_1: int
    version_id_2: int

class ClauseDiff(BaseModel):
    change_type: str  # ADDED, REMOVED, MODIFIED, UNCHANGED
    clause_type: str
    section_number: Optional[str] = None
    old_text: Optional[str] = None
    new_text: Optional[str] = None
    risk_impact: str

class ComparisonResponse(BaseModel):
    contract_id: int
    version_1_number: int
    version_2_number: int
    summary_of_changes: str
    total_added: int
    total_removed: int
    total_modified: int
    clause_diffs: List[ClauseDiff]
    risk_delta: float
    obligation_impact_summary: str
