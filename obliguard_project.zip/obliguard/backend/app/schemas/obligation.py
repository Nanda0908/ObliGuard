"""
ObliGuard AI - Obligation Schemas
Obligation extraction, assignment, status tracking.
"""

from datetime import datetime
from typing import Optional
from pydantic import BaseModel

class ObligationBase(BaseModel):
    obligation_type: str  # Reporting, Payment, SLA, Audit, Notice
    party: str
    action: str
    object_target: Optional[str] = None
    deadline_expression: Optional[str] = None
    frequency: str = "One-Time"
    condition: Optional[str] = None
    penalty_summary: Optional[str] = None
    priority: str = "MEDIUM"  # LOW, MEDIUM, HIGH, CRITICAL
    responsible_user_id: Optional[int] = None
    department_id: Optional[int] = None
    due_date: Optional[datetime] = None
    notice_deadline: Optional[datetime] = None

class ObligationCreate(ObligationBase):
    contract_id: int
    clause_id: Optional[int] = None

class ObligationUpdate(BaseModel):
    party: Optional[str] = None
    action: Optional[str] = None
    object_target: Optional[str] = None
    obligation_type: Optional[str] = None
    status: Optional[str] = None
    priority: Optional[str] = None
    responsible_user_id: Optional[int] = None
    due_date: Optional[datetime] = None

class ObligationOut(ObligationBase):
    id: int
    organization_id: int
    contract_id: int
    clause_id: Optional[int] = None
    status: str
    confidence_score: float
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
