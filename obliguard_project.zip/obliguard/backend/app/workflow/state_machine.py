"""
ObliGuard AI - Obligation Workflow State Machine
Enforces valid state transitions and SLA escalation rules.
"""

from typing import Set
from app.core.exceptions import WorkflowTransitionException

VALID_TRANSITIONS = {
    "Pending": {"Upcoming", "Due", "Completed", "Waived", "Cancelled"},
    "Upcoming": {"Due", "Completed", "Overdue", "Waived", "Cancelled"},
    "Due": {"Completed", "Overdue", "Waived", "Cancelled"},
    "Overdue": {"Completed", "Escalated", "Waived", "Cancelled"},
    "Escalated": {"Completed", "Waived", "Cancelled"},
    "Completed": set(),  # Terminal state
    "Waived": set(),     # Terminal state
    "Cancelled": set()   # Terminal state
}

def transition_obligation_status(current_status: str, target_status: str) -> str:
    """Validate and execute state transition for obligation lifecycle."""
    if current_status == target_status:
        return target_status

    allowed_targets: Set[str] = VALID_TRANSITIONS.get(current_status, set())
    if target_status not in allowed_targets:
        raise WorkflowTransitionException(
            from_state=current_status,
            to_state=target_status,
            reason=f"Allowed next states from '{current_status}' are: {sorted(list(allowed_targets))}"
        )

    return target_status
