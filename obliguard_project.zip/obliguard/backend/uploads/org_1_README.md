# ObliGuard AI — AI-Powered Contract Obligation, Risk & Compliance Intelligence SaaS

[![Architecture](https://img.shields.io/badge/Architecture-Clean%20Modular-blue)](#)
[![Python](https://img.shields.io/badge/Python-3.11%2B-blue)](#)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.109-green)](#)
[![React](https://img.shields.io/badge/React-18.2-cyan)](#)
[![License](https://img.shields.io/badge/License-Proprietary%20SaaS-purple)](#)
[![API Keys](https://img.shields.io/badge/External%20API%20Keys-ZERO%20%28100%25%20Offline%29-brightgreen)](#)

ObliGuard AI is a functional, modular, production-style enterprise B2B SaaS platform that converts unstructured legal contracts into structured, actionable business intelligence with automated temporal deadline calculation, 8-dimensional explainable risk scoring, compliance workflows, semantic vector search, version diffing, grounded local RAG assistant, and executive reporting.

---

## Key Features

- **Document Intelligence Pipeline**: Multi-format text extraction (PDF via PyMuPDF, DOCX via python-docx, TXT, Tesseract OCR fallback), text cleaning, section parser, page mapping.
- **Clause Intelligence Engine**: Hybrid TF-IDF + Scikit-Learn Logistic Regression classifier classifying 20+ clause categories (Payment, SLA, Liability, Indemnity, Confidentiality, Termination, Penalty, Reporting, etc.) with confidence scores.
- **Obligation Extraction Engine**: Detects modal language (*shall, must, required to, agrees to*), extracts Party, Action, Object, Deadline rule, Frequency, Condition, Penalty, and Priority.
- **Temporal Reasoning Engine**: Business day calculations, holiday calendars, relative dates, notice windows, and recurring obligation schedules.
- **Explainable Multi-Dimensional Risk Engine**: 0–100 risk scoring across 8 dimensions (Financial, Compliance, Deadline, Penalty, Renewal, Operational, Legal, Security) with dynamic decay and event history.
- **Compliance & Workflow Engine**: Obligation lifecycle state machine (`Pending` -> `Upcoming` -> `Due` -> `Completed` / `Overdue` -> `Escalated`).
- **Semantic Vector Search**: SentenceTransformers local embeddings + cosine similarity clause search.
- **Grounded Local RAG Assistant**: Local LLM (Ollama) / rules context synthesizer providing 0-hallucination answers backed by precise contract, section, and page citations.
- **Contract Version Comparison**: Structural and semantic version diffing engine detecting added, removed, and modified clauses with risk deltas.
- **Zero External API Keys**: 100% local operation — no paid external AI API keys required.

---

## System Quick Start

### 1. Backend Setup
```bash
cd backend
python -m venv venv
# On Windows:
venv\Scripts\activate

pip install -r requirements.txt
python seed_data.py
python -m uvicorn app.main:app --reload --port 8000
```
FastAPI Swagger documentation will be available at [http://localhost:8000/docs](http://localhost:8000/docs).

### 2. Frontend Setup
```bash
cd frontend
npm install
npm run dev
```
Open [http://localhost:5173](http://localhost:5173) in your browser.

### Default Admin Credentials
- **Email**: `admin@acme.com`
- **Password**: `Password123!`

---

## Testing
Run backend test suite:
```bash
cd backend
python -m pytest tests/
```

---

## Docker Deployment
```bash
docker-compose up --build -d
```
