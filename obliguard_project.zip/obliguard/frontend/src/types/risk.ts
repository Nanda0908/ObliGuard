export interface RiskFactor {
  id: number;
  dimension: string;
  factor_name: string;
  weight: number;
  score_contribution: number;
  description?: string;
}

export interface RiskScore {
  id: number;
  contract_id: number;
  overall_score: number;
  risk_level: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  financial_risk: number;
  compliance_risk: number;
  deadline_risk: number;
  penalty_risk: number;
  renewal_risk: number;
  operational_risk: number;
  legal_risk: number;
  security_risk: number;
  explanation_json: { explanation?: string };
  factors: RiskFactor[];
  calculated_at: string;
}
