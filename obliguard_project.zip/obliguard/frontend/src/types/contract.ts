export interface ContractParty {
  id: number;
  contract_id: number;
  party_name: string;
  party_type: string;
  role_in_contract?: string;
  contact_email?: string;
}

export interface ContractVersion {
  id: number;
  contract_id: number;
  version_number: number;
  file_name: string;
  file_size: number;
  document_type: string;
  is_active_version: boolean;
  processing_status: string;
  processing_error?: string;
  created_at: string;
}

export interface Contract {
  id: number;
  organization_id: number;
  title: string;
  contract_number?: string;
  contract_type: string;
  department_id?: number;
  owner_id?: number;
  status: 'Draft' | 'Active' | 'Expiring' | 'Expired' | 'Terminated' | 'Archived';
  risk_score: number;
  risk_level: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  total_value?: number;
  currency: string;
  effective_date?: string;
  expiry_date?: string;
  renewal_date?: string;
  auto_renewal: boolean;
  notice_period_days: number;
  description?: string;
  tags_json: string[];
  created_at: string;
  updated_at: string;
  parties: ContractParty[];
  versions: ContractVersion[];
}

export interface Clause {
  id: number;
  contract_id: number;
  version_id: number;
  section_number?: string;
  page_number?: number;
  clause_type: string;
  source_text: string;
  normalized_text?: string;
  confidence_score: number;
  risk_impact: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  created_at: string;
}
