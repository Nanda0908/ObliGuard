export interface AnalyticsOverview {
  total_contracts: number;
  active_contracts: number;
  expiring_soon_contracts: number;
  high_risk_contracts: number;
  critical_risk_contracts: number;
  total_obligations: number;
  overdue_obligations: number;
  upcoming_obligations: number;
  compliance_rate_percent: number;
  total_open_violations: number;
  total_penalty_exposure: number;
}

export interface AnalyticsDashboard {
  overview: AnalyticsOverview;
  contract_status_distribution: Array<{ label: string; count: number }>;
  risk_level_distribution: Array<{ risk_level: string; count: number }>;
  obligation_status_distribution: Array<{ label: string; count: number }>;
  compliance_trend: Array<{ date: string; compliance_rate: number; overdue_count: number }>;
  department_risk_matrix: Array<{ department: string; risk_score: number; contracts_count: number }>;
}
