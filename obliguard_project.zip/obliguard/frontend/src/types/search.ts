export interface SearchResultItem {
  clause_id: number;
  contract_id: number;
  contract_title: string;
  section_number?: string;
  page_number?: number;
  clause_type: string;
  source_text: string;
  similarity_score: number;
}

export interface SearchResponse {
  query: string;
  total_matches: number;
  results: SearchResultItem[];
}

export interface RAGSourceReference {
  contract_id: number;
  contract_title: string;
  section_number?: string;
  page_number?: number;
  clause_type: string;
  excerpt: string;
}

export interface RAGResponse {
  question: string;
  answer: string;
  sources: RAGSourceReference[];
  is_grounded: boolean;
  execution_time_seconds: number;
}

export interface ClauseDiff {
  change_type: 'ADDED' | 'REMOVED' | 'MODIFIED' | 'UNCHANGED';
  clause_type: string;
  section_number?: string;
  old_text?: string;
  new_text?: string;
  risk_impact: string;
}

export interface ComparisonResponse {
  contract_id: number;
  version_1_number: number;
  version_2_number: number;
  summary_of_changes: string;
  total_added: number;
  total_removed: number;
  total_modified: number;
  clause_diffs: ClauseDiff[];
  risk_delta: number;
  obligation_impact_summary: string;
}
