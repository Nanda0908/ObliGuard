export interface Obligation {
  id: number;
  organization_id: number;
  contract_id: number;
  clause_id?: number;
  obligation_type: string;
  party: string;
  action: string;
  object_target?: string;
  deadline_expression?: string;
  frequency: string;
  condition?: string;
  penalty_summary?: string;
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  status: 'Pending' | 'Upcoming' | 'Due' | 'Completed' | 'Overdue' | 'Escalated' | 'Waived' | 'Cancelled';
  responsible_user_id?: number;
  department_id?: number;
  due_date?: string;
  notice_deadline?: string;
  confidence_score: number;
  created_at: string;
  updated_at: string;
}
