import React, { createContext, useContext, useState, useEffect } from 'react';
import { apiClient } from '../api/client';
import { Contract } from '../types/contract';

interface ContractContextType {
  contracts: Contract[];
  selectedContractId: number | 'all';
  setSelectedContractId: (id: number | 'all') => void;
  selectedContract: Contract | null;
  refreshContracts: () => Promise<Contract[]>;
  loading: boolean;
}

const ContractContext = createContext<ContractContextType | undefined>(undefined);

export const ContractProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [selectedContractId, setSelectedContractId] = useState<number | 'all'>('all');
  const [loading, setLoading] = useState(true);

  const refreshContracts = async (): Promise<Contract[]> => {
    try {
      setLoading(true);
      const res = await apiClient.get('/contracts');
      const data: Contract[] = res.data || [];
      setContracts(data);
      return data;
    } catch (err) {
      console.error('Failed to load contracts in context:', err);
      return [];
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshContracts();
  }, []);

  const selectedContract = typeof selectedContractId === 'number'
    ? contracts.find(c => c.id === selectedContractId) || null
    : null;

  return (
    <ContractContext.Provider
      value={{
        contracts,
        selectedContractId,
        setSelectedContractId,
        selectedContract,
        refreshContracts,
        loading,
      }}
    >
      {children}
    </ContractContext.Provider>
  );
};

export const useContract = () => {
  const context = useContext(ContractContext);
  if (!context) {
    throw new Error('useContract must be used within a ContractProvider');
  }
  return context;
};
