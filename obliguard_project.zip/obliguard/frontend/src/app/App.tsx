import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from '../auth/AuthContext';
import { ContractProvider } from '../context/ContractContext';
import { AppLayout } from '../layouts/AppLayout';
import { AuthLayout } from '../layouts/AuthLayout';

import { Login } from '../pages/Login';
import { Register } from '../pages/Register';
import { Dashboard } from '../pages/Dashboard';
import { ContractsList } from '../pages/ContractsList';
import { ContractUpload } from '../pages/ContractUpload';
import { ContractDetail } from '../pages/ContractDetail';
import { VersionCompare } from '../pages/VersionCompare';
import { ClauseExplorer } from '../pages/ClauseExplorer';
import { ObligationList } from '../pages/ObligationList';
import { DeadlinesCalendar } from '../pages/DeadlinesCalendar';
import { RiskDashboard } from '../pages/RiskDashboard';
import { ComplianceDashboard } from '../pages/ComplianceDashboard';
import { SemanticSearch } from '../pages/SemanticSearch';
import { AIAssistant } from '../pages/AIAssistant';
import { ObligationGraph } from '../pages/ObligationGraph';
import { Analytics } from '../pages/Analytics';
import { Reports } from '../pages/Reports';
import { UserManagement } from '../pages/UserManagement';
import { Notifications } from '../pages/Notifications';
import { AuditLogs } from '../pages/AuditLogs';
import { Subscription } from '../pages/Subscription';
import { SystemHealth } from '../pages/SystemHealth';
import { Settings } from '../pages/Settings';

export const App: React.FC = () => {
  return (
    <AuthProvider>
      <ContractProvider>
        <BrowserRouter>
        <Routes>
          {/* Public Auth Routes */}
          <Route element={<AuthLayout />}>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
          </Route>

          {/* Protected Enterprise Routes */}
          <Route element={<AppLayout />}>
            <Route path="/" element={<Dashboard />} />
            <Route path="/contracts" element={<ContractsList />} />
            <Route path="/contracts/upload" element={<ContractUpload />} />
            <Route path="/contracts/:id" element={<ContractDetail />} />
            <Route path="/comparison" element={<VersionCompare />} />
            <Route path="/clauses" element={<ClauseExplorer />} />
            <Route path="/graph" element={<ObligationGraph />} />
            <Route path="/obligations" element={<ObligationList />} />
            <Route path="/calendar" element={<DeadlinesCalendar />} />
            <Route path="/risks" element={<RiskDashboard />} />
            <Route path="/compliance" element={<ComplianceDashboard />} />
            <Route path="/search" element={<SemanticSearch />} />
            <Route path="/assistant" element={<AIAssistant />} />
            <Route path="/analytics" element={<Analytics />} />
            <Route path="/reports" element={<Reports />} />
            <Route path="/users" element={<UserManagement />} />
            <Route path="/notifications" element={<Notifications />} />
            <Route path="/audit" element={<AuditLogs />} />
            <Route path="/subscription" element={<Subscription />} />
            <Route path="/system-health" element={<SystemHealth />} />
            <Route path="/settings" element={<Settings />} />
          </Route>

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </ContractProvider>
  </AuthProvider>
);
};
