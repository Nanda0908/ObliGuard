import React from 'react';
import { useContract } from '../context/ContractContext';
import { FileText, ChevronDown } from 'lucide-react';

interface ContractSelectorProps {
  className?: string;
  allowAll?: boolean;
  allLabel?: string;
  onSelect?: (contractId: number | 'all') => void;
}

export const ContractSelector: React.FC<ContractSelectorProps> = ({
  className = '',
  allowAll = true,
  allLabel = 'All Contracts (Combined)',
  onSelect,
}) => {
  const { contracts, selectedContractId, setSelectedContractId } = useContract();

  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value;
    const newId = val === 'all' ? 'all' : Number(val);
    setSelectedContractId(newId);
    if (onSelect) {
      onSelect(newId);
    }
  };

  return (
    <div className={`relative inline-flex items-center ${className}`}>
      <div className="relative flex items-center w-full">
        <FileText className="w-3.5 h-3.5 text-blue-400 absolute left-3 pointer-events-none" />
        <select
          value={selectedContractId}
          onChange={handleChange}
          className="bg-slate-950 border border-slate-800 text-slate-200 text-xs rounded-xl pl-8 pr-8 py-2 focus:outline-none focus:border-blue-500 font-medium transition-all appearance-none cursor-pointer w-full shadow-sm hover:border-slate-700"
        >
          {allowAll && <option value="all">{allLabel}</option>}
          {contracts.map((c) => (
            <option key={c.id} value={c.id}>
              {c.title} (#{c.id} — {c.contract_type})
            </option>
          ))}
        </select>
        <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 pointer-events-none" />
      </div>
    </div>
  );
};
