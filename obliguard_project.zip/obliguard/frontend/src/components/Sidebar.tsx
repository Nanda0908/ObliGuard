import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  FileText,
  UploadCloud,
  Layers,
  GitCompare,
  CheckCircle2,
  Calendar,
  ShieldAlert,
  Search,
  Bot,
  BarChart3,
  FileSpreadsheet,
  Users,
  ShieldCheck,
  CreditCard,
  Activity,
  Settings,
  Bell,
  Network
} from 'lucide-react';
import { useAuth } from '../auth/AuthContext';

export const Sidebar: React.FC = () => {
  const { user } = useAuth();

  const navSections = [
    {
      title: 'EXECUTIVE OVERVIEW',
      items: [
        { label: 'Dashboard', path: '/', icon: LayoutDashboard },
        { label: 'Analytics', path: '/analytics', icon: BarChart3 },
        { label: 'Reports Generator', path: '/reports', icon: FileSpreadsheet },
      ]
    },
    {
      title: 'CONTRACT INTELLIGENCE',
      items: [
        { label: 'All Contracts', path: '/contracts', icon: FileText },
        { label: 'Upload Document', path: '/contracts/upload', icon: UploadCloud },
        { label: 'Version Compare', path: '/comparison', icon: GitCompare },
        { label: 'Clause Explorer', path: '/clauses', icon: Layers },
        { label: 'Dependency Graph', path: '/graph', icon: Network },
      ]
    },
    {
      title: 'OBLIGATIONS & RISK',
      items: [
        { label: 'Obligations Matrix', path: '/obligations', icon: CheckCircle2 },
        { label: 'Deadlines Calendar', path: '/calendar', icon: Calendar },
        { label: 'Risk Intelligence', path: '/risks', icon: ShieldAlert },
        { label: 'Compliance & SLA', path: '/compliance', icon: ShieldCheck },
      ]
    },
    {
      title: 'SEARCH & LOCAL AI',
      items: [
        { label: 'Semantic Search', path: '/search', icon: Search },
        { label: 'RAG Contract Assistant', path: '/assistant', icon: Bot },
      ]
    },
    {
      title: 'GOVERNANCE & SAAS',
      items: [
        { label: 'Team & RBAC', path: '/users', icon: Users },
        { label: 'Notifications', path: '/notifications', icon: Bell },
        { label: 'Audit Trail', path: '/audit', icon: Activity },
        { label: 'Subscription & Quota', path: '/subscription', icon: CreditCard },
        { label: 'System Health', path: '/system-health', icon: Activity },
        { label: 'Settings', path: '/settings', icon: Settings },
      ]
    }
  ];

  return (
    <aside className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col h-screen sticky top-0 z-30 select-none">
      {/* Brand Header */}
      <div className="h-16 flex items-center px-6 border-b border-slate-800/80">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center shadow-lg shadow-blue-500/20">
            <ShieldCheck className="w-5 h-5 text-white" />
          </div>
          <div>
            <span className="font-extrabold text-base tracking-tight bg-gradient-to-r from-white to-slate-300 bg-clip-text text-transparent">
              ObliGuard AI
            </span>
            <span className="block text-[10px] uppercase font-bold text-blue-400 tracking-wider">Enterprise SaaS</span>
          </div>
        </div>
      </div>

      {/* Navigation Streams */}
      <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6">
        {navSections.map((section, idx) => (
          <div key={idx}>
            <h3 className="px-3 text-[11px] font-bold text-slate-500 tracking-wider uppercase mb-2">
              {section.title}
            </h3>
            <ul className="space-y-1">
              {section.items.map((item) => (
                <li key={item.path}>
                  <NavLink
                    to={item.path}
                    end={item.path === '/'}
                    className={({ isActive }) =>
                      `flex items-center space-x-3 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                        isActive
                          ? 'bg-blue-600/10 text-blue-400 border border-blue-500/20 font-semibold shadow-sm'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                      }`
                    }
                  >
                    <item.icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </NavLink>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      {/* User Footer Card */}
      <div className="p-3 border-t border-slate-800 bg-slate-950/50">
        <div className="flex items-center space-x-3 p-2 rounded-lg bg-slate-900 border border-slate-800">
          <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center font-bold text-xs text-white">
            {user?.full_name?.charAt(0) || 'U'}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-semibold text-white truncate">{user?.full_name || 'Enterprise Admin'}</p>
            <p className="text-[10px] text-blue-400 font-medium truncate">{user?.role_name || 'Org Admin'}</p>
          </div>
        </div>
      </div>
    </aside>
  );
};
