import React from 'react';

interface RiskBadgeProps {
  level: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' | string;
  score?: number;
}

export const RiskBadge: React.FC<RiskBadgeProps> = ({ level, score }) => {
  let style = 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';
  if (level === 'MEDIUM') {
    style = 'bg-amber-500/10 text-amber-400 border-amber-500/30';
  } else if (level === 'HIGH') {
    style = 'bg-orange-500/10 text-orange-400 border-orange-500/30';
  } else if (level === 'CRITICAL') {
    style = 'bg-rose-500/10 text-rose-400 border-rose-500/30 font-bold animate-pulse';
  }

  return (
    <span className={`inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium border ${style}`}>
      <span className="w-1.5 h-1.5 rounded-full bg-current mr-1.5"></span>
      {level} {score !== undefined ? `(${score})` : ''}
    </span>
  );
};
