import React from 'react';
import { LucideIcon } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  trend?: string;
  trendPositive?: boolean;
  color?: string;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  trendPositive = true,
  color = 'blue'
}) => {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between hover:border-slate-700 transition-all">
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{title}</span>
        <div className={`p-2.5 rounded-lg bg-${color}-500/10 text-${color}-400 border border-${color}-500/20`}>
          <Icon className="w-5 h-5 text-blue-400" />
        </div>
      </div>
      <div className="mt-4">
        <div className="text-2xl font-extrabold text-white tracking-tight">{value}</div>
        {subtitle && <p className="text-xs text-slate-400 mt-1">{subtitle}</p>}
        {trend && (
          <div className="flex items-center text-xs mt-2 font-medium">
            <span className={trendPositive ? 'text-emerald-400' : 'text-rose-400'}>
              {trend}
            </span>
            <span className="text-slate-500 ml-1.5">vs last month</span>
          </div>
        )}
      </div>
    </div>
  );
};
