import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Bell, LogOut, ShieldAlert, Building2 } from 'lucide-react';
import { useAuth } from '../auth/AuthContext';
import { ContractSelector } from './ContractSelector';

export const Header: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  return (
    <header className="h-16 bg-slate-900/80 backdrop-blur border-b border-slate-800 px-6 flex items-center justify-between sticky top-0 z-20">
      {/* Quick Search & Active Contract Selector */}
      <div className="flex items-center space-x-3 flex-1 max-w-xl">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search contracts, clauses, obligations..."
            onClick={() => navigate('/search')}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-4 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-all cursor-pointer"
          />
        </div>
        <ContractSelector className="w-60 flex-shrink-0" />
      </div>

      {/* Right Header Status & Profile */}
      <div className="flex items-center space-x-4">
        {/* Tenant Organization Context Pill */}
        <div className="flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-300">
          <Building2 className="w-3.5 h-3.5 text-blue-400" />
          <span className="font-semibold text-slate-200">Acme Corp</span>
          <span className="text-[10px] bg-blue-500/20 text-blue-400 px-1.5 py-0.5 rounded font-mono">Org #1</span>
        </div>

        {/* Notifications Button */}
        <button
          onClick={() => navigate('/notifications')}
          className="relative p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-all"
        >
          <Bell className="w-4 h-4" />
          <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-blue-500"></span>
        </button>

        {/* Logout Button */}
        <button
          onClick={logout}
          title="Sign Out"
          className="p-2 text-slate-400 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition-all"
        >
          <LogOut className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
