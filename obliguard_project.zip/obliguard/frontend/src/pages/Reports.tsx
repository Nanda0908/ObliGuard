import React, { useEffect, useState } from 'react';
import { apiClient } from '../api/client';
import { FileSpreadsheet, Download, Plus, Clock } from 'lucide-react';

export const Reports: React.FC = () => {
  const [reports, setReports] = useState<any[]>([]);
  const [title, setTitle] = useState('Q3 Contract Risk & Compliance Audit');
  const [reportType, setReportType] = useState('Risk');
  const [format, setFormat] = useState('PDF');
  const [generating, setGenerating] = useState(false);

  const fetchReports = async () => {
    try {
      const res = await apiClient.get('/reports');
      setReports(res.data);
    } catch (err) {
      console.error('Failed to load reports:', err);
    }
  };

  useEffect(() => {
    fetchReports();
  }, []);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setGenerating(true);
    try {
      await apiClient.post('/reports/generate', { title, report_type: reportType, format });
      fetchReports();
    } catch (err) {
      console.error('Report generation failed:', err);
    } finally {
      setGenerating(false);
    }
  };

  const handleDownload = (reportId: number) => {
    window.open(`/api/v1/reports/${reportId}/download`, '_blank');
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black text-white tracking-tight">Executive Reports Generator</h1>
        <p className="text-xs text-slate-400 mt-1">
          Generate downloadable audit, compliance, obligation, and risk evaluation reports in PDF, CSV, or JSON formats.
        </p>
      </div>

      {/* Generator Form */}
      <form onSubmit={handleGenerate} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider">Generate Custom Report</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Report Title</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Report Type</label>
            <select
              value={reportType}
              onChange={(e) => setReportType(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
            >
              <option value="Risk">Contract Risk Report</option>
              <option value="Compliance">Compliance & Violation Report</option>
              <option value="Obligation">Obligation & SLA Matrix</option>
              <option value="Renewal">Upcoming Renewals Report</option>
              <option value="Audit">Immutable Audit Trail Report</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Export Format</label>
            <select
              value={format}
              onChange={(e) => setFormat(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
            >
              <option value="PDF">PDF Document</option>
              <option value="CSV">CSV Spreadsheet</option>
              <option value="JSON">Structured JSON</option>
            </select>
          </div>
        </div>

        <button
          type="submit"
          disabled={generating}
          className="bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-6 py-2.5 rounded-xl shadow-lg shadow-blue-500/20 flex items-center space-x-2 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>{generating ? 'Compiling Report...' : 'Generate & Export Report'}</span>
        </button>
      </form>

      {/* Reports Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-slate-950 border-b border-slate-800 text-[11px] font-bold text-slate-400 uppercase">
              <th className="py-3.5 px-4">Report Title</th>
              <th className="py-3.5 px-4">Type</th>
              <th className="py-3.5 px-4">Format</th>
              <th className="py-3.5 px-4">Generated At</th>
              <th className="py-3.5 px-4 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {reports.map((r) => (
              <tr key={r.id} className="hover:bg-slate-800/40">
                <td className="py-3.5 px-4 font-bold text-white flex items-center space-x-2">
                  <FileSpreadsheet className="w-4 h-4 text-blue-400" />
                  <span>{r.title}</span>
                </td>
                <td className="py-3.5 px-4 text-slate-300">{r.report_type}</td>
                <td className="py-3.5 px-4 font-mono font-bold text-slate-400">{r.format}</td>
                <td className="py-3.5 px-4 text-slate-400">{new Date(r.created_at).toLocaleString()}</td>
                <td className="py-3.5 px-4 text-right">
                  <button
                    onClick={() => handleDownload(r.id)}
                    className="bg-blue-600/20 hover:bg-blue-600/40 text-blue-400 border border-blue-500/30 font-semibold px-3 py-1 rounded text-xs transition-all inline-flex items-center space-x-1"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
