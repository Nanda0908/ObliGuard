import React, { useEffect, useState } from 'react';
import { apiClient } from '../api/client';
import { useContract } from '../context/ContractContext';
import { ContractSelector } from '../components/ContractSelector';
import { RiskScore } from '../types/risk';
import { RiskBadge } from '../components/RiskBadge';
import { ShieldAlert, AlertTriangle, TrendingUp, Layers, UploadCloud } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const RiskDashboard: React.FC = () => {
  const { contracts, selectedContractId, selectedContract } = useContract();
  const [riskScore, setRiskScore] = useState<RiskScore | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const targetContractId = typeof selectedContractId === 'number'
    ? selectedContractId
    : (contracts.length > 0 ? contracts[0].id : null);

  useEffect(() => {
    const fetchRisk = async () => {
      if (!targetContractId) {
        setRiskScore(null);
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        const res = await apiClient.get(`/risks/contract/${targetContractId}`);
        setRiskScore(res.data);
      } catch (err) {
        console.error('Failed to load risk dashboard for contract:', err);
        setRiskScore(null);
      } finally {
        setLoading(false);
      }
    };
    fetchRisk();
  }, [targetContractId]);

  const activeContractObj = selectedContract || (contracts.length > 0 ? contracts[0] : null);

  const dimensions = riskScore ? [
    { label: 'Financial Risk', val: riskScore.financial_risk, max: 25 },
    { label: 'Penalty Risk', val: riskScore.penalty_risk, max: 25 },
    { label: 'Compliance Risk', val: riskScore.compliance_risk, max: 30 },
    { label: 'Renewal & Notice Risk', val: riskScore.renewal_risk, max: 20 },
    { label: 'Deadline Exposure', val: riskScore.deadline_risk, max: 20 },
    { label: 'Operational Exposure', val: riskScore.operational_risk, max: 20 },
    { label: 'Legal Liability', val: riskScore.legal_risk, max: 20 },
    { label: 'Data & Security', val: riskScore.security_risk, max: 20 },
  ] : [];

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight">Risk Intelligence Dashboard</h1>
          <p className="text-xs text-slate-400 mt-1">
            Multi-dimensional explainable 0–100 risk evaluations across financial, penalty, and compliance factors.
          </p>
          {activeContractObj && (
            <p className="text-xs text-blue-400 font-semibold mt-1">
              Analyzing Document: {activeContractObj.title} (#{activeContractObj.id})
            </p>
          )}
        </div>
        <div className="flex items-center space-x-3">
          <ContractSelector allowAll={false} className="w-64" />
          {riskScore && <RiskBadge level={riskScore.risk_level} score={riskScore.overall_score} />}
        </div>
      </div>

      {loading ? (
        <div className="text-center py-12 text-slate-400">Evaluating contract risk factors...</div>
      ) : !riskScore ? (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center space-y-4">
          <ShieldAlert className="w-12 h-12 text-slate-600 mx-auto" />
          <h3 className="text-base font-bold text-white">No Risk Score Evaluated</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Select an uploaded contract document above or upload a new contract to view automated multi-dimensional risk evaluation.
          </p>
          <button
            onClick={() => navigate('/contracts/upload')}
            className="bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow-lg inline-flex items-center space-x-2"
          >
            <UploadCloud className="w-4 h-4" />
            <span>Upload Contract Document</span>
          </button>
        </div>
      ) : (
        <>
          {/* 8 Dimension Risk Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {dimensions.map((dim, idx) => (
              <div key={idx} className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl space-y-3">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-slate-400 uppercase tracking-wider">{dim.label}</span>
                  <span className="font-extrabold text-white">{dim.val} / {dim.max}</span>
                </div>
                <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                  <div
                    className={`h-full rounded-full ${dim.val > (dim.max * 0.7) ? 'bg-rose-500' : dim.val > (dim.max * 0.4) ? 'bg-amber-500' : 'bg-emerald-500'}`}
                    style={{ width: `${Math.min(100, (dim.val / dim.max) * 100)}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>

          {/* Factors List */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Identified Risk Factors for Document ({riskScore.factors?.length || 0})
            </h3>
            {riskScore.factors && riskScore.factors.length > 0 ? (
              <div className="space-y-3">
                {riskScore.factors.map((f) => (
                  <div key={f.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <span className="text-xs font-bold text-white">{f.factor_name}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-semibold">{f.dimension}</span>
                      </div>
                      <p className="text-xs text-slate-400">{f.description}</p>
                    </div>
                    <div className="text-right">
                      <span className="text-sm font-extrabold text-rose-400">+{f.score_contribution} pts</span>
                      <span className="block text-[10px] text-slate-500 font-mono">Weight: x{f.weight}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 text-xs text-slate-400 text-center">No high-risk factors flagged for this contract document.</div>
            )}
          </div>
        </>
      )}
    </div>
  );
};
