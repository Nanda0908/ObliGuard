import React, { useEffect, useState } from 'react';
import { apiClient } from '../api/client';
import { CreditCard, CheckCircle2, ShieldCheck } from 'lucide-react';

export const Subscription: React.FC = () => {
  const [usage, setUsage] = useState<any>(null);

  useEffect(() => {
    apiClient.get('/saas/usage').then((res) => setUsage(res.data)).catch(console.error);
  }, []);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-black text-white tracking-tight">SaaS Subscription & Feature Quota</h1>
        <p className="text-xs text-slate-400 mt-1">Enterprise plan status, contract document quotas, and storage utilization.</p>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div>
            <span className="text-xs text-slate-400 uppercase font-bold tracking-wider">Current Plan Tier</span>
            <h2 className="text-xl font-extrabold text-blue-400">{usage?.plan_tier || 'ENTERPRISE'} TIER</h2>
          </div>
          <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-bold border border-emerald-500/30">
            Active Subscription
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <span className="text-xs font-bold text-slate-400 uppercase">Contracts Analyzed</span>
            <p className="text-xl font-extrabold text-white">{usage?.contracts_used || 1} / {usage?.contracts_limit || 1000}</p>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-blue-500 h-full w-[1%]"></div>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <span className="text-xs font-bold text-slate-400 uppercase">Team Users</span>
            <p className="text-xl font-extrabold text-white">{usage?.users_used || 1} / {usage?.users_limit || 50}</p>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-emerald-500 h-full w-[2%]"></div>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <span className="text-xs font-bold text-slate-400 uppercase">Storage Used</span>
            <p className="text-xl font-extrabold text-white">{usage?.storage_mb_used || 1.2} MB / 50 GB</p>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div className="bg-indigo-500 h-full w-[1%]"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
