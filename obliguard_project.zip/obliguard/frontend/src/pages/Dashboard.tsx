import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { apiClient } from '../api/client';
import { MetricCard } from '../components/MetricCard';
import { RiskBadge } from '../components/RiskBadge';
import { AnalyticsDashboard } from '../types/analytics';
import { Obligation } from '../types/obligation';
import {
  FileText,
  AlertTriangle,
  CheckCircle2,
  DollarSign,
  TrendingUp,
  UploadCloud,
  Bot,
  Search,
  ArrowUpRight
} from 'lucide-react';
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis
} from 'recharts';

import { useContract } from '../context/ContractContext';

export const Dashboard: React.FC = () => {
  const { selectedContractId } = useContract();
  const [data, setData] = useState<AnalyticsDashboard | null>(null);
  const [urgentObligations, setUrgentObligations] = useState<Obligation[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        let obUrl = '/obligations?limit=5';
        if (typeof selectedContractId === 'number') {
          obUrl += `&contract_id=${selectedContractId}`;
        }
        const [dashRes, obRes] = await Promise.all([
          apiClient.get('/analytics/dashboard'),
          apiClient.get(obUrl)
        ]);
        setData(dashRes.data);
        setUrgentObligations(obRes.data || []);
      } catch (err) {
        console.error('Failed to load dashboard:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [selectedContractId]);

  if (loading || !data) {
    return (
      <div className="flex items-center justify-center h-64 text-slate-400 text-sm">
        Loading enterprise intelligence metrics...
      </div>
    );
  }

  const { overview } = data;

  const COLORS = ['#10b981', '#f59e0b', '#f97316', '#ef4444'];

  return (
    <div className="space-y-8">
      {/* Top Banner Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight">Contract Obligation & Risk Intelligence</h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time compliance monitoring, automated SLA tracking, and local NLP risk synthesis.
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={() => navigate('/contracts/upload')}
            className="bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs px-4 py-2.5 rounded-xl shadow-lg shadow-blue-500/20 flex items-center space-x-2 transition-all"
          >
            <UploadCloud className="w-4 h-4" />
            <span>Upload Contract</span>
          </button>
          <button
            onClick={() => navigate('/assistant')}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs px-4 py-2.5 rounded-xl flex items-center space-x-2 transition-all"
          >
            <Bot className="w-4 h-4 text-blue-400" />
            <span>AI Assistant</span>
          </button>
        </div>
      </div>

      {/* KPI Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        <MetricCard
          title="Total Contracts"
          value={overview.total_contracts}
          subtitle={`${overview.active_contracts} Active | ${overview.expiring_soon_contracts} Expiring`}
          icon={FileText}
          trend="+12%"
          trendPositive={true}
        />
        <MetricCard
          title="Compliance Rate"
          value={`${overview.compliance_rate_percent}%`}
          subtitle={`${overview.total_obligations} Total Obligations Tracked`}
          icon={CheckCircle2}
          trend="+4.2%"
          trendPositive={true}
        />
        <MetricCard
          title="High/Critical Risk"
          value={overview.high_risk_contracts + overview.critical_risk_contracts}
          subtitle={`${overview.overdue_obligations} Overdue Obligations`}
          icon={AlertTriangle}
          trend="-2"
          trendPositive={true}
          color="rose"
        />
        <MetricCard
          title="Penalty Exposure"
          value={`$${overview.total_penalty_exposure.toLocaleString()}`}
          subtitle={`${overview.total_open_violations} Active Violations`}
          icon={DollarSign}
          trend="$0"
          trendPositive={true}
        />
      </div>

      {/* Analytics Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Risk Distribution Pie */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Contract Risk Distribution</h3>
            <p className="text-xs text-slate-400 mt-0.5">Breakdown by evaluated risk tier</p>
          </div>
          <div className="h-56 my-2">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data.risk_level_distribution}
                  dataKey="count"
                  nameKey="risk_level"
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={80}
                  paddingAngle={5}
                >
                  {data.risk_level_distribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '8px', fontSize: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-4 text-center border-t border-slate-800/80 pt-3">
            {data.risk_level_distribution.map((item, idx) => (
              <div key={idx}>
                <span className="text-[10px] text-slate-400 uppercase font-semibold">{item.risk_level}</span>
                <p className="text-base font-extrabold text-white">{item.count}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Compliance Trend Line Chart */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">Compliance Trend & SLA Overdues</h3>
              <p className="text-xs text-slate-400 mt-0.5">30-day compliance percentage trajectory</p>
            </div>
            <span className="text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-full font-medium flex items-center">
              <TrendingUp className="w-3.5 h-3.5 mr-1" /> SLA Target: 95%
            </span>
          </div>
          <div className="h-60 mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.compliance_trend}>
                <defs>
                  <linearGradient id="colorCompliance" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="date" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} domain={[50, 100]} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '8px', fontSize: '12px' }} />
                <Area type="monotone" dataKey="compliance_rate" stroke="#3b82f6" strokeWidth={2.5} fillOpacity={1} fill="url(#colorCompliance)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Urgent Obligations & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">Urgent Contract Obligations</h3>
              <p className="text-xs text-slate-400">Items requiring immediate action or review</p>
            </div>
            <button
              onClick={() => navigate('/obligations')}
              className="text-xs text-blue-400 hover:text-blue-300 font-semibold flex items-center"
            >
              View All <ArrowUpRight className="w-3.5 h-3.5 ml-1" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-slate-800 text-[11px] font-bold text-slate-400 uppercase">
                  <th className="py-2.5 px-3">Party & Action</th>
                  <th className="py-2.5 px-3">Type</th>
                  <th className="py-2.5 px-3">Deadline</th>
                  <th className="py-2.5 px-3">Priority</th>
                  <th className="py-2.5 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-xs">
                {urgentObligations.map((ob) => (
                  <tr key={ob.id} className="hover:bg-slate-800/40 transition-all cursor-pointer" onClick={() => navigate('/obligations')}>
                    <td className="py-3 px-3">
                      <span className="font-semibold text-white block">{ob.action}</span>
                      <span className="text-[11px] text-slate-400">{ob.party}</span>
                    </td>
                    <td className="py-3 px-3 text-slate-300 font-medium">{ob.obligation_type}</td>
                    <td className="py-3 px-3 text-slate-300">{ob.due_date ? new Date(ob.due_date).toLocaleDateString() : ob.deadline_expression}</td>
                    <td className="py-3 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${ob.priority === 'CRITICAL' ? 'bg-rose-500/20 text-rose-400' : 'bg-amber-500/20 text-amber-400'}`}>
                        {ob.priority}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-500/15 text-blue-400 border border-blue-500/30">
                        {ob.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Quick Action Navigation Grid */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Quick Intelligence Workflows</h3>
            <p className="text-xs text-slate-400 mb-4">Direct shortcuts to key engine features</p>

            <div className="space-y-3">
              <div
                onClick={() => navigate('/search')}
                className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-blue-500/50 transition-all cursor-pointer flex items-center space-x-3"
              >
                <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400">
                  <Search className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">Semantic Search</h4>
                  <p className="text-[11px] text-slate-400">Query contract clauses using vector similarity</p>
                </div>
              </div>

              <div
                onClick={() => navigate('/comparison')}
                className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-blue-500/50 transition-all cursor-pointer flex items-center space-x-3"
              >
                <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">Version Diffing</h4>
                  <p className="text-[11px] text-slate-400">Compare contract revisions & risk deltas</p>
                </div>
              </div>

              <div
                onClick={() => navigate('/reports')}
                className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-blue-500/50 transition-all cursor-pointer flex items-center space-x-3"
              >
                <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white">Executive Reports</h4>
                  <p className="text-[11px] text-slate-400">Generate downloadable PDF/CSV audits</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
