import React, { useState, useEffect } from 'react';
import { apiClient } from '../api/client';
import { useContract } from '../context/ContractContext';
import { ComparisonResponse } from '../types/search';
import { GitCompare, ArrowRight, ShieldAlert, CheckCircle2, Plus, Minus, Edit3 } from 'lucide-react';

export const VersionCompare: React.FC = () => {
  const { contracts } = useContract();
  const [version1Id, setVersion1Id] = useState<number>(0);
  const [version2Id, setVersion2Id] = useState<number>(0);
  const [result, setResult] = useState<ComparisonResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Collect all contract versions across uploaded contracts
  const allVersions: { versionId: number; contractId: number; title: string; versionNumber: int; fileName: string }[] = [];
  contracts.forEach(c => {
    if (c.versions && c.versions.length > 0) {
      c.versions.forEach(v => {
        allVersions.push({
          versionId: v.id,
          contractId: c.id,
          title: c.title,
          versionNumber: v.version_number,
          fileName: v.file_name
        });
      });
    } else {
      // Fallback: use contract ID as version ID if version list is empty
      allVersions.push({
        versionId: c.id,
        contractId: c.id,
        title: c.title,
        versionNumber: 1,
        fileName: c.title
      });
    }
  });

  useEffect(() => {
    if (allVersions.length > 0) {
      if (!version1Id) setVersion1Id(allVersions[0].versionId);
      if (!version2Id) setVersion2Id(allVersions.length > 1 ? allVersions[1].versionId : allVersions[0].versionId);
    }
  }, [contracts]);

  const handleCompare = async () => {
    if (!version1Id || !version2Id) {
      setError('Select two versions to perform comparison.');
      return;
    }

    setError('');
    setLoading(true);
    try {
      const res = await apiClient.post('/comparison', {
        version_id_1: version1Id,
        version_id_2: version2Id
      });
      setResult(res.data);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Comparison failed. Ensure valid document versions are selected.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black text-white tracking-tight">Contract Version Comparison</h1>
        <p className="text-xs text-slate-400 mt-1">
          Perform structural, semantic, and risk diffing between contract document versions.
        </p>
      </div>

      {/* Selectors Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex flex-col sm:flex-row items-center space-y-3 sm:space-y-0 sm:space-x-4 w-full md:w-auto">
          <div className="w-full sm:w-64">
            <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1">Base Version (v1)</label>
            <select
              value={version1Id}
              onChange={(e) => setVersion1Id(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
            >
              {allVersions.map((v) => (
                <option key={`v1-${v.versionId}`} value={v.versionId}>
                  {v.title} (v{v.versionNumber} - #{v.versionId})
                </option>
              ))}
            </select>
          </div>

          <span className="text-slate-500 font-bold text-xs self-center">VS</span>

          <div className="w-full sm:w-64">
            <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1">Target Version (v2)</label>
            <select
              value={version2Id}
              onChange={(e) => setVersion2Id(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
            >
              {allVersions.map((v) => (
                <option key={`v2-${v.versionId}`} value={v.versionId}>
                  {v.title} (v{v.versionNumber} - #{v.versionId})
                </option>
              ))}
            </select>
          </div>
        </div>

        <button
          onClick={handleCompare}
          disabled={loading || allVersions.length === 0}
          className="bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-6 py-2.5 rounded-xl shadow-lg shadow-blue-500/20 flex items-center space-x-2 transition-all w-full md:w-auto justify-center"
        >
          <GitCompare className="w-4 h-4" />
          <span>{loading ? 'Diffing Versions...' : 'Compare Document Versions'}</span>
        </button>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-medium">
          {error}
        </div>
      )}

      {result && (
        <div className="space-y-6">
          {/* Summary Panel */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
              <span className="text-[11px] font-bold text-slate-400 uppercase block">Added Clauses</span>
              <span className="text-2xl font-extrabold text-emerald-400 flex items-center mt-1">
                <Plus className="w-5 h-5 mr-1" /> {result.total_added}
              </span>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
              <span className="text-[11px] font-bold text-slate-400 uppercase block">Removed Clauses</span>
              <span className="text-2xl font-extrabold text-rose-400 flex items-center mt-1">
                <Minus className="w-5 h-5 mr-1" /> {result.total_removed}
              </span>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
              <span className="text-[11px] font-bold text-slate-400 uppercase block">Modified Clauses</span>
              <span className="text-2xl font-extrabold text-amber-400 flex items-center mt-1">
                <Edit3 className="w-5 h-5 mr-1" /> {result.total_modified}
              </span>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
              <span className="text-[11px] font-bold text-slate-400 uppercase block">Risk Score Delta</span>
              <span className="text-2xl font-extrabold text-blue-400 mt-1 block">
                {result.risk_delta >= 0 ? `+${result.risk_delta}` : result.risk_delta} pts
              </span>
            </div>
          </div>

          {/* Diffs List */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Clause Change Timeline</h3>
            {result.clause_diffs.length === 0 ? (
              <div className="p-4 text-xs text-slate-400 text-center">No structural clause changes detected between these versions.</div>
            ) : (
              <div className="space-y-3">
                {result.clause_diffs.map((diff, idx) => (
                  <div key={idx} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          diff.change_type === 'ADDED' ? 'bg-emerald-500/20 text-emerald-400' :
                          diff.change_type === 'REMOVED' ? 'bg-rose-500/20 text-rose-400' : 'bg-amber-500/20 text-amber-400'
                        }`}>
                          {diff.change_type}
                        </span>
                        <span className="text-xs font-bold text-white">{diff.clause_type}</span>
                        <span className="text-[11px] text-slate-400 font-mono">Section {diff.section_number}</span>
                      </div>
                    </div>

                    {diff.old_text && (
                      <div className="p-2.5 rounded bg-rose-950/20 border border-rose-900/30 text-xs text-rose-300">
                        <span className="font-bold block text-[10px] uppercase text-rose-400">Previous Text (v1):</span>
                        "{diff.old_text}"
                      </div>
                    )}

                    {diff.new_text && (
                      <div className="p-2.5 rounded bg-emerald-950/20 border border-emerald-900/30 text-xs text-emerald-300">
                        <span className="font-bold block text-[10px] uppercase text-emerald-400">Revised Text (v2):</span>
                        "{diff.new_text}"
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
