import React, { useEffect, useState } from 'react';
import { apiClient } from '../api/client';
import { Activity, CheckCircle2, Server, Database, Bot } from 'lucide-react';

export const SystemHealth: React.FC = () => {
  const [health, setHealth] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    apiClient.get('/health').then((res) => setHealth(res.data)).catch(console.error).finally(() => setLoading(false));
  }, []);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-black text-white tracking-tight">System Health & Observability</h1>
        <p className="text-xs text-slate-400 mt-1">Live operational status, backend database probes, and local AI engines.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl flex items-center space-x-4">
          <div className="p-3 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <Server className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase">FastAPI Backend API</span>
            <p className="text-base font-extrabold text-emerald-400 mt-0.5">{health?.status?.toUpperCase() || 'HEALTHY'}</p>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl flex items-center space-x-4">
          <div className="p-3 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
            <Database className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase">PostgreSQL / Vector DB</span>
            <p className="text-base font-extrabold text-blue-400 mt-0.5">CONNECTED</p>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl flex items-center space-x-4">
          <div className="p-3 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
            <Bot className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase">Local NLP & AI Engine</span>
            <p className="text-base font-extrabold text-indigo-400 mt-0.5">ONLINE (0 API KEYS)</p>
          </div>
        </div>
      </div>
    </div>
  );
};
