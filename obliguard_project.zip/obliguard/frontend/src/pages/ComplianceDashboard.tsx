import React, { useEffect, useState } from 'react';
import { apiClient } from '../api/client';
import { useContract } from '../context/ContractContext';
import { ContractSelector } from '../components/ContractSelector';
import { ShieldCheck, AlertCircle, DollarSign, CheckCircle2 } from 'lucide-react';

export const ComplianceDashboard: React.FC = () => {
  const { selectedContractId } = useContract();
  const [metrics, setMetrics] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCompliance = async () => {
      try {
        setLoading(true);
        let url = '/analytics/dashboard';
        if (typeof selectedContractId === 'number') {
          url += `?contract_id=${selectedContractId}`;
        }
        const res = await apiClient.get(url);
        setMetrics(res.data.overview);
      } catch (err) {
        console.error('Failed to load compliance data:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchCompliance();
  }, [selectedContractId]);

  if (loading || !metrics) {
    return <div className="text-center py-12 text-slate-400">Loading compliance monitoring data...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight">Compliance & SLA Monitoring</h1>
          <p className="text-xs text-slate-400 mt-1">
            Monitor SLA breaches, compliance check verifications, and financial penalty liabilities.
          </p>
        </div>
        <ContractSelector className="w-64" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl flex items-center space-x-4">
          <div className="p-3 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase">Compliance Rate</span>
            <p className="text-2xl font-extrabold text-white mt-0.5">{metrics.compliance_rate_percent}%</p>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl flex items-center space-x-4">
          <div className="p-3 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/20">
            <AlertCircle className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase">Open Violations</span>
            <p className="text-2xl font-extrabold text-white mt-0.5">{metrics.total_open_violations}</p>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl flex items-center space-x-4">
          <div className="p-3 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <DollarSign className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase">Penalty Exposure</span>
            <p className="text-2xl font-extrabold text-white mt-0.5">${metrics.total_penalty_exposure.toLocaleString()}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
