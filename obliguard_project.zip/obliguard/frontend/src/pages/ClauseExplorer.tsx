import React, { useEffect, useState } from 'react';
import { apiClient } from '../api/client';
import { useContract } from '../context/ContractContext';
import { ContractSelector } from '../components/ContractSelector';
import { Clause } from '../types/contract';
import { Layers, Search, Filter } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const ClauseExplorer: React.FC = () => {
  const { selectedContractId } = useContract();
  const [clauses, setClauses] = useState<Clause[]>([]);
  const [clauseTypeFilter, setClauseTypeFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchClauses = async () => {
      try {
        setLoading(true);
        const params = new URLSearchParams();
        if (typeof selectedContractId === 'number') {
          params.append('contract_id', selectedContractId.toString());
        }
        if (clauseTypeFilter) {
          params.append('clause_type', clauseTypeFilter);
        }

        let url = '/clauses';
        if (params.toString()) url += `?${params.toString()}`;

        const res = await apiClient.get(url);
        setClauses(res.data || []);
      } catch (err) {
        console.error('Failed to load clauses:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchClauses();
  }, [clauseTypeFilter, selectedContractId]);

  const categories = [
    'Payment', 'Termination', 'Renewal', 'Confidentiality', 'Liability',
    'Indemnity', 'Warranty', 'Insurance', 'Intellectual Property', 'SLA',
    'Penalty', 'Dispute Resolution', 'Audit', 'Reporting', 'Compliance', 'Security'
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight">Clause Intelligence Explorer</h1>
          <p className="text-xs text-slate-400 mt-1">
            Inspect, filter, and review classified clauses across your organization's entire contract repository.
          </p>
        </div>
        <ContractSelector className="w-64" />
      </div>

      {/* Filter Chips */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setClauseTypeFilter('')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            clauseTypeFilter === '' ? 'bg-blue-600 text-white' : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          All Categories
        </button>
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setClauseTypeFilter(cat)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              clauseTypeFilter === cat ? 'bg-blue-600 text-white' : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Clauses Stream */}
      <div className="space-y-4">
        {loading ? (
          <div className="text-center py-12 text-slate-400">Loading categorized clauses...</div>
        ) : clauses.length === 0 ? (
          <div className="text-center py-12 text-slate-400 bg-slate-900 rounded-2xl border border-slate-800">
            No clauses found matching selected document or category.
          </div>
        ) : (
          clauses.map((c) => (
            <div key={c.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <span className="px-3 py-1 rounded-lg bg-blue-500/10 text-blue-400 border border-blue-500/20 text-xs font-bold">
                    {c.clause_type}
                  </span>
                  <span
                    onClick={() => navigate(`/contracts/${c.contract_id}`)}
                    className="text-xs text-slate-300 font-mono hover:text-blue-400 cursor-pointer"
                  >
                    Contract ID: #{c.contract_id} | Section {c.section_number || '1.0'} (Page {c.page_number || 1})
                  </span>
                </div>
                <span className={`px-2.5 py-0.5 rounded text-[10px] font-bold ${
                  c.risk_impact === 'CRITICAL' ? 'bg-rose-500/20 text-rose-400' :
                  c.risk_impact === 'HIGH' ? 'bg-orange-500/20 text-orange-400' : 'bg-emerald-500/20 text-emerald-400'
                }`}>
                  Impact: {c.risk_impact}
                </span>
              </div>

              <p className="text-xs text-slate-200 leading-relaxed bg-slate-950/70 p-4 rounded-xl border border-slate-800/80 font-sans">
                "{c.source_text}"
              </p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
