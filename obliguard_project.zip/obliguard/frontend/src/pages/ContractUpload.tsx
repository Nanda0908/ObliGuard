import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { apiClient } from '../api/client';
import { useContract } from '../context/ContractContext';
import { UploadCloud, FileText, CheckCircle2, ArrowRight, ShieldCheck } from 'lucide-react';

export const ContractUpload: React.FC = () => {
  const { refreshContracts, setSelectedContractId } = useContract();
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState('');
  const [contractType, setContractType] = useState('Master Services Agreement');
  const [totalValue, setTotalValue] = useState<number>(100000);
  const [currency, setCurrency] = useState('USD');
  const [uploading, setUploading] = useState(false);
  const [pipelineStep, setPipelineStep] = useState<string>('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selected = e.target.files[0];
      setFile(selected);
      if (!title) {
        setTitle(selected.name.replace(/\.[^/.]+$/, '').replace(/_/g, ' '));
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) {
      setError('Select a contract file (PDF, DOCX, or TXT).');
      return;
    }

    setError('');
    setUploading(true);
    setPipelineStep('Ingesting & Extracting Text...');

    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('title', title);
      formData.append('contract_type', contractType);
      formData.append('total_value', totalValue.toString());
      formData.append('currency', currency);

      setTimeout(() => setPipelineStep('Classifying Clauses & Obligations...'), 1200);
      setTimeout(() => setPipelineStep('Calculating Temporal Deadlines & Risk...'), 2400);

      const res = await apiClient.post('/contracts/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });

      await refreshContracts();
      setSelectedContractId(res.data.id);

      navigate(`/contracts/${res.data.id}`);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Processing failed. Ensure file format is valid.');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-black text-white tracking-tight">Upload & Analyze Contract</h1>
        <p className="text-xs text-slate-400 mt-1">
          Execute automated Document Intelligence, Clause Segmentation, Obligation Extraction, and Risk Evaluation.
        </p>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-medium">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
        {/* Drag & Drop File Zone */}
        <div className="border-2 border-dashed border-slate-700 hover:border-blue-500/60 rounded-xl p-8 text-center transition-all bg-slate-950/50">
          <UploadCloud className="w-10 h-10 text-blue-400 mx-auto mb-3" />
          <p className="text-xs font-semibold text-white">Drag and drop your contract document here</p>
          <p className="text-[11px] text-slate-400 mt-1 mb-4">Supports PDF, DOCX, and TXT files up to 50MB</p>
          
          <input
            type="file"
            id="file-input"
            accept=".pdf,.docx,.doc,.txt"
            onChange={handleFileChange}
            className="hidden"
          />
          <label
            htmlFor="file-input"
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold px-4 py-2 rounded-lg border border-slate-700 cursor-pointer inline-block transition-all"
          >
            Browse Files
          </label>

          {file && (
            <div className="mt-4 p-3 rounded-lg bg-blue-500/10 border border-blue-500/20 inline-flex items-center space-x-2 text-xs text-blue-400 font-medium">
              <FileText className="w-4 h-4" />
              <span>Selected: {file.name} ({(file.size / 1024).toFixed(1)} KB)</span>
            </div>
          )}
        </div>

        {/* Metadata Fields */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Contract Title</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-blue-500"
              placeholder="Master Services Agreement"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Contract Type</label>
            <select
              value={contractType}
              onChange={(e) => setContractType(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
            >
              <option value="Master Services Agreement">Master Services Agreement (MSA)</option>
              <option value="Non-Disclosure Agreement">Non-Disclosure Agreement (NDA)</option>
              <option value="Service Level Agreement">Service Level Agreement (SLA)</option>
              <option value="Vendor Agreement">Vendor Agreement</option>
              <option value="Software License Agreement">Software License Agreement</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Contract Total Value</label>
            <input
              type="number"
              value={totalValue}
              onChange={(e) => setTotalValue(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">Currency</label>
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
            >
              <option value="USD">USD ($)</option>
              <option value="EUR">EUR (€)</option>
              <option value="GBP">GBP (£)</option>
            </select>
          </div>
        </div>

        {uploading ? (
          <div className="p-4 rounded-xl bg-blue-500/10 border border-blue-500/30 text-center space-y-2">
            <div className="animate-spin w-6 h-6 border-2 border-blue-400 border-t-transparent rounded-full mx-auto"></div>
            <p className="text-xs font-bold text-blue-400">{pipelineStep}</p>
            <p className="text-[11px] text-slate-400">Executing OCR, NLP Clause Classifier & Risk Score Evaluator</p>
          </div>
        ) : (
          <button
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 px-4 rounded-xl text-xs shadow-lg shadow-blue-500/25 flex items-center justify-center space-x-2 transition-all"
          >
            <span>Execute Intelligence Pipeline</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        )}
      </form>
    </div>
  );
};
