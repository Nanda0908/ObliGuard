import React, { useEffect, useState } from 'react';
import { apiClient } from '../api/client';
import { useContract } from '../context/ContractContext';
import { ContractSelector } from '../components/ContractSelector';
import { Obligation } from '../types/obligation';
import { CheckCircle2, AlertTriangle, UserCheck, Calendar, Filter, RefreshCw } from 'lucide-react';

export const ObligationList: React.FC = () => {
  const { selectedContractId } = useContract();
  const [obligations, setObligations] = useState<Obligation[]>([]);
  const [statusFilter, setStatusFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [loading, setLoading] = useState(true);

  const fetchObligations = async () => {
    try {
      setLoading(true);
      let url = '/obligations';
      const params = new URLSearchParams();
      if (typeof selectedContractId === 'number') {
        params.append('contract_id', selectedContractId.toString());
      }
      if (statusFilter) params.append('status', statusFilter);
      if (typeFilter) params.append('obligation_type', typeFilter);
      if (params.toString()) url += `?${params.toString()}`;

      const res = await apiClient.get(url);
      setObligations(res.data || []);
    } catch (err) {
      console.error('Failed to load obligations:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchObligations();
  }, [statusFilter, typeFilter, selectedContractId]);

  const handleStatusChange = async (obligationId: number, newStatus: string) => {
    try {
      await apiClient.put(`/obligations/${obligationId}/status?status=${newStatus}`);
      fetchObligations();
    } catch (err: any) {
      alert(err.response?.data?.message || 'Status transition failed.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight">Obligations Matrix & Lifecycle</h1>
          <p className="text-xs text-slate-400 mt-1">
            Track, assign, and manage all extracted contractual obligations and workflow states.
          </p>
        </div>
        <ContractSelector className="w-64" />
      </div>

      {/* Filter Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center space-x-3 w-full md:w-auto">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 text-slate-300 text-xs rounded-lg px-3 py-2 focus:outline-none focus:border-blue-500"
          >
            <option value="">All Statuses</option>
            <option value="Upcoming">Upcoming</option>
            <option value="Due">Due Today</option>
            <option value="Overdue">Overdue</option>
            <option value="Completed">Completed</option>
            <option value="Escalated">Escalated</option>
            <option value="Waived">Waived</option>
          </select>

          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 text-slate-300 text-xs rounded-lg px-3 py-2 focus:outline-none focus:border-blue-500"
          >
            <option value="">All Types</option>
            <option value="Reporting">Reporting</option>
            <option value="Payment">Payment</option>
            <option value="SLA">SLA Uptime</option>
            <option value="Audit">Audit</option>
            <option value="Notice">Notice</option>
            <option value="Compliance">Compliance</option>
          </select>
        </div>

        <button
          onClick={fetchObligations}
          className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold px-4 py-2 rounded-lg border border-slate-700 flex items-center space-x-1.5 transition-all"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh Matrix</span>
        </button>
      </div>

      {/* Obligations Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-950 border-b border-slate-800 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                <th className="py-3.5 px-4">Action & Object</th>
                <th className="py-3.5 px-4">Party</th>
                <th className="py-3.5 px-4">Type</th>
                <th className="py-3.5 px-4">Deadline Rule</th>
                <th className="py-3.5 px-4">Target Date</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-right">Transition Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {loading ? (
                <tr>
                  <td colSpan={7} className="text-center py-8 text-slate-400">Loading obligations matrix...</td>
                </tr>
              ) : obligations.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-8 text-slate-400">No obligations found matching filters.</td>
                </tr>
              ) : (
                obligations.map((ob) => (
                  <tr key={ob.id} className="hover:bg-slate-800/40 transition-all">
                    <td className="py-4 px-4 font-semibold text-white">
                      <span className="block">{ob.action}</span>
                      <span className="text-[11px] text-slate-400 font-normal">{ob.object_target}</span>
                    </td>
                    <td className="py-4 px-4 font-medium text-slate-300">{ob.party}</td>
                    <td className="py-4 px-4 font-semibold text-blue-400">{ob.obligation_type}</td>
                    <td className="py-4 px-4 text-slate-300">{ob.deadline_expression || 'Continuous'}</td>
                    <td className="py-4 px-4 text-slate-300 font-mono">
                      {ob.due_date ? new Date(ob.due_date).toLocaleDateString() : 'N/A'}
                    </td>
                    <td className="py-4 px-4">
                      <span className={`px-2.5 py-1 rounded-md text-[10px] font-bold border ${
                        ob.status === 'Completed' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' :
                        ob.status === 'Overdue' ? 'bg-rose-500/10 text-rose-400 border-rose-500/30 animate-pulse' :
                        ob.status === 'Due' ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' : 'bg-blue-500/10 text-blue-400 border-blue-500/30'
                      }`}>
                        {ob.status}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-right">
                      <div className="flex items-center justify-end space-x-2">
                        {ob.status !== 'Completed' && (
                          <button
                            onClick={() => handleStatusChange(ob.id, 'Completed')}
                            className="bg-emerald-600/20 hover:bg-emerald-600/40 text-emerald-400 border border-emerald-500/30 font-semibold px-2.5 py-1 rounded text-[10px] transition-all"
                          >
                            Complete
                          </button>
                        )}
                        {ob.status !== 'Waived' && (
                          <button
                            onClick={() => handleStatusChange(ob.id, 'Waived')}
                            className="bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 font-semibold px-2.5 py-1 rounded text-[10px] transition-all"
                          >
                            Waive
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
