import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { apiClient } from '../api/client';
import { useContract } from '../context/ContractContext';
import { ContractSelector } from '../components/ContractSelector';
import { SearchResponse } from '../types/search';
import { Search, Layers, FileText, ArrowRight } from 'lucide-react';

export const SemanticSearch: React.FC = () => {
  const { selectedContractId, selectedContract } = useContract();
  const [query, setQuery] = useState('contracts where vendors have strict uptime requirements or penalties');
  const [response, setResponse] = useState<SearchResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query) return;
    setLoading(true);
    try {
      const payload: any = { query, top_k: 5 };
      if (typeof selectedContractId === 'number') {
        payload.contract_id = selectedContractId;
      }

      const res = await apiClient.post('/search', payload);
      setResponse(res.data);
    } catch (err) {
      console.error('Search failed:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight">Semantic Contract Search</h1>
          <p className="text-xs text-slate-400 mt-1">
            Perform natural language similarity search over indexed clauses using SentenceTransformers dense vectors.
          </p>
        </div>
        <ContractSelector className="w-64" />
      </div>

      {/* Query Input */}
      <form onSubmit={handleSearch} className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl flex items-center space-x-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={selectedContract ? `Search clauses inside "${selectedContract.title}"...` : "Search e.g. 'contracts where customer can terminate without cause'..."}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
        </div>
        <button
          type="submit"
          disabled={loading}
          className="bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-6 py-2.5 rounded-xl shadow-lg shadow-blue-500/20 flex items-center space-x-2 transition-all"
        >
          <span>{loading ? 'Searching Vectors...' : 'Execute Search'}</span>
        </button>
      </form>

      {/* Results Stream */}
      {response && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Found {response.total_matches} semantic clause matches</span>
            <span>Vector Match Metric: Cosine Similarity</span>
          </div>

          {response.results.length === 0 ? (
            <div className="text-center py-12 text-slate-400 bg-slate-900 rounded-2xl border border-slate-800 text-xs">
              No semantic vector matches found for query.
            </div>
          ) : (
            response.results.map((item, idx) => (
              <div key={idx} className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <span className="px-2.5 py-1 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20 text-xs font-bold">
                      {item.clause_type}
                    </span>
                    <span
                      onClick={() => navigate(`/contracts/${item.contract_id}`)}
                      className="text-xs text-white font-bold hover:text-blue-400 cursor-pointer flex items-center space-x-1"
                    >
                      <FileText className="w-3.5 h-3.5 text-blue-400" />
                      <span>{item.contract_title}</span>
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono">
                      Section {item.section_number} (Page {item.page_number})
                    </span>
                  </div>
                  <span className="px-2.5 py-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-xs font-mono font-bold">
                    {(item.similarity_score * 100).toFixed(1)}% Match
                  </span>
                </div>

                <p className="text-xs text-slate-200 leading-relaxed bg-slate-950/70 p-4 rounded-xl border border-slate-800/80">
                  "{item.source_text}"
                </p>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};
