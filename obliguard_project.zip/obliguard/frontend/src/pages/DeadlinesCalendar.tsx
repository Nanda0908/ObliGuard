import React, { useEffect, useState } from 'react';
import { apiClient } from '../api/client';
import { useContract } from '../context/ContractContext';
import { ContractSelector } from '../components/ContractSelector';
import { Obligation } from '../types/obligation';
import { Calendar, Clock, AlertCircle, FileText } from 'lucide-react';

export const DeadlinesCalendar: React.FC = () => {
  const { contracts, selectedContractId } = useContract();
  const [obligations, setObligations] = useState<Obligation[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDeadlines = async () => {
      try {
        setLoading(true);
        let url = '/obligations';
        if (typeof selectedContractId === 'number') {
          url += `?contract_id=${selectedContractId}`;
        }
        const res = await apiClient.get(url);
        setObligations(res.data || []);
      } catch (err) {
        console.error('Failed to load deadlines:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchDeadlines();
  }, [selectedContractId]);

  // Compute active notice windows from uploaded contracts
  const activeContractsForNotice = typeof selectedContractId === 'number'
    ? contracts.filter(c => c.id === selectedContractId)
    : contracts;

  const noticeWindows = activeContractsForNotice.map(c => {
    const noticeDays = c.notice_period_days || 30;
    let lastValidDate = 'Continuous / Unspecified';

    if (c.expiry_date) {
      const expDate = new Date(c.expiry_date);
      expDate.setDate(expDate.getDate() - noticeDays);
      lastValidDate = expDate.toLocaleDateString();
    } else {
      // Calculate 60 days notice from today as placeholder if contract is ongoing
      const d = new Date();
      d.setDate(d.getDate() + 60);
      lastValidDate = d.toLocaleDateString();
    }

    return {
      contractId: c.id,
      title: c.title,
      noticeDays,
      lastValidDate,
      autoRenewal: c.auto_renewal,
    };
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight">Contractual Deadlines & Calendar</h1>
          <p className="text-xs text-slate-400 mt-1">
            Chronological schedule of upcoming obligation deadlines, recurring reporting schedules, and notice windows.
          </p>
        </div>
        <ContractSelector className="w-64" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Deadlines Timeline Stream */}
        <div className="lg:col-span-2 space-y-4">
          {loading ? (
            <div className="text-center py-12 text-slate-400">Loading deadline schedule...</div>
          ) : obligations.length === 0 ? (
            <div className="text-center py-12 text-slate-400 bg-slate-900 rounded-2xl border border-slate-800">
              No scheduled deadlines found for selected document.
            </div>
          ) : (
            obligations.map((ob) => (
              <div key={ob.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex items-start justify-between space-x-4">
                <div className="flex items-start space-x-4">
                  <div className="p-3 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20 text-center min-w-[70px]">
                    <Clock className="w-5 h-5 mx-auto mb-1" />
                    <span className="text-[10px] font-bold uppercase block">{ob.due_date ? new Date(ob.due_date).toLocaleDateString(undefined, { month: 'short' }) : 'SCHED'}</span>
                    <span className="text-base font-extrabold text-white leading-none">{ob.due_date ? new Date(ob.due_date).getDate() : '—'}</span>
                  </div>

                  <div>
                    <h3 className="text-sm font-bold text-white">{ob.action}</h3>
                    <p className="text-xs text-slate-400 mt-0.5">{ob.party} — {ob.object_target}</p>
                    <div className="flex items-center space-x-3 mt-2 text-[11px] text-slate-500">
                      <span>Frequency: <strong className="text-slate-300">{ob.frequency}</strong></span>
                      <span>Expression: <strong className="text-slate-300">{ob.deadline_expression || 'Continuous'}</strong></span>
                      <span>Contract ID: <strong className="text-blue-400">#{ob.contract_id}</strong></span>
                    </div>
                  </div>
                </div>

                <span className={`px-2.5 py-1 rounded text-[10px] font-bold border ${
                  ob.priority === 'CRITICAL' ? 'bg-rose-500/20 text-rose-400 border-rose-500/30' : 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                }`}>
                  {ob.priority}
                </span>
              </div>
            ))
          )}
        </div>

        {/* Dynamic Notice Window Widget */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4 h-fit">
          <div className="flex items-center space-x-2">
            <AlertCircle className="w-5 h-5 text-amber-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Cancellation Notice Windows</h3>
          </div>
          <p className="text-xs text-slate-400">
            Critical non-renewal notice dates calculated from uploaded contract expiration terms.
          </p>

          {noticeWindows.length === 0 ? (
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-500 text-center">
              No active notice windows found.
            </div>
          ) : (
            <div className="space-y-3 max-h-[350px] overflow-y-auto">
              {noticeWindows.map((nw) => (
                <div key={nw.contractId} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white truncate">{nw.title}</span>
                    <span className="text-[10px] text-blue-400 font-mono">#{nw.contractId}</span>
                  </div>
                  <div className="flex justify-between text-xs text-slate-400">
                    <span>Notice Window:</span>
                    <span className="text-amber-400 font-bold">{nw.noticeDays} Days Prior</span>
                  </div>
                  <div className="flex justify-between text-xs text-slate-400">
                    <span>Last Valid Date:</span>
                    <span className="text-white font-mono font-semibold">{nw.lastValidDate}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
