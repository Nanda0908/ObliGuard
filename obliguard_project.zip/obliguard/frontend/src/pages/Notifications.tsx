import React from 'react';
import { Bell, Clock, AlertTriangle, CheckCircle2 } from 'lucide-react';

export const Notifications: React.FC = () => {
  const alerts = [
    { title: 'Upcoming Deadline Alert', msg: 'Quarterly compliance report for CloudScale MSA is due in 14 days.', type: 'Deadline', date: '2026-09-07 10:15' },
    { title: 'SLA Uptime Monitoring Alert', msg: 'Cloud Infrastructure SLA uptime check recorded 99.92% compliance.', type: 'SLA', date: '2026-09-06 14:20' },
    { title: 'Risk Score Updated', msg: 'Risk score for Master Services Agreement evaluated at HIGH (68.5).', type: 'Risk', date: '2026-09-05 09:30' }
  ];

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-black text-white tracking-tight">Notification & Escalation Center</h1>
        <p className="text-xs text-slate-400 mt-1">Real-time alerts for deadlines, risk increases, and SLA breaches.</p>
      </div>

      <div className="space-y-3">
        {alerts.map((item, idx) => (
          <div key={idx} className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex items-start space-x-4">
            <div className="p-2.5 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
              <Bell className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-white">{item.title}</h3>
                <span className="text-[10px] text-slate-500 font-mono">{item.date}</span>
              </div>
              <p className="text-xs text-slate-300 mt-1">{item.msg}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
