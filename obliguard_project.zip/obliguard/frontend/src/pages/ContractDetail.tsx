import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { apiClient } from '../api/client';
import { Contract, Clause } from '../types/contract';
import { Obligation } from '../types/obligation';
import { RiskScore } from '../types/risk';
import { RiskBadge } from '../components/RiskBadge';
import { FileText, ShieldAlert, CheckCircle2, Layers, Calendar, DollarSign, ArrowLeft } from 'lucide-react';

export const ContractDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [contract, setContract] = useState<Contract | null>(null);
  const [clauses, setClauses] = useState<Clause[]>([]);
  const [obligations, setObligations] = useState<Obligation[]>([]);
  const [riskScore, setRiskScore] = useState<RiskScore | null>(null);
  const [activeTab, setActiveTab] = useState<'clauses' | 'obligations' | 'risk'>('clauses');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDetails = async () => {
      try {
        const [cRes, clRes, obRes, rRes] = await Promise.all([
          apiClient.get(`/contracts/${id}`),
          apiClient.get(`/clauses?contract_id=${id}`),
          apiClient.get(`/obligations?contract_id=${id}`),
          apiClient.get(`/risks/contract/${id}`).catch(() => ({ data: null }))
        ]);
        setContract(cRes.data);
        setClauses(clRes.data);
        setObligations(obRes.data);
        setRiskScore(rRes.data);
      } catch (err) {
        console.error('Failed to load contract details:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchDetails();
  }, [id]);

  if (loading || !contract) {
    return <div className="text-center py-12 text-slate-400">Loading contract intelligence...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Back Button & Header */}
      <div>
        <button
          onClick={() => navigate('/contracts')}
          className="text-xs text-slate-400 hover:text-white flex items-center space-x-1.5 mb-3 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Contracts</span>
        </button>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center space-x-3 mb-1">
              <h1 className="text-2xl font-black text-white">{contract.title}</h1>
              <RiskBadge level={contract.risk_level} score={contract.risk_score} />
            </div>
            <p className="text-xs text-slate-400">
              Type: <span className="text-slate-200 font-semibold">{contract.contract_type}</span> | Owner ID: #{contract.owner_id || 1}
            </p>
          </div>

          <div className="flex items-center space-x-6 border-t md:border-t-0 md:border-l border-slate-800 pt-4 md:pt-0 md:pl-6 text-xs">
            <div>
              <span className="text-slate-500 uppercase font-semibold text-[10px] block">Contract Value</span>
              <span className="text-base font-extrabold text-white">
                {contract.total_value ? `$${contract.total_value.toLocaleString()} ${contract.currency}` : '—'}
              </span>
            </div>
            <div>
              <span className="text-slate-500 uppercase font-semibold text-[10px] block">Expiry Date</span>
              <span className="text-base font-extrabold text-white">
                {contract.expiry_date ? new Date(contract.expiry_date).toLocaleDateString() : 'Continuous'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs Bar */}
      <div className="flex border-b border-slate-800 space-x-6">
        <button
          onClick={() => setActiveTab('clauses')}
          className={`pb-3 text-xs font-bold transition-all border-b-2 flex items-center space-x-2 ${
            activeTab === 'clauses' ? 'border-blue-500 text-blue-400' : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Clauses ({clauses.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('obligations')}
          className={`pb-3 text-xs font-bold transition-all border-b-2 flex items-center space-x-2 ${
            activeTab === 'obligations' ? 'border-blue-500 text-blue-400' : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>Extracted Obligations ({obligations.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('risk')}
          className={`pb-3 text-xs font-bold transition-all border-b-2 flex items-center space-x-2 ${
            activeTab === 'risk' ? 'border-blue-500 text-blue-400' : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <ShieldAlert className="w-4 h-4" />
          <span>Risk Factor Analysis</span>
        </button>
      </div>

      {/* Tab Content */}
      {activeTab === 'clauses' && (
        <div className="space-y-4">
          {clauses.map((c) => (
            <div key={c.id} className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <span className="px-2.5 py-1 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20 text-xs font-bold">
                    {c.clause_type}
                  </span>
                  <span className="text-xs text-slate-400 font-mono">
                    Section {c.section_number || '1.0'} (Page {c.page_number || 1})
                  </span>
                </div>
                <span className="text-[11px] text-slate-500 font-medium">
                  NLP Confidence: {(c.confidence_score * 100).toFixed(0)}%
                </span>
              </div>

              <p className="text-xs text-slate-200 leading-relaxed font-sans bg-slate-950/60 p-3.5 rounded-lg border border-slate-800/80">
                "{c.source_text}"
              </p>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'obligations' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-950 border-b border-slate-800 text-[11px] font-bold text-slate-400 uppercase">
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4">Responsible Party</th>
                <th className="py-3 px-4">Action & Object</th>
                <th className="py-3 px-4">Deadline</th>
                <th className="py-3 px-4">Frequency</th>
                <th className="py-3 px-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {obligations.map((ob) => (
                <tr key={ob.id} className="hover:bg-slate-800/40">
                  <td className="py-3.5 px-4 font-semibold text-blue-400">{ob.obligation_type}</td>
                  <td className="py-3.5 px-4 text-white font-medium">{ob.party}</td>
                  <td className="py-3.5 px-4 text-slate-200">
                    <span className="font-semibold block">{ob.action}</span>
                    <span className="text-[11px] text-slate-400">{ob.object_target}</span>
                  </td>
                  <td className="py-3.5 px-4 text-slate-300 font-mono">
                    {ob.due_date ? new Date(ob.due_date).toLocaleDateString() : ob.deadline_expression}
                  </td>
                  <td className="py-3.5 px-4 text-slate-400">{ob.frequency}</td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-500/20 text-blue-400">
                      {ob.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'risk' && riskScore && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6 shadow-xl">
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Explainable Risk Factors Breakdown</h3>
            <p className="text-xs text-slate-400 mt-1">{riskScore.explanation_json.explanation}</p>
          </div>

          <div className="space-y-3">
            {riskScore.factors.map((factor) => (
              <div key={factor.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-bold text-white">{factor.factor_name}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400">{factor.dimension}</span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">{factor.description}</p>
                </div>
                <div className="text-right">
                  <span className="text-xs font-extrabold text-rose-400">+{factor.score_contribution} pts</span>
                  <span className="block text-[10px] text-slate-500">Weight: x{factor.weight}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
