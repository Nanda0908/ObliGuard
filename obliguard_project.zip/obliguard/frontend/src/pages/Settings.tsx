import React from 'react';
import { Settings as SettingsIcon, Sliders, Shield } from 'lucide-react';

export const Settings: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-black text-white tracking-tight">Organization Configuration & Risk Settings</h1>
        <p className="text-xs text-slate-400 mt-1">Configure risk evaluation weights, business day holiday calendars, and notification rules.</p>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider">Risk Engine Weight Configuration</h3>
        
        <div className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Financial Exposure Weight (Default: 1.5)</label>
            <input type="range" min="1" max="3" step="0.1" defaultValue="1.5" className="w-full accent-blue-500" />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Liquidated Damages / Penalty Weight (Default: 2.0)</label>
            <input type="range" min="1" max="3" step="0.1" defaultValue="2.0" className="w-full accent-blue-500" />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Overdue Obligation Weight (Default: 2.5)</label>
            <input type="range" min="1" max="3" step="0.1" defaultValue="2.5" className="w-full accent-blue-500" />
          </div>
        </div>

        <button className="bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-6 py-2.5 rounded-xl shadow-lg shadow-blue-500/20">
          Save Configuration
        </button>
      </div>
    </div>
  );
};
