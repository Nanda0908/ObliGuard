import React, { useEffect, useState } from 'react';
import { apiClient } from '../api/client';
import { Activity, Shield } from 'lucide-react';

export const AuditLogs: React.FC = () => {
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLogs = async () => {
      try {
        const res = await apiClient.get('/audit');
        setLogs(res.data);
      } catch (err) {
        console.error('Failed to load audit logs:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchLogs();
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black text-white tracking-tight">Immutable Audit & Governance Trail</h1>
        <p className="text-xs text-slate-400 mt-1">
          Complete, tamper-evident audit record of contract uploads, obligation status transitions, and user logins.
        </p>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-slate-950 border-b border-slate-800 text-[11px] font-bold text-slate-400 uppercase">
              <th className="py-3.5 px-4">Action Event</th>
              <th className="py-3.5 px-4">Resource</th>
              <th className="py-3.5 px-4">User ID</th>
              <th className="py-3.5 px-4">Timestamp</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-mono">
            {logs.map((l) => (
              <tr key={l.id} className="hover:bg-slate-800/40">
                <td className="py-3 px-4 font-bold text-blue-400">{l.action}</td>
                <td className="py-3 px-4 text-slate-300">{l.resource_type} #{l.resource_id}</td>
                <td className="py-3 px-4 text-slate-400">User #{l.user_id || 'System'}</td>
                <td className="py-3 px-4 text-slate-400">{new Date(l.created_at).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
