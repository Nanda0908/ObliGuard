import React, { useEffect, useState } from 'react';
import { apiClient } from '../api/client';
import { useContract } from '../context/ContractContext';
import { ContractSelector } from '../components/ContractSelector';
import { Clause } from '../types/contract';
import { Obligation } from '../types/obligation';
import { RiskScore } from '../types/risk';
import { Network, Layers, CheckCircle2, ShieldAlert, ArrowRight, GitBranch } from 'lucide-react';

export const ObligationGraph: React.FC = () => {
  const { contracts, selectedContractId, selectedContract } = useContract();
  const [clauses, setClauses] = useState<Clause[]>([]);
  const [obligations, setObligations] = useState<Obligation[]>([]);
  const [riskScore, setRiskScore] = useState<RiskScore | null>(null);
  const [loading, setLoading] = useState(true);

  const targetContractId = typeof selectedContractId === 'number'
    ? selectedContractId
    : (contracts.length > 0 ? contracts[0].id : null);

  const activeContractObj = selectedContract || (contracts.length > 0 ? contracts[0] : null);

  useEffect(() => {
    const fetchGraphData = async () => {
      if (!targetContractId) {
        setClauses([]);
        setObligations([]);
        setRiskScore(null);
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        const [clRes, obRes, rRes] = await Promise.all([
          apiClient.get(`/clauses?contract_id=${targetContractId}`),
          apiClient.get(`/obligations?contract_id=${targetContractId}`),
          apiClient.get(`/risks/contract/${targetContractId}`).catch(() => ({ data: null }))
        ]);
        setClauses(clRes.data || []);
        setObligations(obRes.data || []);
        setRiskScore(rRes.data);
      } catch (err) {
        console.error('Failed to load graph data:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchGraphData();
  }, [targetContractId]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight">Obligation Dependency Graph</h1>
          <p className="text-xs text-slate-400 mt-1">
            Visual relationship map linking Contracts, Clauses, Obligations, Deadlines, Responsible Owners, and Risk Triggers.
          </p>
          {activeContractObj && (
            <p className="text-xs text-blue-400 font-semibold mt-1 flex items-center space-x-1.5">
              <GitBranch className="w-3.5 h-3.5" />
              <span>Active Graph Document: {activeContractObj.title} (#{activeContractObj.id})</span>
            </p>
          )}
        </div>
        <ContractSelector allowAll={false} className="w-64" />
      </div>

      {/* Interactive Graph Visualization Shell */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl min-h-[520px] flex flex-col justify-between relative overflow-hidden">
        <div className="flex items-center justify-between z-10 pb-4 border-b border-slate-800">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Automated Graph Engine Flow</span>
          <div className="flex items-center space-x-4 text-xs">
            <span className="flex items-center text-blue-400 font-semibold"><span className="w-2.5 h-2.5 rounded-full bg-blue-500 mr-1.5"></span> Contract Root</span>
            <span className="flex items-center text-indigo-400 font-semibold"><span className="w-2.5 h-2.5 rounded-full bg-indigo-500 mr-1.5"></span> Clauses ({clauses.length})</span>
            <span className="flex items-center text-emerald-400 font-semibold"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500 mr-1.5"></span> Obligations ({obligations.length})</span>
            <span className="flex items-center text-rose-400 font-semibold"><span className="w-2.5 h-2.5 rounded-full bg-rose-500 mr-1.5"></span> Risk Factors ({riskScore?.factors?.length || 0})</span>
          </div>
        </div>

        {loading ? (
          <div className="text-center py-20 text-slate-400 text-xs">Building dependency graph from extracted document structure...</div>
        ) : !activeContractObj ? (
          <div className="text-center py-20 text-slate-400 text-xs">No contract document selected. Upload a contract to construct graph.</div>
        ) : (
          <div className="my-6 grid grid-cols-1 lg:grid-cols-4 gap-6 items-start justify-center relative z-10">
            {/* Column 1: Contract Node */}
            <div className="space-y-3">
              <div className="flex items-center justify-center space-x-1.5">
                <span className="text-[11px] font-bold text-blue-400 uppercase tracking-wider">1. Document Node</span>
              </div>
              <div className="bg-slate-950 border-2 border-blue-500/60 rounded-2xl p-5 shadow-xl text-center space-y-3 relative group hover:border-blue-400 transition-all">
                <div className="w-12 h-12 rounded-2xl bg-blue-500/20 text-blue-400 flex items-center justify-center mx-auto border border-blue-500/40 shadow-inner">
                  <Network className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-xs font-extrabold text-white block leading-tight">{activeContractObj.title}</span>
                  <span className="text-[10px] text-blue-400 font-mono block mt-1">ID: #{activeContractObj.id} | {activeContractObj.contract_type}</span>
                </div>
                <div className="pt-2 border-t border-slate-800 text-[10px] text-slate-400 space-y-1">
                  <div className="flex justify-between"><span>Value:</span><strong className="text-white font-mono">${activeContractObj.total_value?.toLocaleString() || '0'}</strong></div>
                  <div className="flex justify-between"><span>Risk Score:</span><strong className="text-rose-400 font-bold">{activeContractObj.risk_score} / 100</strong></div>
                </div>
              </div>
            </div>

            {/* Column 2: Classified Clauses */}
            <div className="space-y-3">
              <div className="flex items-center justify-center space-x-1.5">
                <span className="text-[11px] font-bold text-indigo-400 uppercase tracking-wider">2. Extracted Clauses ({clauses.length})</span>
              </div>
              <div className="space-y-2.5 max-h-[420px] overflow-y-auto pr-1">
                {clauses.length === 0 ? (
                  <div className="p-4 text-center text-[11px] text-slate-500 bg-slate-950/60 rounded-xl border border-slate-800">No clauses extracted</div>
                ) : (
                  clauses.map((c) => (
                    <div key={c.id} className="bg-slate-950 border border-indigo-500/30 rounded-xl p-3.5 shadow-md text-left space-y-1.5 hover:border-indigo-400 transition-all">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-white truncate">{c.clause_type}</span>
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-mono">Sec {c.section_number}</span>
                      </div>
                      <p className="text-[10px] text-slate-400 line-clamp-2 leading-relaxed">"{c.source_text}"</p>
                      <div className="flex items-center justify-between text-[9px] text-slate-500 pt-1 border-t border-slate-900">
                        <span>Page {c.page_number}</span>
                        <span className={`font-bold ${c.risk_impact === 'CRITICAL' ? 'text-rose-400' : 'text-emerald-400'}`}>{c.risk_impact}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Column 3: Extracted Obligations */}
            <div className="space-y-3">
              <div className="flex items-center justify-center space-x-1.5">
                <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider">3. Action Obligations ({obligations.length})</span>
              </div>
              <div className="space-y-2.5 max-h-[420px] overflow-y-auto pr-1">
                {obligations.length === 0 ? (
                  <div className="p-4 text-center text-[11px] text-slate-500 bg-slate-950/60 rounded-xl border border-slate-800">No obligations extracted</div>
                ) : (
                  obligations.map((ob) => (
                    <div key={ob.id} className="bg-slate-950 border border-emerald-500/30 rounded-xl p-3.5 shadow-md text-left space-y-1.5 hover:border-emerald-400 transition-all">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-white truncate">{ob.action}</span>
                        <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold ${ob.priority === 'CRITICAL' ? 'bg-rose-500/20 text-rose-400' : 'bg-amber-500/20 text-amber-400'}`}>
                          {ob.priority}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-300 font-medium">{ob.party} — {ob.object_target}</p>
                      <div className="flex items-center justify-between text-[9px] text-emerald-400 font-mono pt-1 border-t border-slate-900">
                        <span>{ob.obligation_type}</span>
                        <span>{ob.deadline_expression || 'Continuous'}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Column 4: Evaluated Risk Factors */}
            <div className="space-y-3">
              <div className="flex items-center justify-center space-x-1.5">
                <span className="text-[11px] font-bold text-rose-400 uppercase tracking-wider">4. Risk Triggers ({riskScore?.factors?.length || 0})</span>
              </div>
              <div className="space-y-2.5 max-h-[420px] overflow-y-auto pr-1">
                {!riskScore?.factors || riskScore.factors.length === 0 ? (
                  <div className="p-4 text-center text-[11px] text-slate-500 bg-slate-950/60 rounded-xl border border-slate-800">No critical risk triggers</div>
                ) : (
                  riskScore.factors.map((f) => (
                    <div key={f.id} className="bg-slate-950 border border-rose-500/30 rounded-xl p-3.5 shadow-md text-left space-y-1.5 hover:border-rose-400 transition-all">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-white truncate">{f.factor_name}</span>
                        <span className="text-[10px] font-bold text-rose-400">+{f.score_contribution} pts</span>
                      </div>
                      <p className="text-[10px] text-slate-400 leading-relaxed">{f.description}</p>
                      <span className="text-[9px] text-slate-500 font-mono block pt-1 border-t border-slate-900">Dimension: {f.dimension}</span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        <div className="text-center text-xs text-slate-500 z-10 border-t border-slate-800 pt-3 mt-4">
          Dependency graph generated in real-time from active document NLP extraction database
        </div>
      </div>
    </div>
  );
};
