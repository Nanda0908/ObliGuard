import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { apiClient } from '../api/client';
import { Contract } from '../types/contract';
import { RiskBadge } from '../components/RiskBadge';
import { FileText, Plus, Search, Filter, Calendar, DollarSign, Eye, Trash2 } from 'lucide-react';

export const ContractsList: React.FC = () => {
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const fetchContracts = async () => {
    try {
      setLoading(true);
      let url = '/contracts';
      const params = new URLSearchParams();
      if (query) params.append('query', query);
      if (statusFilter) params.append('status', statusFilter);
      if (params.toString()) url += `?${params.toString()}`;

      const res = await apiClient.get(url);
      setContracts(res.data);
    } catch (err) {
      console.error('Failed to load contracts:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchContracts();
  }, [statusFilter]);

  const handleDelete = async (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Delete contract and associated intelligence data?')) {
      await apiClient.delete(`/contracts/${id}`);
      fetchContracts();
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tight">Contract Repository</h1>
          <p className="text-xs text-slate-400 mt-1">Manage, inspect, and analyze all enterprise contracts.</p>
        </div>
        <button
          onClick={() => navigate('/contracts/upload')}
          className="bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs px-4 py-2.5 rounded-xl shadow-lg shadow-blue-500/20 flex items-center space-x-2 transition-all self-start"
        >
          <Plus className="w-4 h-4" />
          <span>Upload New Contract</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Filter by title, contract number, or keywords..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && fetchContracts()}
            className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
        </div>
        <div className="flex items-center space-x-3 w-full md:w-auto">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 text-slate-300 text-xs rounded-lg px-3 py-2 focus:outline-none focus:border-blue-500"
          >
            <option value="">All Statuses</option>
            <option value="Active">Active</option>
            <option value="Expiring">Expiring Soon</option>
            <option value="Draft">Draft</option>
            <option value="Expired">Expired</option>
          </select>
          <button
            onClick={fetchContracts}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold px-4 py-2 rounded-lg border border-slate-700 transition-all"
          >
            Apply Filters
          </button>
        </div>
      </div>

      {/* Contracts Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-950 border-b border-slate-800 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                <th className="py-3.5 px-4">Contract Title</th>
                <th className="py-3.5 px-4">Type</th>
                <th className="py-3.5 px-4">Value</th>
                <th className="py-3.5 px-4">Risk Evaluation</th>
                <th className="py-3.5 px-4">Expiry Date</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-xs">
              {loading ? (
                <tr>
                  <td colSpan={7} className="text-center py-8 text-slate-400">Loading contracts...</td>
                </tr>
              ) : contracts.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-8 text-slate-400">No contracts found. Upload a contract to begin.</td>
                </tr>
              ) : (
                contracts.map((c) => (
                  <tr
                    key={c.id}
                    onClick={() => navigate(`/contracts/${c.id}`)}
                    className="hover:bg-slate-800/50 transition-all cursor-pointer group"
                  >
                    <td className="py-4 px-4 font-semibold text-white">
                      <div className="flex items-center space-x-2.5">
                        <FileText className="w-4 h-4 text-blue-400 flex-shrink-0" />
                        <div>
                          <span className="block group-hover:text-blue-400 transition-colors">{c.title}</span>
                          <span className="text-[10px] text-slate-400 font-mono">{c.contract_number || `ID: #${c.id}`}</span>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-4 text-slate-300 font-medium">{c.contract_type}</td>
                    <td className="py-4 px-4 font-mono text-slate-200">
                      {c.total_value ? `$${c.total_value.toLocaleString()} ${c.currency}` : '—'}
                    </td>
                    <td className="py-4 px-4">
                      <RiskBadge level={c.risk_level} score={c.risk_score} />
                    </td>
                    <td className="py-4 px-4 text-slate-300">
                      {c.expiry_date ? new Date(c.expiry_date).toLocaleDateString() : 'Continuous'}
                    </td>
                    <td className="py-4 px-4">
                      <span className={`px-2.5 py-1 rounded-md text-[10px] font-semibold border ${c.status === 'Active' ? 'bg-blue-500/10 text-blue-400 border-blue-500/30' : 'bg-slate-800 text-slate-400 border-slate-700'}`}>
                        {c.status}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-right">
                      <div className="flex items-center justify-end space-x-2">
                        <button
                          onClick={(e) => { e.stopPropagation(); navigate(`/contracts/${c.id}`); }}
                          className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition-all"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={(e) => handleDelete(c.id, e)}
                          className="p-1.5 hover:bg-rose-500/10 text-slate-400 hover:text-rose-400 rounded-lg transition-all"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
