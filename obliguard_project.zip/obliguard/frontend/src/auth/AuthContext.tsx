import React, { createContext, useContext, useState, useEffect } from 'react';
import { apiClient } from '../api/client';

interface User {
  id: number;
  email: string;
  full_name: string;
  role_name: string;
  organization_id: number;
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  login: (email: string, pass: string) => Promise<void>;
  register: (email: string, pass: string, name: string, orgName: string) => Promise<void>;
  logout: () => void;
  hasRole: (roles: string[]) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('obliguard_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('obliguard_token'));

  useEffect(() => {
    if (token) {
      apiClient.get('/auth/me')
        .then(res => {
          setUser(res.data);
          localStorage.setItem('obliguard_user', JSON.stringify(res.data));
        })
        .catch(() => logout());
    }
  }, [token]);

  const login = async (email: string, password: string) => {
    const res = await apiClient.post('/auth/login', { email, password });
    const data = res.data;
    setToken(data.access_token);
    localStorage.setItem('obliguard_token', data.access_token);
    const u: User = {
      id: data.user_id,
      email,
      full_name: data.full_name,
      role_name: data.role,
      organization_id: data.organization_id
    };
    setUser(u);
    localStorage.setItem('obliguard_user', JSON.stringify(u));
  };

  const register = async (email: string, password: string, full_name: string, organization_name: string) => {
    const res = await apiClient.post('/auth/register', { email, password, full_name, organization_name });
    const data = res.data;
    setToken(data.access_token);
    localStorage.setItem('obliguard_token', data.access_token);
    const u: User = {
      id: data.user_id,
      email,
      full_name: data.full_name,
      role_name: data.role,
      organization_id: data.organization_id
    };
    setUser(u);
    localStorage.setItem('obliguard_user', JSON.stringify(u));
  };

  const logout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem('obliguard_token');
    localStorage.removeItem('obliguard_user');
  };

  const hasRole = (allowedRoles: string[]) => {
    if (!user) return false;
    if (user.role_name === 'Super Admin' || user.role_name === 'Organization Admin') return true;
    return allowedRoles.includes(user.role_name);
  };

  return (
    <AuthContext.Provider value={{ user, token, isAuthenticated: !!token, login, register, logout, hasRole }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};
